using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Loader;
namespace BeatsOn
{
    /// <summary>Ponto de entrada chamado pela engine C++ (hostfxr). Metodos [UnmanagedCallersOnly] = function pointers nativos.</summary>
    public static unsafe class Host
    {
        static readonly List<BeatsOnScript> scripts = new();
        static readonly List<Assembly> assemblies = new();
        static string S(byte* p) => Marshal.PtrToStringUTF8((IntPtr)p) ?? "";
        static void Each(Action<BeatsOnScript> a) { foreach (var s in scripts) { try { a(s); } catch (Exception e) { Game.Log("[Script erro] " + e); } } }

        [UnmanagedCallersOnly] public static void Init(IntPtr api) { N.Api = (NativeApi*)api; }
        [UnmanagedCallersOnly] public static int LoadScriptAssembly(byte* path)
        {
            try { var ctx = AssemblyLoadContext.GetLoadContext(typeof(Host).Assembly); assemblies.Add(ctx.LoadFromAssemblyPath(S(path))); return 1; }
            catch (Exception e) { Game.Log("[Script] falha ao carregar assembly: " + e.Message); return 0; }
        }
        [UnmanagedCallersOnly] public static int ActivateScript(byte* className)
        {
            string name = S(className);
            foreach (var asm in assemblies) { var t = asm.GetType(name); if (t != null && typeof(BeatsOnScript).IsAssignableFrom(t)) { scripts.Add((BeatsOnScript)Activator.CreateInstance(t)); return 1; } }
            Game.Log("[Script] classe nao encontrada: " + name); return 0;
        }
        [UnmanagedCallersOnly] public static void ClearScripts() { scripts.Clear(); }
        [UnmanagedCallersOnly] public static void OnLevelLoad(byte* n) { var s = S(n); Each(x => x.OnLevelLoad(s)); }
        [UnmanagedCallersOnly] public static void OnUpdate(float dt) => Each(x => x.OnUpdate(dt));
        [UnmanagedCallersOnly] public static void OnBeat(int b) => Each(x => x.OnBeat(b));
        [UnmanagedCallersOnly] public static void OnStep(int b) => Each(x => x.OnStep(b));
        [UnmanagedCallersOnly] public static void OnSongStart(byte* n) { var s = S(n); Each(x => x.OnSongStart(s)); }
        [UnmanagedCallersOnly] public static void OnSongEnd(byte* n) { var s = S(n); Each(x => x.OnSongEnd(s)); }
        [UnmanagedCallersOnly] public static void OnNoteSpawn(int side, int lane, double t) { var n = new NoteInfo { Side = (Side)side, Lane = lane, TimeMs = t }; Each(x => x.OnNoteSpawn(n)); }
        [UnmanagedCallersOnly] public static void OnNoteReachStrum(int side, int lane, double t, int idx) { var n = new NoteInfo { Side = (Side)side, Lane = lane, TimeMs = t, Index = idx }; Each(x => x.OnNoteReachStrum(n)); }
        [UnmanagedCallersOnly] public static void OnNoteHit(int side, int lane, int j, double d) { var n = new NoteInfo { Side = (Side)side, Lane = lane }; Each(x => x.OnNoteHit(n, (Judgement)j, d)); }
        [UnmanagedCallersOnly] public static void OnNoteMiss(int side, int lane) { var n = new NoteInfo { Side = (Side)side, Lane = lane }; Each(x => x.OnNoteMiss(n)); }
        [UnmanagedCallersOnly] public static void OnGhostTap(int lane) => Each(x => x.OnGhostTap(lane));
        [UnmanagedCallersOnly] public static void OnEvent(byte* n, byte* a) { string nn = S(n), aa = S(a); Each(x => x.OnEvent(nn, aa)); }
    }
}
