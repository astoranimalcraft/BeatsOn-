using System;
using System.Runtime.InteropServices;
namespace BeatsOn
{
    // Espelho de BOApi (src/scripting/BeatsOnAPI.h). A ORDEM DOS CAMPOS DEVE SER IDENTICA.
    [StructLayout(LayoutKind.Sequential)]
    internal unsafe struct NativeApi
    {
        public uint version;
        public delegate* unmanaged[Cdecl]<float, float, int, void> Camera_ZoomTo;
        public delegate* unmanaged[Cdecl]<float, float, void> Camera_ZoomPunch;
        public delegate* unmanaged[Cdecl]<float, float, int, void> Camera_FovTo;
        public delegate* unmanaged[Cdecl]<float, float, float, float, int, void> Camera_MoveTo;
        public delegate* unmanaged[Cdecl]<float, float, float, float, int, void> Camera_RotateTo;
        public delegate* unmanaged[Cdecl]<float, float, void> Camera_Shake;
        public delegate* unmanaged[Cdecl]<float, float, float, float, float, void> Camera_Flash;
        public delegate* unmanaged[Cdecl]<float, float, float, int, float, void> Camera_Fade;
        public delegate* unmanaged[Cdecl]<int, float, float, int, void> Camera_SetPost;
        public delegate* unmanaged[Cdecl]<uint, float, float, float, float, void> Camera_Follow;
        public delegate* unmanaged[Cdecl]<int, float, void> Camera_SetOrtho;
        public delegate* unmanaged[Cdecl]<byte*, uint> Entity_Find;
        public delegate* unmanaged[Cdecl]<uint, float, float, float, void> Entity_SetPosition;
        public delegate* unmanaged[Cdecl]<uint, float*, void> Entity_GetPosition;
        public delegate* unmanaged[Cdecl]<uint, float, float, float, void> Entity_SetRotation;
        public delegate* unmanaged[Cdecl]<uint, float, float, float, void> Entity_SetScale;
        public delegate* unmanaged[Cdecl]<uint, int, void> Entity_SetActive;
        public delegate* unmanaged[Cdecl]<uint, byte*, void> Sprite_SetTexture;
        public delegate* unmanaged[Cdecl]<uint, float, float, float, float, void> Sprite_SetTint;
        public delegate* unmanaged[Cdecl]<uint, int, void> Sprite_SetFlipX;
        public delegate* unmanaged[Cdecl]<uint, float, float, void> Sprite_SetSize;
        public delegate* unmanaged[Cdecl]<uint, byte*, int, void> Sprite_PlayAnim;
        public delegate* unmanaged[Cdecl]<uint, byte*, int, int, int, int, float, int, void> Sprite_AddGridAnim;
        public delegate* unmanaged[Cdecl]<float, float, float, float, void> Sky_Set;
        public delegate* unmanaged[Cdecl]<int> Game_GetScore;
        public delegate* unmanaged[Cdecl]<int> Game_GetCombo;
        public delegate* unmanaged[Cdecl]<float> Game_GetHealth;
        public delegate* unmanaged[Cdecl]<float, void> Game_SetHealth;
        public delegate* unmanaged[Cdecl]<double> Game_GetSongTimeMs;
        public delegate* unmanaged[Cdecl]<byte*, void> Game_LoadLevel;
        public delegate* unmanaged[Cdecl]<void> Game_EndSong;
        public delegate* unmanaged[Cdecl]<int, int, int, void> Strum_Pulse;
        public delegate* unmanaged[Cdecl]<int, int> Input_KeyDown;
        public delegate* unmanaged[Cdecl]<int, int> Input_KeyPressed;
        public delegate* unmanaged[Cdecl]<byte*, void> Audio_PlaySfx;
        public delegate* unmanaged[Cdecl]<byte*, void> Log;
    }
}
