using System;
using System.Text;
using System.Runtime.InteropServices;
namespace BeatsOn
{
    public enum Ease { Linear, QuadIn, QuadOut, QuadInOut, CubicIn, CubicOut, CubicInOut, SineInOut, BackOut, ElasticOut, BounceOut, Instant }
    public enum PostParam { Exposure, Bloom, Vignette, ChromaticAberration, Saturation, Contrast, Grain, FlashAmount }
    public enum Judgement { Sick, Good, Bad, Shit, Miss }
    public enum Side { Player = 0, Opponent = 1 }
    public struct Vec3 { public float X, Y, Z; public Vec3(float x, float y, float z) { X = x; Y = y; Z = z; } }
    public struct NoteInfo { public Side Side; public int Lane; public double TimeMs; public int Index; }

    internal static unsafe class N
    {
        public static NativeApi* Api;
        public static byte[] Utf8(string s) => Encoding.UTF8.GetBytes(s + "\0");
    }

    /// <summary>Camera do jogador na GamePlay: zoom, movimento, rotacao, efeitos e pos-processamento.</summary>
    public static unsafe class Camera
    {
        public static void ZoomTo(float zoom, float duration = 0.4f, Ease ease = Ease.QuadOut) => N.Api->Camera_ZoomTo(zoom, duration, (int)ease);
        public static void ZoomPunch(float amount = 0.04f, float duration = 0.25f) => N.Api->Camera_ZoomPunch(amount, duration);
        public static void FovTo(float fov, float duration = 0.4f, Ease ease = Ease.QuadOut) => N.Api->Camera_FovTo(fov, duration, (int)ease);
        public static void MoveTo(float x, float y, float z, float duration = 0.5f, Ease ease = Ease.QuadInOut) => N.Api->Camera_MoveTo(x, y, z, duration, (int)ease);
        public static void RotateTo(float pitch, float yaw, float roll, float duration = 0.5f, Ease ease = Ease.QuadInOut) => N.Api->Camera_RotateTo(pitch, yaw, roll, duration, (int)ease);
        public static void Shake(float intensity = 0.08f, float duration = 0.3f) => N.Api->Camera_Shake(intensity, duration);
        public static void Flash(float r = 1, float g = 1, float b = 1, float amount = 1, float duration = 0.5f) => N.Api->Camera_Flash(r, g, b, amount, duration);
        public static void Fade(bool fadeOut, float duration = 1f, float r = 0, float g = 0, float b = 0) => N.Api->Camera_Fade(r, g, b, fadeOut ? 1 : 0, duration);
        public static void SetPost(PostParam p, float value, float duration = 0f, Ease ease = Ease.QuadOut) => N.Api->Camera_SetPost((int)p, value, duration, (int)ease);
        public static void Follow(Entity e, float lerp = 5f) => N.Api->Camera_Follow(e.Id, 0, 0, 0, lerp);
        public static void SetOrthographic(bool on, float size = 5f) => N.Api->Camera_SetOrtho(on ? 1 : 0, size);
    }

    /// <summary>Handle para uma entidade da cena (sprite, modelo, etc.).</summary>
    public readonly unsafe struct Entity
    {
        public readonly uint Id; public Entity(uint id) { Id = id; }
        public bool IsValid => Id != 0;
        public static Entity Find(string name) { fixed (byte* p = N.Utf8(name)) return new Entity(N.Api->Entity_Find(p)); }
        public Vec3 Position { get { float* v = stackalloc float[3]; N.Api->Entity_GetPosition(Id, v); return new Vec3(v[0], v[1], v[2]); } set => N.Api->Entity_SetPosition(Id, value.X, value.Y, value.Z); }
        public void SetRotation(float x, float y, float z) => N.Api->Entity_SetRotation(Id, x, y, z);
        public void SetScale(float x, float y, float z) => N.Api->Entity_SetScale(Id, x, y, z);
        public void SetActive(bool a) => N.Api->Entity_SetActive(Id, a ? 1 : 0);
        // ---- Sprite 2D ----
        public void SetTexture(string path) { fixed (byte* p = N.Utf8(path)) N.Api->Sprite_SetTexture(Id, p); }
        public void SetTint(float r, float g, float b, float a = 1) => N.Api->Sprite_SetTint(Id, r, g, b, a);
        public void FlipX(bool f) => N.Api->Sprite_SetFlipX(Id, f ? 1 : 0);
        public void SetSpriteSize(float w, float h) => N.Api->Sprite_SetSize(Id, w, h);
        public void PlayAnim(string name, bool restart = true) { fixed (byte* p = N.Utf8(name)) N.Api->Sprite_PlayAnim(Id, p, restart ? 1 : 0); }
        public void AddGridAnim(string name, int startFrame, int count, int cols, int rows, float fps = 24, bool loop = true) { fixed (byte* p = N.Utf8(name)) N.Api->Sprite_AddGridAnim(Id, p, startFrame, count, cols, rows, fps, loop ? 1 : 0); }
    }

    public static unsafe class Sky
    {
        public static void Set(float sunElevation, float sunAzimuth, float cloudCover = 0.55f, float cloudDensity = 1f) => N.Api->Sky_Set(sunElevation, sunAzimuth, cloudCover, cloudDensity);
    }

    public static unsafe class Game
    {
        public static int Score => N.Api->Game_GetScore();
        public static int Combo => N.Api->Game_GetCombo();
        public static float Health { get => N.Api->Game_GetHealth(); set => N.Api->Game_SetHealth(value); }
        public static double SongTimeMs => N.Api->Game_GetSongTimeMs();
        public static void LoadLevel(string levelPath) { fixed (byte* p = N.Utf8(levelPath)) N.Api->Game_LoadLevel(p); }
        public static void EndSong() => N.Api->Game_EndSong();
        public static void PulseStrum(Side side, int lane, bool pressed = true) => N.Api->Strum_Pulse((int)side, lane, pressed ? 1 : 0);
        public static void PlaySfx(string path) { fixed (byte* p = N.Utf8(path)) N.Api->Audio_PlaySfx(p); }
        public static void Log(string msg) { fixed (byte* p = N.Utf8(msg)) N.Api->Log(p); }
    }
    public static unsafe class Input
    {
        public static bool IsDown(int virtualKey) => N.Api->Input_KeyDown(virtualKey) != 0;
        public static bool WasPressed(int virtualKey) => N.Api->Input_KeyPressed(virtualKey) != 0;
    }

    /// <summary>Base de todo script de level. Sobrescreva so o que precisar.</summary>
    public abstract class BeatsOnScript
    {
        public virtual void OnLevelLoad(string levelName) { }
        public virtual void OnUpdate(float dt) { }
        public virtual void OnBeat(int beat) { }
        public virtual void OnStep(int step) { }
        public virtual void OnSongStart(string song) { }
        public virtual void OnSongEnd(string song) { }
        public virtual void OnNoteSpawn(NoteInfo note) { }
        /// <summary>A seta encostou na seta principal (strum). Ideal p/ animar o oponente, shake, etc.</summary>
        public virtual void OnNoteReachStrum(NoteInfo note) { }
        public virtual void OnNoteHit(NoteInfo note, Judgement j, double deltaMs) { }
        public virtual void OnNoteMiss(NoteInfo note) { }
        public virtual void OnGhostTap(int lane) { }
        /// <summary>Evento colocado no Music Editor (trilha "Events"): nome + argumento.</summary>
        public virtual void OnEvent(string name, string arg) { }
    }
}
