#pragma once
#include "ModInfo.h"
namespace bo {
struct ExportOptions {
    ModInfo info;               // nome, descricao, criador, versao
    std::string iconPng;        // png escolhido como icone do mod (opcional)
    std::string projectDir;     // pasta do projeto (Levels/, Scenes/, Songs/, Assets/, Scripts/)
    std::string outFile;        // .beatson de saida
    bool includeScriptSources = false;
};
bool ExportMod(const ExportOptions& o, std::string& error);                       // gera o pacote .beatson (zip)
std::vector<ModInfo> ListMods(const std::string& modsDir);                         // le mod.json de cada .beatson
bool ReadModIcon(const ModInfo& m, std::vector<unsigned char>& png);
bool InstallMod(const std::string& beatson, const std::string& modsDir);           // copia para a pasta Mods
bool ExtractMod(const ModInfo& m, const std::string& destDir);                     // descompacta (para jogar)
}
