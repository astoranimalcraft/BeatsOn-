#pragma once
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include "../../third_party/json.hpp"
namespace bo {
struct ModInfo {
    std::string name = "My Mod", description, author, version = "1.0.0";
    std::string icon;                 // arquivo png dentro do pacote ("icon.png")
    std::string startLevel = "Levels/Level01.level.json";
    std::string path;                 // (runtime) caminho do .beatson
};
inline void to_json(nlohmann::json& j, const ModInfo& m){
    j = {{"format",1},{"name",m.name},{"description",m.description},{"author",m.author},{"version",m.version},{"icon",m.icon},{"startLevel",m.startLevel}}; }
inline void from_json(const nlohmann::json& j, ModInfo& m){
    m.name=j.value("name",std::string("Mod")); m.description=j.value("description",std::string());
    m.author=j.value("author",std::string()); m.version=j.value("version",std::string("1.0.0"));
    m.icon=j.value("icon",std::string()); m.startLevel=j.value("startLevel",std::string()); }
} // namespace bo
