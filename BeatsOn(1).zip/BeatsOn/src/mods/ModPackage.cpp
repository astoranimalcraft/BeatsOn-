#include "ModPackage.h"
#include <miniz.h>
namespace bo {
namespace fs = std::filesystem;
static std::string Slash(std::string s) { std::replace(s.begin(), s.end(), '\\', '/'); return s; }

bool ExportMod(const ExportOptions& o, std::string& err) {
    if (o.info.name.empty()) { err = "O mod precisa de um nome."; return false; }
    fs::create_directories(fs::path(o.outFile).parent_path());
    mz_zip_archive z{}; if (!mz_zip_writer_init_file(&z, o.outFile.c_str(), 0)) { err = "Nao foi possivel criar " + o.outFile; return false; }
    ModInfo info = o.info; info.icon = ""; bool ok = true;
    if (!o.iconPng.empty() && fs::exists(o.iconPng)) { ok &= mz_zip_writer_add_file(&z, "icon.png", o.iconPng.c_str(), nullptr, 0, MZ_DEFAULT_LEVEL) != 0; info.icon = "icon.png"; }
    for (const char* dir : { "Levels", "Scenes", "Songs", "Assets", "Scripts" }) {
        fs::path root = fs::path(o.projectDir) / dir; if (!fs::exists(root)) continue;
        for (auto& e : fs::recursive_directory_iterator(root)) { if (!e.is_regular_file()) continue; std::string rel = Slash(fs::relative(e.path(), o.projectDir).string());
            if (std::string(dir) == "Scripts") { bool src = e.path().extension() == ".cs" || e.path().extension() == ".csproj"; bool inObj = rel.find("/obj/") != std::string::npos; bool isDll = rel.find("/bin/") != std::string::npos && e.path().extension() == ".dll";
                if (inObj || (!isDll && !(src && o.includeScriptSources))) continue; }
            ok &= mz_zip_writer_add_file(&z, rel.c_str(), e.path().string().c_str(), nullptr, 0, MZ_DEFAULT_LEVEL) != 0; } }
    std::string js = nlohmann::json(info).dump(2); ok &= mz_zip_writer_add_mem(&z, "mod.json", js.data(), js.size(), MZ_DEFAULT_LEVEL) != 0;
    ok &= mz_zip_writer_finalize_archive(&z) != 0; mz_zip_writer_end(&z); if (!ok) err = "Erro ao escrever o pacote."; return ok; }

static bool ReadEntry(const std::string& zipPath, const char* name, std::vector<unsigned char>& out) {
    mz_zip_archive z{}; if (!mz_zip_reader_init_file(&z, zipPath.c_str(), 0)) return false; size_t sz = 0; void* p = mz_zip_reader_extract_file_to_heap(&z, name, &sz, 0);
    bool ok = p != nullptr; if (ok) out.assign((unsigned char*)p, (unsigned char*)p + sz); mz_free(p); mz_zip_reader_end(&z); return ok; }

std::vector<ModInfo> ListMods(const std::string& dir) {
    std::vector<ModInfo> r; if (!fs::exists(dir)) return r;
    for (auto& e : fs::directory_iterator(dir)) { if (e.path().extension() != ".beatson") continue; std::vector<unsigned char> b; if (!ReadEntry(e.path().string(), "mod.json", b)) continue;
        try { ModInfo m = nlohmann::json::parse(b.begin(), b.end()).get<ModInfo>(); m.path = e.path().string(); r.push_back(m); } catch (...) {} }
    std::sort(r.begin(), r.end(), [](auto& a, auto& b) { return a.name < b.name; }); return r; }
bool ReadModIcon(const ModInfo& m, std::vector<unsigned char>& png) { return !m.icon.empty() && ReadEntry(m.path, m.icon.c_str(), png); }
bool InstallMod(const std::string& src, const std::string& dir) { std::error_code ec; fs::create_directories(dir, ec); fs::copy_file(src, fs::path(dir) / fs::path(src).filename(), fs::copy_options::overwrite_existing, ec); return !ec; }
bool ExtractMod(const ModInfo& m, const std::string& dest) {
    mz_zip_archive z{}; if (!mz_zip_reader_init_file(&z, m.path.c_str(), 0)) return false; fs::create_directories(dest); bool ok = true;
    for (mz_uint i = 0; i < mz_zip_reader_get_num_files(&z); ++i) { if (mz_zip_reader_is_file_a_directory(&z, i)) continue; char name[512]; mz_zip_reader_get_filename(&z, i, name, 512);
        std::string n = name; if (n.find("..") != std::string::npos || (!n.empty() && (n[0] == '/' || n[0] == '\\')) || (n.size() > 1 && n[1] == ':')) continue;   // anti zip-slip
        fs::path out = fs::path(dest) / n; fs::create_directories(out.parent_path()); ok &= mz_zip_reader_extract_to_file(&z, i, out.string().c_str(), 0) != 0; }
    mz_zip_reader_end(&z); return ok; }
}
