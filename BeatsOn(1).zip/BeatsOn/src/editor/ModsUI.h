#pragma once
// Janela "Mods": lista os .beatson exportados/instalados (com icone, nome, criador, descricao). Compartilhada por Editor e GamePlay.
#include "../mods/ModPackage.h"
#include "../engine/Renderer.h"
#include "../engine/Platform.h"
#include <imgui.h>
#include "IconsFontAwesome6.h"
namespace bo {
struct ModsState { std::vector<ModInfo> mods; std::map<std::string, GpuTexture*> icons; bool dirty = true; int selected = -1; };
inline void DrawModsContent(Renderer& r, ModsState& st, const std::string& modsDir, HWND hwnd, const std::function<void(const ModInfo&)>& onPlay) {
    if (st.dirty) { st.mods = ListMods(modsDir); st.dirty = false; for (auto& m : st.mods) if (!st.icons.count(m.path)) { std::vector<unsigned char> png; st.icons[m.path] = ReadModIcon(m, png) ? r.CreateTextureFromMemory(png.data(), png.size()) : nullptr; } }
    if (ImGui::Button(ICON_FA_ROTATE " Atualizar")) st.dirty = true; ImGui::SameLine();
    if (ImGui::Button(ICON_FA_FILE_IMPORT " Instalar .beatson...")) { auto f = OpenFileDialog(hwnd, L"Mod BeatsOn!\0*.beatson\0"); if (!f.empty()) { InstallMod(f, modsDir); st.dirty = true; } }
    ImGui::SameLine(); ImGui::TextDisabled("%s", modsDir.c_str()); ImGui::Separator();
    if (st.mods.empty()) { ImGui::Spacing(); ImGui::TextDisabled("Nenhum mod instalado. Exporte um pelo Editor (File > Export Mod) ou instale um .beatson."); return; }
    ImGui::BeginChild("modlist", { 0,0 }, false);
    for (int i = 0; i < (int)st.mods.size(); ++i) { auto& m = st.mods[i]; ImGui::PushID(i); ImGui::BeginChild("card", { 0, 92 }, ImGuiChildFlags_Borders); ImVec2 p = ImGui::GetCursorScreenPos(); auto* dl = ImGui::GetWindowDrawList();
        if (auto* t = st.icons[m.path]) ImGui::Image((ImTextureID)r.ImGuiHandle(t).ptr, { 72, 72 }); else { dl->AddRectFilled(p, { p.x + 72, p.y + 72 }, IM_COL32(60, 48, 110, 255), 10); dl->AddText(nullptr, 34, { p.x + 22, p.y + 18 }, IM_COL32(200, 180, 255, 255), ICON_FA_MUSIC); ImGui::Dummy({ 72, 72 }); }
        ImGui::SameLine(); ImGui::BeginGroup(); ImGui::Text("%s  v%s", m.name.c_str(), m.version.c_str()); ImGui::TextDisabled("por %s", m.author.empty() ? "(sem autor)" : m.author.c_str()); ImGui::TextWrapped("%s", m.description.c_str()); ImGui::EndGroup();
        if (onPlay) { ImGui::SameLine(ImGui::GetContentRegionMax().x - 90); if (ImGui::Button(ICON_FA_PLAY " Jogar", { 84, 34 })) onPlay(m); }
        ImGui::EndChild(); ImGui::PopID(); }
    ImGui::EndChild(); }
}
