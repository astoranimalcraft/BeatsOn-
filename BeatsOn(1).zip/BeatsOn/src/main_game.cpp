// BeatsOn! GamePlay: menu principal, Play, Mods.
#include "engine/Application.h"
#include "game/GameRuntime.h"
#include "game/Project.h"
#include "editor/ModsUI.h"
using namespace bo;
class GameApp : public Application {
    enum class Screen { Menu, Mods, Playing } screen = Screen::Menu;
    std::unique_ptr<GameRuntime> rt; ViewportTarget vp; ModsState mods; fs::path projectDir, modsDir;
    bool OnInit() override {
        projectDir = exeDir / "Projects" / "Default"; modsDir = exeDir / "Mods"; fs::create_directories(modsDir);
        if (!fs::exists(projectDir / "project.json")) CreateDefaultProject(projectDir, exeDir / "assets" / "Example" / "ExampleScripts.cs");
        rt = std::make_unique<GameRuntime>(renderer, *audio, &scripts, window.input); return true; }
    void Start(const fs::path& root, const std::string& level) { if (rt->LoadLevel(root.string(), level)) screen = Screen::Playing; }
    void OnUpdate(float dt) override {
        if (screen != Screen::Playing) return;
        if (window.input.Pressed(VK_ESCAPE)) { rt->Stop(); screen = Screen::Menu; return; }
        rt->Update(dt); if (rt->Finished()) { screen = Screen::Menu; } }
    void OnGui() override {
        ImVec2 ds = ImGui::GetIO().DisplaySize;
        if (screen == Screen::Playing) { rt->DrawHud(ImGui::GetBackgroundDrawList(), { 0,0 }, ds); return; }
        auto* dl = ImGui::GetBackgroundDrawList(); dl->AddRectFilledMultiColor({ 0,0 }, ds, IM_COL32(20, 14, 42, 255), IM_COL32(40, 20, 70, 255), IM_COL32(10, 30, 60, 255), IM_COL32(12, 10, 30, 255));
        ImGui::SetNextWindowPos({ ds.x * 0.5f, ds.y * 0.5f }, ImGuiCond_Always, { 0.5f, 0.5f }); ImGui::SetNextWindowSize({ screen == Screen::Mods ? ds.x * 0.7f : 380.f, screen == Screen::Mods ? ds.y * 0.8f : 360.f });
        ImGui::Begin("##menu", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
        if (screen == Screen::Menu) {
            if (fontBig) ImGui::PushFont(fontBig); ImGui::SetCursorPosX((380 - ImGui::CalcTextSize("BeatsOn!").x) * 0.5f); ImGui::TextColored({ 0.65f, 0.5f, 1, 1 }, "BeatsOn!"); if (fontBig) ImGui::PopFont(); ImGui::Spacing(); ImGui::Spacing();
            ImVec2 b{ -1, 54 }; if (ImGui::Button(ICON_FA_PLAY "  Jogar", b)) Start(projectDir, "Levels/Level01.level.json"); if (ImGui::Button(ICON_FA_PUZZLE_PIECE "  Mods", b)) { screen = Screen::Mods; mods.dirty = true; }
            if (ImGui::Button(ICON_FA_RIGHT_FROM_BRACKET "  Sair", b)) PostQuitMessage(0); ImGui::Spacing(); ImGui::TextDisabled("Teclas: D F J K  ou  setas  |  Esc = voltar");
        } else {
            if (ImGui::Button(ICON_FA_ARROW_LEFT " Voltar")) screen = Screen::Menu; ImGui::SameLine(); ImGui::Text("Mods"); ImGui::Separator();
            DrawModsContent(renderer, mods, modsDir.string(), window.Handle(), [&](const ModInfo& m) { fs::path cache = modsDir / "_cache" / fs::path(m.path).stem(); std::error_code ec; fs::remove_all(cache, ec);
                if (ExtractMod(m, cache.string())) Start(cache, m.startLevel); else Log("[Mods] falha ao abrir %s", m.name.c_str()); }); }
        ImGui::End(); }
    void OnRender() override {
        if (screen != Screen::Playing) return; renderer.CreateViewport(vp, window.Width(), window.Height()); rt->Render(vp); renderer.BlitToBackbuffer(vp); }
};
int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) { GameApp app; return app.Run(L"BeatsOn!", 1280, 720, false); }
