#include "GameRuntime.h"
namespace bo {
static const ImU32 kLaneCol[4] = { IM_COL32(194,75,153,255), IM_COL32(0,229,255,255), IM_COL32(18,250,5,255), IM_COL32(249,57,63,255) };
static const float kLaneAng[4] = { 3.14159265f, 1.5707963f, -1.5707963f, 0.f };   // esquerda, baixo, cima, direita

void GameRuntime::SetupContext() {
    ctx = {}; ctx.scene = &scene; ctx.camera = &camera; ctx.session = &session; ctx.audio = &audio; ctx.input = &input; ctx.assetRoot = root;
    ctx.loadLevel = [this](const std::string& l) { pendingLevel = l; };
    ctx.endSong = [this]() { session.NotifyAudioEnded(); };
    ctx.songTimeMs = [this]() { return songMs; };
    ctx.strumPulse = [this](int s, int l, bool p) { Pulse(s, l, p); };
    ScriptApi_SetContext(&ctx); }

bool GameRuntime::LoadLevel(const std::string& projectRoot, const std::string& levelRel) {
    Stop(); root = projectRoot; renderer.SetAssetRoot(root);
    if (!bo::LoadLevel(level, root + "/" + levelRel)) { Log("[Game] level nao encontrado: %s", levelRel.c_str()); return false; }
    if (level.scene.empty() || !scene.Load(root + "/" + level.scene)) scene.BuildDefault();
    if (auto* c = scene.GameplayCamera()) camera.Bind(*c);     // a camera da cena = os olhos do jogador
    for (const char* n : { "Boyfriend", "Opponent" }) if (auto* e = scene.FindByName(n)) if (e->animator) e->animator->onFinished = [e](const std::string&) { e->animator->Play("idle"); };
    SetupContext();
    if (scripts && scripts->Ready()) {
        scripts->Clear();
        if (loadedAsmRoot != root) { fs::path dll = fs::path(root) / "Scripts" / "bin" / "GameScripts.dll"; if (fs::exists(dll) && scripts->LoadUserAssembly(dll.string())) loadedAsmRoot = root; }
        for (auto& s : level.scripts) scripts->Activate(s);
        scripts->cb.OnLevelLoad(level.name.c_str()); }
    songIndex = 0; running = true; finished = false; pendingLevel.clear(); pendingNext = false; sceneTime = 0; StartSong(0); return true; }

void GameRuntime::StartSong(int i) {
    if (i >= (int)level.songs.size()) { running = false; finished = true; return; }
    const SongData& s = level.songs[i]; audio.Stop(); audioStarted = false; clockMs = -countdownMs; songMs = clockMs;
    if (!s.audio.empty()) { if (!audio.Load(root + "/" + s.audio)) Log("[Audio] falhou: %s", s.audio.c_str()); }
    session.botplay = botplay; session.Start(s, this); memset(strumPulse, 0, sizeof strumPulse); }
void GameRuntime::Stop() { audio.Stop(); running = false; }

void GameRuntime::Update(float dt) {
    if (!running) return; sceneTime += dt; clockMs += dt * 1000.0;
    if (!audioStarted && clockMs >= 0) { audio.Seek(0); audio.Play(); audioStarted = true; }
    if (audioStarted && audio.IsPlaying()) { double a = audio.PositionMs(); clockMs = std::abs(a - clockMs) > 40 ? a : clockMs + (a - clockMs) * 0.25; }
    songMs = clockMs; if (audioStarted && audio.IsFinished()) session.NotifyAudioEnded();
    InputFrame f; for (int l = 0; l < 4; ++l) { bool d = input.Down(keys[0][l]) || input.Down(keys[1][l]), p = input.Pressed(keys[0][l]) || input.Pressed(keys[1][l]);
        f.down[l] = d; f.pressed[l] = p; f.released[l] = !d; if (p) Pulse(0, l, true); }
    session.botplay = botplay; session.Update(songMs, f);
    if (scripts && scripts->Ready()) scripts->cb.OnUpdate(dt);
    camera.Update(dt, scene); scene.Update(dt);
    for (auto& s : strumPulse) for (float& v : s) v = std::max(0.f, v - dt * 5.f);
    for (int s = 0; s < 2; ++s) { charPulse[s] = std::max(0.f, charPulse[s] - dt * 4.f); if (auto* e = scene.FindByName(s ? "Opponent" : "Boyfriend")) { float k = 1.f + 0.06f * charPulse[s]; e->transform.scale = { k, k, 1 }; } }
    lastJudge.t += dt; ApplyPending(); }

void GameRuntime::ApplyPending() {
    if (pendingNext) { pendingNext = false; ++songIndex; if (songIndex < (int)level.songs.size()) StartSong(songIndex); else if (!level.nextLevel.empty()) pendingLevel = level.nextLevel; else { running = false; finished = true; } }
    if (!pendingLevel.empty()) { std::string l = pendingLevel; pendingLevel.clear(); LoadLevel(root, l); } }

void GameRuntime::Render(ViewportTarget& vt) {
    RenderView rv; rv.view = camera.View(); rv.proj = camera.Proj((float)vt.w / std::max(1u, vt.h)); rv.camPos = camera.Position(); rv.post = camera.GetPost(); rv.time = sceneTime; rv.drawGrid = false;
    renderer.RenderScene(scene, rv, vt); }

// ---------------- eventos -> scripts + visuais padrao
#define SCR(call) if (scripts && scripts->Ready()) scripts->cb.call
void GameRuntime::Pulse(int side, int lane, bool) { if (lane >= 0 && lane < 8) strumPulse[side][lane] = 1.f; }
void GameRuntime::OnSongStart(const SongData& s) { SCR(OnSongStart(s.name.c_str())); }
void GameRuntime::OnSongEnd(const SongData& s) { SCR(OnSongEnd(s.name.c_str())); pendingNext = true; }
void GameRuntime::OnBeat(int b) { if (autoBop && b % 4 == 0) camera.ZoomPunch(0.025f, 0.3f); SCR(OnBeat(b)); }
void GameRuntime::OnStep(int s) { SCR(OnStep(s)); }
void GameRuntime::OnNoteSpawn(const NoteRuntime& n) { SCR(OnNoteSpawn(n.d.side, n.d.lane, n.d.time)); }
void GameRuntime::OnNoteReachStrum(const NoteRuntime& n) {      // a seta encostou na seta principal
    if (n.d.side == 1) { Pulse(1, n.d.lane, true); charPulse[1] = 1.f; if (auto* e = scene.FindByName("Opponent")) if (e->animator) { static const char* d[] = { "sing_left","sing_down","sing_up","sing_right" }; e->animator->Play(d[n.d.lane & 3]); } }
    SCR(OnNoteReachStrum(n.d.side, n.d.lane, n.d.time, n.index)); }
void GameRuntime::OnNoteHit(const NoteRuntime& n, Judgement j, double d) {
    if (n.d.side == 0) { Pulse(0, n.d.lane, true); charPulse[0] = 1.f; lastJudge = { j, 0 }; if (auto* e = scene.FindByName("Boyfriend")) if (e->animator) { static const char* dn[] = { "sing_left","sing_down","sing_up","sing_right" }; e->animator->Play(dn[n.d.lane & 3]); } }
    SCR(OnNoteHit(n.d.side, n.d.lane, (int)j, d)); }
void GameRuntime::OnNoteMiss(const NoteRuntime& n) { lastJudge = { Judgement::Miss, 0 }; SCR(OnNoteMiss(n.d.side, n.d.lane)); }
void GameRuntime::OnGhostTap(int l) { SCR(OnGhostTap(l)); }
void GameRuntime::OnScriptEvent(const std::string& n, const std::string& a) { SCR(OnEvent(n.c_str(), a.c_str())); }

// ---------------- HUD (setas)
static void Arrow(ImDrawList* dl, ImVec2 c, float s, float ang, ImU32 col, bool outline, float thick = 3.f) {
    float ca = cosf(ang), sa = sinf(ang); auto P = [&](float x, float y) { return ImVec2(c.x + (x * ca - y * sa) * s * 0.5f, c.y + (x * sa + y * ca) * s * 0.5f); };
    ImVec2 head[3] = { P(0.95f,0), P(0.05f,-0.85f), P(0.05f,0.85f) }; ImVec2 body[4] = { P(-0.85f,-0.38f), P(0.05f,-0.38f), P(0.05f,0.38f), P(-0.85f,0.38f) };
    if (outline) { dl->AddConvexPolyFilled(head, 3, col); dl->AddConvexPolyFilled(body, 4, col); }
    else { dl->AddConvexPolyFilled(head, 3, col); dl->AddConvexPolyFilled(body, 4, col); dl->AddPolyline(head, 3, IM_COL32(255,255,255,200), ImDrawFlags_Closed, thick * 0.5f); } }
void GameRuntime::DrawHud(ImDrawList* dl, ImVec2 pos, ImVec2 size) {
    if (!running && !finished) return; float W = size.x, H = size.y, as = std::min(W / 11.f, H / 8.f), strumY = pos.y + H * 0.14f, pxPerMs = (H * 0.78f) / (float)session.approachMs;
    auto laneX = [&](int side, int lane) { return pos.x + W * (side == 0 ? 0.74f : 0.26f) + (lane - 1.5f) * as * 1.18f; };
    for (int side = 0; side < 2; ++side) for (int l = 0; l < session.song.keyCount && l < 4; ++l) {
        float p = strumPulse[side][l]; ImU32 base = IM_COL32(70, 70, 90, 220); Arrow(dl, { laneX(side, l), strumY }, as * (1.f + 0.12f * p), kLaneAng[l], base, true);
        if (p > 0) { ImU32 c = (kLaneCol[l] & 0x00FFFFFF) | ((ImU32)(255 * p) << 24); Arrow(dl, { laneX(side, l), strumY }, as * (1.f + 0.12f * p), kLaneAng[l], c, true); } }
    for (auto& n : session.notes) {
        if (!n.spawned || n.d.lane > 3) continue; if (n.hit && n.d.sustain <= 0) continue; float x = laneX(n.d.side, n.d.lane);
        float y = strumY + (float)(n.d.time - songMs) * pxPerMs; float len = (float)n.d.sustain * pxPerMs; if (y > pos.y + H + as) continue; if (y + len < strumY - as) continue;
        ImU32 col = kLaneCol[n.d.lane]; if (n.missed || n.dropped) col = (col & 0x00FFFFFF) | (90u << 24);
        if (len > 0) { float top = std::max(y, strumY); dl->AddRectFilled({ x - as * 0.13f, top }, { x + as * 0.13f, y + len }, (col & 0x00FFFFFF) | (170u << 24), as * 0.1f); }
        if (!n.hit) Arrow(dl, { x, y }, as, kLaneAng[n.d.lane], col, false); }
    // vida, score, julgamento
    float bw = W * 0.4f, bx = pos.x + (W - bw) * 0.5f, by = pos.y + H * 0.95f; dl->AddRectFilled({ bx, by }, { bx + bw, by + 12 }, IM_COL32(220, 40, 60, 255), 6); dl->AddRectFilled({ bx + bw * (1 - session.health), by }, { bx + bw, by + 12 }, IM_COL32(60, 220, 120, 255), 6); dl->AddRect({ bx, by }, { bx + bw, by + 12 }, IM_COL32(0,0,0,255), 6, 0, 2);
    char buf[128]; snprintf(buf, sizeof buf, "Score: %d   Combo: %d   Acc: %.1f%%   Misses: %d", session.score, session.combo, session.Accuracy() * 100.f, session.counts[4]); dl->AddText({ bx, by + 16 }, IM_COL32(255, 255, 255, 230), buf);
    if (lastJudge.t < 0.7f) { ImU32 a = (ImU32)(255 * (1.f - lastJudge.t / 0.7f)); dl->AddText(nullptr, as * 0.5f, { pos.x + W * 0.74f - as, pos.y + H * 0.5f - lastJudge.t * 20 }, IM_COL32(255, 255, 255, 0) | (a << 24) | 0x00FFFFFF, JudgementName(lastJudge.j)); }
    if (songMs < 0) { snprintf(buf, sizeof buf, "%d", (int)std::ceil(-songMs / 666.0)); dl->AddText(nullptr, as * 1.4f, { pos.x + W * 0.5f - as * 0.3f, pos.y + H * 0.4f }, IM_COL32(255, 255, 255, 230), buf); }
}
}
