#pragma once
// BeatsOn! - runtime de uma fase: carrega Level + Cena, toca a musica, roda GameSession, encaminha eventos para scripts C#,
// desenha HUD (setas) e controla a camera do jogador. Usado pelo GamePlay e pelo botao "Play" do Editor.
#include "GameSession.h"
#include "../engine/Renderer.h"
#include "../engine/Audio.h"
#include "../engine/Platform.h"
#include "../scripting/ScriptHost.h"
#include "../scripting/ScriptContext.h"
#include <imgui.h>
namespace bo {
class GameRuntime : public IGameEvents {
public:
    GameRuntime(Renderer& r, AudioEngine& a, ScriptHost* host, Input& in) : renderer(r), audio(a), scripts(host), input(in) {}
    bool LoadLevel(const std::string& projectRoot, const std::string& levelRel);   // levelRel: "Levels/Level01.level.json"
    void StartSong(int index);
    void Update(float dt);
    void Render(ViewportTarget& vt);
    void DrawHud(ImDrawList* dl, ImVec2 pos, ImVec2 size);
    void Stop();
    bool Running() const { return running; } bool Finished() const { return finished; }
    // estado
    Scene scene; CameraRig camera; GameSession session; LevelData level; std::string root; bool botplay = false; bool autoBop = true;
    int keys[2][4] = { { 'D','F','J','K' }, { VK_LEFT, VK_DOWN, VK_UP, VK_RIGHT } };
    double SongMs() const { return songMs; }
    // IGameEvents
    void OnSongStart(const SongData&) override; void OnSongEnd(const SongData&) override; void OnBeat(int) override; void OnStep(int) override;
    void OnNoteSpawn(const NoteRuntime&) override; void OnNoteReachStrum(const NoteRuntime&) override; void OnNoteHit(const NoteRuntime&, Judgement, double) override;
    void OnNoteMiss(const NoteRuntime&) override; void OnGhostTap(int) override; void OnScriptEvent(const std::string&, const std::string&) override;
private:
    void Pulse(int side, int lane, bool pressed); void SetupContext(); void ApplyPending();
    Renderer& renderer; AudioEngine& audio; ScriptHost* scripts; Input& input; ScriptContext ctx;
    int songIndex = 0; double songMs = 0, clockMs = 0; bool running = false, finished = false, audioStarted = false; double countdownMs = 2000;
    float strumPulse[2][8] = {}; float charPulse[2] = {}; std::string pendingLevel; bool pendingNext = false;
    struct Pop { Judgement j; float t; } lastJudge{ Judgement::Sick, 99 }; std::string loadedAsmRoot; float sceneTime = 0;
};
}
