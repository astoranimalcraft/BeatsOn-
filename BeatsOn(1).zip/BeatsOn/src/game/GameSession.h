#pragma once
// BeatsOn! - logica de gameplay (julgamento, combo, vida, eventos). Sem dependencia de plataforma.
#include "Chart.h"
#include <algorithm>
#include <cmath>

namespace bo {

enum class Judgement { Sick, Good, Bad, Shit, Miss };
inline const char* JudgementName(Judgement j){ static const char* n[]={"Sick!!","Good","Bad","Shit","Miss"}; return n[(int)j]; }

struct NoteRuntime {
    NoteData d; int index = 0;
    bool spawned=false, reachedStrum=false, hit=false, missed=false, holding=false, dropped=false;
};

// Callbacks que a engine/scripts C# recebem. "O que acontece quando a seta chega na seta principal" = OnNoteReachStrum.
struct IGameEvents {
    virtual ~IGameEvents() = default;
    virtual void OnSongStart(const SongData&) {}
    virtual void OnSongEnd(const SongData&) {}
    virtual void OnBeat(int /*beat*/) {}
    virtual void OnStep(int /*step*/) {}
    virtual void OnNoteSpawn(const NoteRuntime&) {}
    virtual void OnNoteReachStrum(const NoteRuntime&) {}                    // a seta encostou na seta fixa
    virtual void OnNoteHit(const NoteRuntime&, Judgement, double /*deltaMs*/) {}
    virtual void OnNoteMiss(const NoteRuntime&) {}
    virtual void OnGhostTap(int /*lane*/) {}                                // apertou sem nota
    virtual void OnSustainDrop(const NoteRuntime&) {}
    virtual void OnScriptEvent(const std::string& /*name*/, const std::string& /*arg*/) {}
    virtual void OnHealthChanged(float /*health*/) {}
};

struct InputFrame { bool down[8]={}, pressed[8]={}, released[8]={}; };   // por lane do jogador

class GameSession {
public:
    // janelas de acerto (ms), estilo FNF
    double windowSick=45, windowGood=90, windowBad=135, windowShit=160;
    double approachMs = 1800;   // quanto tempo antes a nota aparece (derivado do scrollSpeed)
    bool   botplay = false;

    void Start(const SongData& s, IGameEvents* ev) {
        song = s; events = ev; ended = false; audioEnded = false;
        score=0; combo=0; maxCombo=0; health=0.5f; counts[0]=counts[1]=counts[2]=counts[3]=counts[4]=0;
        lastBeat=-1; lastStep=-1; nextEvent=0;
        approachMs = 1800.0 / std::max(0.25f, s.scrollSpeed) ;
        notes.clear(); notes.reserve(s.notes.size());
        std::vector<NoteData> sorted = s.notes;
        std::sort(sorted.begin(), sorted.end(), [](auto&a, auto&b){return a.time<b.time;});
        for (size_t i=0;i<sorted.size();++i){ NoteRuntime n; n.d=sorted[i]; n.index=(int)i; notes.push_back(n); }
        evs = s.events; std::sort(evs.begin(), evs.end(), [](auto&a, auto&b){return a.time<b.time;});
        if (events) events->OnSongStart(song);
    }
    void NotifyAudioEnded() { audioEnded = true; }

    void Update(double songMs, const InputFrame& in) {
        if (!events || ended) return;
        const double stepMs = 60000.0 / song.bpm / 4.0;
        int step = (int)std::floor((songMs - song.offsetMs) / stepMs);
        if (songMs >= song.offsetMs) {
            while (lastStep < step) { ++lastStep; events->OnStep(lastStep); int b = lastStep/4;
                if (lastStep%4==0 && b != lastBeat) { lastBeat=b; events->OnBeat(b); } }
        }
        while (nextEvent < evs.size() && evs[nextEvent].time <= songMs) { events->OnScriptEvent(evs[nextEvent].name, evs[nextEvent].arg); ++nextEvent; }

        // 1) spawn / chegou na seta / oponente toca sozinho / miss
        for (auto& n : notes) {
            if (!n.spawned && songMs >= n.d.time - approachMs) { n.spawned=true; events->OnNoteSpawn(n); }
            if (n.spawned && !n.reachedStrum && songMs >= n.d.time) {
                n.reachedStrum = true; events->OnNoteReachStrum(n);
                if (n.d.side == 1 || (botplay && n.d.side == 0)) { RegisterHit(n, Judgement::Sick, 0); }
            }
            if (!n.hit && !n.missed && n.d.side == 0 && songMs - n.d.time > windowShit) { RegisterMiss(n); }
        }
        // 2) input do jogador
        for (int lane = 0; lane < song.keyCount && lane < 8; ++lane) {
            if (in.pressed[lane]) {
                NoteRuntime* best = nullptr; double bestAbs = 1e18;
                for (auto& n : notes) {
                    if (n.d.side!=0 || n.d.lane!=lane || n.hit || n.missed) continue;
                    double d = std::abs(songMs - n.d.time);
                    if (d <= windowShit && d < bestAbs) { best=&n; bestAbs=d; }
                }
                if (best) { double delta = songMs - best->d.time; RegisterHit(*best, Classify(std::abs(delta)), delta); }
                else { events->OnGhostTap(lane); }
            }
            // sustains
            for (auto& n : notes) {
                if (n.d.side!=0 || n.d.lane!=lane || !n.holding || n.d.sustain<=0) continue;
                if (songMs >= n.d.time + n.d.sustain) { n.holding=false; }
                else if (!in.down[lane] && !botplay) { n.holding=false; n.dropped=true; combo=0; events->OnSustainDrop(n); AddHealth(-0.04f); }
                else score += 2;
            }
        }
        // 3) fim da musica
        if (audioEnded || (!notes.empty() && songMs > notes.back().d.time + notes.back().d.sustain + 2500 && song.audio.empty())) {
            ended = true; events->OnSongEnd(song);
        }
    }

    Judgement Classify(double absDelta) const {
        return absDelta<=windowSick?Judgement::Sick : absDelta<=windowGood?Judgement::Good : absDelta<=windowBad?Judgement::Bad : Judgement::Shit; }

    float Accuracy() const { int tot=counts[0]+counts[1]+counts[2]+counts[3]+counts[4]; if(!tot) return 1.f;
        return (counts[0]*1.0f+counts[1]*0.75f+counts[2]*0.4f+counts[3]*0.1f)/tot; }

    SongData song; std::vector<NoteRuntime> notes; std::vector<ScriptEventData> evs;
    int score=0, combo=0, maxCombo=0, counts[5]={}; float health=0.5f; bool ended=false;
private:
    void AddHealth(float d){ health=std::clamp(health+d,0.f,1.f); if(events) events->OnHealthChanged(health); }
    void RegisterHit(NoteRuntime& n, Judgement j, double delta){
        n.hit=true; n.holding = n.d.sustain>0;
        if (n.d.side==0) {
            counts[(int)j]++; combo++; maxCombo=std::max(maxCombo,combo);
            static const int pts[]={350,200,100,50,0}; score += pts[(int)j];
            AddHealth(j==Judgement::Sick?0.023f : j==Judgement::Good?0.012f : j==Judgement::Bad?0.0f : -0.03f);
        }
        events->OnNoteHit(n, j, delta);
    }
    void RegisterMiss(NoteRuntime& n){ n.missed=true; counts[4]++; combo=0; AddHealth(-0.06f); events->OnNoteMiss(n); }
    IGameEvents* events=nullptr; int lastBeat=-1,lastStep=-1; size_t nextEvent=0; bool audioEnded=false;
};

} // namespace bo
