#pragma once
// Projeto padrao (pasta com Levels/ Scenes/ Songs/ Assets/ Scripts/) usado pelo Editor e pelo GamePlay.
#include "Chart.h"
#include "../engine/Scene.h"
namespace bo {
inline void CreateDefaultProject(const fs::path& dir, const fs::path& exampleScript) {
    for (auto d : { "Levels", "Scenes", "Songs", "Assets", "Scripts" }) fs::create_directories(dir / d);
    Scene s; s.BuildDefault(); s.Save((dir / "Scenes/Default.scene.json").string());
    LevelData L; L.name = "Level 01"; L.scene = "Scenes/Default.scene.json"; L.scripts = { "Example.CameraBop" }; SongData song; song.name = "Demo (sem audio)"; song.bpm = 120; song.scrollSpeed = 2.f;
    double beat = 60000.0 / song.bpm; for (int b = 4; b < 40; ++b) { song.notes.push_back({ b * beat, b % 4, 1, 0, "normal" }); if (b % 2) song.notes.push_back({ (b + 0.5) * beat, (b * 3) % 4, 0, 0, "normal" }); }
    song.events.push_back({ 16 * beat, "zoom", "1.15" }); song.events.push_back({ 24 * beat, "zoom", "1.0" }); L.songs.push_back(song); SaveLevel(L, (dir / "Levels/Level01.level.json").string());
    std::ofstream(dir / "project.json") << R"({"name":"Default","startLevel":"Levels/Level01.level.json"})";
    std::ofstream(dir / "Scripts/GameScripts.csproj") << R"(<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><TargetFramework>net8.0</TargetFramework><AssemblyName>GameScripts</AssemblyName><EnableDefaultCompileItems>true</EnableDefaultCompileItems><BaseOutputPath>bin\</BaseOutputPath></PropertyGroup>
  <ItemGroup><Reference Include="BeatsOn.Scripting"><HintPath>$(BeatsOnDir)\BeatsOn.Scripting.dll</HintPath><Private>false</Private></Reference></ItemGroup>
</Project>)";
    std::error_code ec; if (fs::exists(exampleScript)) fs::copy_file(exampleScript, dir / "Scripts/ExampleScripts.cs", fs::copy_options::skip_existing, ec); }
}
