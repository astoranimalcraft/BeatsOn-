#pragma once
// BeatsOn! - dados de musica / level (serializados em JSON). Sem dependencia de plataforma.
#include <string>
#include <vector>
#include <fstream>
#include "../../third_party/json.hpp"

namespace bo {

struct NoteData {
    double time = 0;          // ms
    int    lane = 0;          // 0..keyCount-1
    int    side = 0;          // 0 = jogador, 1 = oponente
    double sustain = 0;       // ms (0 = nota normal)
    std::string type = "normal"; // "normal", "mine", "script"...
};
struct ScriptEventData { double time = 0; std::string name; std::string arg; };

struct SongData {
    std::string name = "New Song", artist, audio;   // audio: caminho relativo ao projeto (.mp3 .wav .ogg .flac)
    double bpm = 120.0;
    double offsetMs = 0;
    int    keyCount = 4;
    float  scrollSpeed = 2.0f;
    std::vector<NoteData> notes;
    std::vector<ScriptEventData> events;
};

struct LevelData {
    std::string name = "New Level";
    std::string scene = "Scenes/Default.scene.json";
    std::vector<std::string> scripts;   // nomes de classes C# (BeatsOnScript) ativas neste level
    std::vector<SongData> songs;        // tocadas em sequencia
    std::string nextLevel;              // carregado quando as musicas acabam ("" = volta ao menu)
};

inline void to_json(nlohmann::json& j, const NoteData& n){ j = {{"t",n.time},{"l",n.lane},{"s",n.side},{"d",n.sustain},{"k",n.type}}; }
inline void from_json(const nlohmann::json& j, NoteData& n){ n.time=j.value("t",0.0); n.lane=j.value("l",0); n.side=j.value("s",0); n.sustain=j.value("d",0.0); n.type=j.value("k",std::string("normal")); }
inline void to_json(nlohmann::json& j, const ScriptEventData& e){ j = {{"t",e.time},{"n",e.name},{"a",e.arg}}; }
inline void from_json(const nlohmann::json& j, ScriptEventData& e){ e.time=j.value("t",0.0); e.name=j.value("n",std::string()); e.arg=j.value("a",std::string()); }
inline void to_json(nlohmann::json& j, const SongData& s){
    j = {{"name",s.name},{"artist",s.artist},{"audio",s.audio},{"bpm",s.bpm},{"offsetMs",s.offsetMs},
         {"keyCount",s.keyCount},{"scrollSpeed",s.scrollSpeed},{"notes",s.notes},{"events",s.events}}; }
inline void from_json(const nlohmann::json& j, SongData& s){
    s.name=j.value("name",std::string("Song")); s.artist=j.value("artist",std::string()); s.audio=j.value("audio",std::string());
    s.bpm=j.value("bpm",120.0); s.offsetMs=j.value("offsetMs",0.0); s.keyCount=j.value("keyCount",4);
    s.scrollSpeed=j.value("scrollSpeed",2.0f);
    if(j.contains("notes")) s.notes=j["notes"].get<std::vector<NoteData>>();
    if(j.contains("events")) s.events=j["events"].get<std::vector<ScriptEventData>>(); }
inline void to_json(nlohmann::json& j, const LevelData& l){
    j = {{"name",l.name},{"scene",l.scene},{"scripts",l.scripts},{"songs",l.songs},{"nextLevel",l.nextLevel}}; }
inline void from_json(const nlohmann::json& j, LevelData& l){
    l.name=j.value("name",std::string("Level")); l.scene=j.value("scene",std::string());
    l.nextLevel=j.value("nextLevel",std::string());
    if(j.contains("scripts")) l.scripts=j["scripts"].get<std::vector<std::string>>();
    if(j.contains("songs")) l.songs=j["songs"].get<std::vector<SongData>>(); }

inline bool SaveLevel(const LevelData& l, const std::string& path){
    std::ofstream f(path); if(!f) return false; f << nlohmann::json(l).dump(2); return true; }
inline bool LoadLevel(LevelData& l, const std::string& path){
    std::ifstream f(path); if(!f) return false;
    try { l = nlohmann::json::parse(f).get<LevelData>(); } catch(...) { return false; } return true; }

} // namespace bo
