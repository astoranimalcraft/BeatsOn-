// Para suportar .ogg o miniaudio precisa do stb_vorbis (CMake adiciona o include dir do stb).
#define STB_VORBIS_HEADER_ONLY
#include <stb_vorbis.c>
#define MINIAUDIO_IMPLEMENTATION
#include <miniaudio.h>
#undef STB_VORBIS_HEADER_ONLY
#include <stb_vorbis.c>
#include "Audio.h"
namespace bo {
struct AudioEngine::Impl { ma_engine engine; bool ok = false; ma_sound music; bool hasMusic = false; };
AudioEngine::AudioEngine() : d(new Impl) { d->ok = ma_engine_init(nullptr, &d->engine) == MA_SUCCESS; }
AudioEngine::~AudioEngine() { if (d->hasMusic) ma_sound_uninit(&d->music); if (d->ok) ma_engine_uninit(&d->engine); }
bool AudioEngine::Load(const std::string& path) {
    if (!d->ok) return false; if (d->hasMusic) { ma_sound_uninit(&d->music); d->hasMusic = false; }
    d->hasMusic = ma_sound_init_from_file(&d->engine, path.c_str(), MA_SOUND_FLAG_STREAM | MA_SOUND_FLAG_NO_SPATIALIZATION, nullptr, nullptr, &d->music) == MA_SUCCESS; return d->hasMusic; }
void AudioEngine::Play() { if (d->hasMusic) ma_sound_start(&d->music); } void AudioEngine::Pause() { if (d->hasMusic) ma_sound_stop(&d->music); }
void AudioEngine::Stop() { if (d->hasMusic) { ma_sound_stop(&d->music); ma_sound_seek_to_pcm_frame(&d->music, 0); } }
void AudioEngine::Seek(double ms) { if (!d->hasMusic) return; ma_uint32 sr = ma_engine_get_sample_rate(&d->engine); ma_sound_seek_to_pcm_frame(&d->music, (ma_uint64)(ms * 0.001 * sr)); }
bool AudioEngine::IsPlaying() const { return d->hasMusic && ma_sound_is_playing(&d->music); } bool AudioEngine::IsFinished() const { return d->hasMusic && ma_sound_at_end(&d->music); }
double AudioEngine::PositionMs() const { if (!d->hasMusic) return 0; float s = 0; ma_sound_get_cursor_in_seconds(&d->music, &s); return s * 1000.0; }
double AudioEngine::LengthMs() const { if (!d->hasMusic) return 0; float s = 0; ma_sound_get_length_in_seconds(&d->music, &s); return s * 1000.0; }
void AudioEngine::SetVolume(float v) { if (d->hasMusic) ma_sound_set_volume(&d->music, v); } void AudioEngine::SetPitch(float p) { if (d->hasMusic) ma_sound_set_pitch(&d->music, p); }
void AudioEngine::PlayOneShot(const std::string& path, float vol) { if (d->ok) { ma_engine_play_sound(&d->engine, path.c_str(), nullptr); (void)vol; } }
}
