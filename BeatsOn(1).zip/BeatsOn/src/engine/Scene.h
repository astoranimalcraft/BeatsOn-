#pragma once
// BeatsOn! - Cena + Componentes (Transform, SpriteRenderer, SpriteAnimator, Camera, ModelRenderer, Light, Sky, Script)
#include "Common.h"
namespace bo {
using EntityId = uint32_t;

struct Transform {
    XMFLOAT3 position{0,0,0}, rotation{0,0,0} /*graus*/, scale{1,1,1};
    XMMATRIX Local() const {
        return XMMatrixScaling(scale.x,scale.y,scale.z) *
               XMMatrixRotationRollPitchYaw(XMConvertToRadians(rotation.x),XMConvertToRadians(rotation.y),XMConvertToRadians(rotation.z)) *
               XMMatrixTranslation(position.x,position.y,position.z); }
};

struct AnimFrame { float u, v, w, h; };           // retangulo UV no atlas
struct SpriteAnim { std::vector<AnimFrame> frames; float fps = 24; bool loop = true; };

struct SpriteRenderer {
    std::string texture;                 // caminho (png/jpg/tga) ou "builtin:white"
    XMFLOAT4 tint{1,1,1,1};
    XMFLOAT2 size{1,1};                  // tamanho em unidades do mundo
    XMFLOAT2 pivot{0.5f,0.0f};
    bool billboard = true, flipX = false, lit = false;
    int  sortOrder = 0;
    XMFLOAT4 uvRect{0,0,1,1};            // atualizado pelo animador
};

// Animacao de sprite 2D (sprite sheet). Eventos: onFinished.
struct SpriteAnimator {
    std::map<std::string, SpriteAnim> anims;
    std::string current; float time = 0; bool playing = false; int frame = 0;
    std::function<void(const std::string&)> onFinished;
    void AddGridAnimation(const std::string& name, int startFrame, int count, int cols, int rows, float fps, bool loop) {
        SpriteAnim a; a.fps = fps; a.loop = loop;
        for (int i = 0; i < count; ++i) { int f = startFrame + i; a.frames.push_back({ (f%cols)/(float)cols, (f/cols)/(float)rows, 1.f/cols, 1.f/rows }); }
        anims[name] = a; }
    void Play(const std::string& name, bool restart = true) {
        if (!anims.count(name)) return; if (current == name && playing && !restart) return;
        current = name; time = 0; frame = 0; playing = true; }
    void Update(float dt, SpriteRenderer& sr) {
        if (!playing || !anims.count(current)) return; auto& a = anims[current]; if (a.frames.empty()) return;
        time += dt; int idx = (int)(time * a.fps);
        if (idx >= (int)a.frames.size()) {
            if (a.loop) idx %= (int)a.frames.size(); else { idx = (int)a.frames.size()-1; playing = false; if (onFinished) onFinished(current); } }
        frame = idx; auto& f = a.frames[idx]; sr.uvRect = { f.u, f.v, f.w, f.h }; }
};

struct CameraComponent { float fovDeg = 50, orthoSize = 5, nearZ = 0.05f, farZ = 2000; bool ortho = false, gameplayCamera = true; };
struct ModelRenderer {
    std::string model;                    // "builtin:cube", "builtin:plane" ou arquivo fbx/obj/gltf (Assimp)
    std::string albedo, normal, orm, emissive;   // texturas PBR (orm = AO/Roughness/Metallic)
    XMFLOAT4 baseColor{1,1,1,1}; float metallic = 0, roughness = 0.6f, emissiveStrength = 0; bool castShadow = true, receiveShadow = true;
};
struct LightComponent { XMFLOAT3 color{1,0.95f,0.85f}; float intensity = 6.0f; };   // luz direcional (sol)
struct SkyComponent {
    bool procedural = true; std::string hdri;            // HDRI equirretangular (.hdr/.exr)
    float sunElevation = 40, sunAzimuth = 35;             // graus
    float cloudCover = 0.55f, cloudDensity = 1.0f, hdriIntensity = 1.0f;
};
struct ScriptComponent { std::vector<std::string> classes; };

struct Entity {
    EntityId id = 0; std::string name = "Entity"; EntityId parent = 0; bool active = true;
    Transform transform;
    std::optional<SpriteRenderer> sprite; std::optional<SpriteAnimator> animator;
    std::optional<CameraComponent> camera; std::optional<ModelRenderer> model;
    std::optional<LightComponent> light; std::optional<SkyComponent> sky; std::optional<ScriptComponent> script;
    XMMATRIX World(const class Scene& s) const;
};

class Scene {
public:
    std::string name = "Scene";
    std::vector<std::unique_ptr<Entity>> entities;
    Entity* Create(const std::string& n) { auto e = std::make_unique<Entity>(); e->id = ++nextId; e->name = n; entities.push_back(std::move(e)); return entities.back().get(); }
    Entity* Find(EntityId id) { for (auto& e : entities) if (e->id == id) return e.get(); return nullptr; }
    const Entity* Find(EntityId id) const { for (auto& e : entities) if (e->id == id) return e.get(); return nullptr; }
    Entity* FindByName(const std::string& n) { for (auto& e : entities) if (e->name == n) return e.get(); return nullptr; }
    Entity* GameplayCamera() { for (auto& e : entities) if (e->camera && e->camera->gameplayCamera && e->active) return e.get(); return nullptr; }
    void Remove(EntityId id) { for (auto& e : entities) if (e->parent == id) e->parent = 0;
        entities.erase(std::remove_if(entities.begin(), entities.end(), [&](auto& e){return e->id==id;}), entities.end()); }
    void Update(float dt) { for (auto& e : entities) if (e->animator && e->sprite) e->animator->Update(dt, *e->sprite); }
    // Projeto padrao: chao, fundo, 2 personagens (sprites), camera, sol + ceu.
    void BuildDefault();
    bool Save(const std::string& path) const; bool Load(const std::string& path);
private: EntityId nextId = 0;
};
inline XMMATRIX Entity::World(const Scene& s) const {
    XMMATRIX m = transform.Local(); const Entity* p = s.Find(parent); int guard = 0;
    while (p && guard++ < 32) { m = m * p->transform.Local(); p = s.Find(p->parent); } return m; }

// ---- serializacao ----  (ADL: precisa estar no namespace dos tipos DirectX)
}
namespace DirectX {
inline void to_json(nlohmann::json& j, const XMFLOAT3& v){ j = {v.x,v.y,v.z}; }
inline void from_json(const nlohmann::json& j, XMFLOAT3& v){ v = {j[0],j[1],j[2]}; }
inline void to_json(nlohmann::json& j, const XMFLOAT4& v){ j = {v.x,v.y,v.z,v.w}; }
inline void from_json(const nlohmann::json& j, XMFLOAT4& v){ v = {j[0],j[1],j[2],j[3]}; }
inline void to_json(nlohmann::json& j, const XMFLOAT2& v){ j = {v.x,v.y}; }
inline void from_json(const nlohmann::json& j, XMFLOAT2& v){ v = {j[0],j[1]}; }

}
namespace bo {
inline void Scene::BuildDefault() {
    entities.clear(); nextId = 0; name = "Default";
    auto* sky = Create("Sky & Sun"); sky->sky = SkyComponent{}; sky->light = LightComponent{}; sky->transform.rotation = {-40,35,0};
    auto* ground = Create("Ground"); ground->model = ModelRenderer{}; ground->model->model = "builtin:plane"; ground->model->baseColor = {0.30f,0.32f,0.36f,1};
    ground->model->roughness = 0.85f; ground->transform.scale = {40,1,40};
    auto* backdrop = Create("Backdrop"); backdrop->sprite = SpriteRenderer{}; backdrop->sprite->texture = "builtin:backdrop"; backdrop->sprite->size = {24,12};
    backdrop->sprite->billboard = false; backdrop->sprite->pivot = {0.5f,0.f}; backdrop->sprite->sortOrder = -10; backdrop->transform.position = {0,0,6};
    auto* bf = Create("Boyfriend"); bf->sprite = SpriteRenderer{}; bf->sprite->texture = "builtin:char_blue"; bf->sprite->size = {2.2f,3.2f};
    bf->sprite->billboard = false; bf->sprite->flipX = true; bf->transform.position = {2.6f,0,2}; bf->animator = SpriteAnimator{};
    bf->animator->AddGridAnimation("idle", 0, 1, 1, 1, 24, true);
    auto* op = Create("Opponent"); op->sprite = SpriteRenderer{}; op->sprite->texture = "builtin:char_red"; op->sprite->size = {2.2f,3.2f};
    op->sprite->billboard = false; op->transform.position = {-2.6f,0,2}; op->animator = SpriteAnimator{};
    op->animator->AddGridAnimation("idle", 0, 1, 1, 1, 24, true);
    auto* cam = Create("Main Camera"); cam->camera = CameraComponent{}; cam->transform.position = {0,2.2f,-7.5f}; cam->transform.rotation = {5,0,0};
}
inline bool Scene::Save(const std::string& path) const {
    using nlohmann::json; json root; root["name"] = name; json arr = json::array();
    for (auto& e : entities) { json o; o["id"]=e->id; o["name"]=e->name; o["parent"]=e->parent; o["active"]=e->active;
        o["pos"]=e->transform.position; o["rot"]=e->transform.rotation; o["scale"]=e->transform.scale;
        if (e->sprite) { auto& s=*e->sprite; o["sprite"]={{"tex",s.texture},{"tint",s.tint},{"size",s.size},{"pivot",s.pivot},{"billboard",s.billboard},{"flipX",s.flipX},{"lit",s.lit},{"sort",s.sortOrder}}; }
        if (e->animator) { json an=json::object(); for (auto& [k,a]:e->animator->anims){ json fr=json::array(); for(auto&f:a.frames) fr.push_back({f.u,f.v,f.w,f.h}); an[k]={{"fps",a.fps},{"loop",a.loop},{"frames",fr}}; } o["animator"]=an; }
        if (e->camera) { auto& c=*e->camera; o["camera"]={{"fov",c.fovDeg},{"ortho",c.ortho},{"orthoSize",c.orthoSize},{"near",c.nearZ},{"far",c.farZ},{"gameplay",c.gameplayCamera}}; }
        if (e->model) { auto& m=*e->model; o["model"]={{"file",m.model},{"albedo",m.albedo},{"normal",m.normal},{"orm",m.orm},{"emissive",m.emissive},{"color",m.baseColor},{"metal",m.metallic},{"rough",m.roughness},{"emis",m.emissiveStrength},{"cast",m.castShadow}}; }
        if (e->light) o["light"]={{"color",e->light->color},{"intensity",e->light->intensity}};
        if (e->sky) { auto& s=*e->sky; o["sky"]={{"proc",s.procedural},{"hdri",s.hdri},{"elev",s.sunElevation},{"azim",s.sunAzimuth},{"cover",s.cloudCover},{"dens",s.cloudDensity},{"hdriInt",s.hdriIntensity}}; }
        if (e->script) o["script"]=e->script->classes;
        arr.push_back(o); }
    root["entities"] = arr; std::ofstream f(path); if (!f) return false; f << root.dump(2); return true;
}
inline bool Scene::Load(const std::string& path) {
    using nlohmann::json; std::ifstream f(path); if (!f) return false; json root;
    try { root = json::parse(f); } catch (...) { return false; }
    entities.clear(); nextId = 0; name = root.value("name", "Scene");
    for (auto& o : root["entities"]) { auto* e = Create(o.value("name","Entity")); e->id = o.value("id", e->id); nextId = std::max(nextId, e->id);
        e->parent=o.value("parent",0u); e->active=o.value("active",true);
        e->transform.position=o["pos"].get<XMFLOAT3>(); e->transform.rotation=o["rot"].get<XMFLOAT3>(); e->transform.scale=o["scale"].get<XMFLOAT3>();
        if (o.contains("sprite")) { auto& s=o["sprite"]; SpriteRenderer r; r.texture=s.value("tex",std::string()); r.tint=s["tint"].get<XMFLOAT4>(); r.size=s["size"].get<XMFLOAT2>(); r.pivot=s["pivot"].get<XMFLOAT2>();
            r.billboard=s.value("billboard",true); r.flipX=s.value("flipX",false); r.lit=s.value("lit",false); r.sortOrder=s.value("sort",0); e->sprite=r; }
        if (o.contains("animator")) { SpriteAnimator an; for (auto& [k,v]:o["animator"].items()){ SpriteAnim a; a.fps=v.value("fps",24.f); a.loop=v.value("loop",true); for(auto&fr:v["frames"]) a.frames.push_back({fr[0],fr[1],fr[2],fr[3]}); an.anims[k]=a; } if(!an.anims.empty()) an.Play(an.anims.begin()->first); e->animator=an; }
        if (o.contains("camera")) { auto& c=o["camera"]; CameraComponent r; r.fovDeg=c.value("fov",50.f); r.ortho=c.value("ortho",false); r.orthoSize=c.value("orthoSize",5.f); r.nearZ=c.value("near",0.05f); r.farZ=c.value("far",2000.f); r.gameplayCamera=c.value("gameplay",true); e->camera=r; }
        if (o.contains("model")) { auto& m=o["model"]; ModelRenderer r; r.model=m.value("file",std::string()); r.albedo=m.value("albedo",std::string()); r.normal=m.value("normal",std::string()); r.orm=m.value("orm",std::string()); r.emissive=m.value("emissive",std::string());
            r.baseColor=m["color"].get<XMFLOAT4>(); r.metallic=m.value("metal",0.f); r.roughness=m.value("rough",0.6f); r.emissiveStrength=m.value("emis",0.f); r.castShadow=m.value("cast",true); e->model=r; }
        if (o.contains("light")) { LightComponent l; l.color=o["light"]["color"].get<XMFLOAT3>(); l.intensity=o["light"].value("intensity",6.f); e->light=l; }
        if (o.contains("sky")) { auto& s=o["sky"]; SkyComponent r; r.procedural=s.value("proc",true); r.hdri=s.value("hdri",std::string()); r.sunElevation=s.value("elev",40.f); r.sunAzimuth=s.value("azim",35.f); r.cloudCover=s.value("cover",.55f); r.cloudDensity=s.value("dens",1.f); r.hdriIntensity=s.value("hdriInt",1.f); e->sky=r; }
        if (o.contains("script")) { ScriptComponent sc; sc.classes=o["script"].get<std::vector<std::string>>(); e->script=sc; } }
    return true;
}
}
