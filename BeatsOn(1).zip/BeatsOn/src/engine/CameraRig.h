#pragma once
// BeatsOn! - Camera API: zoom, movimento, rotacao, shake, flash/fade, pos-processamento, follow.
#include "Scene.h"
#include "Tween.h"
namespace bo {

enum class PostParam { Exposure, Bloom, Vignette, ChromaticAberration, Saturation, Contrast, Grain, FlashAmount, Count };
struct PostSettings {   // enviado ao shader de pos-processamento (tonemap ACES + bloom + vinheta + CA + grain)
    float exposure = 1.0f, bloom = 0.18f, vignette = 0.25f, chroma = 0.0f, saturation = 1.0f, contrast = 1.0f, grain = 0.0f, flash = 0.0f;
    XMFLOAT3 flashColor{1,1,1};
};

class CameraRig {
public:
    // ---- estado animado ----
    TweenF px, py, pz, pitch, yaw, roll, zoom, fov;
    TweenF post[(int)PostParam::Count];
    float shakeIntensity = 0, shakeTime = 0, shakeDur = 0; XMFLOAT3 flashColor{1,1,1};
    EntityId followTarget = 0; XMFLOAT3 followOffset{0,0,0}; float followLerp = 5.f;
    bool ortho = false; float orthoSize = 5, nearZ = 0.05f, farZ = 2000;

    void Bind(const Entity& camEntity) {   // inicializa a partir do componente Camera da cena
        px.Set(camEntity.transform.position.x); py.Set(camEntity.transform.position.y); pz.Set(camEntity.transform.position.z);
        pitch.Set(camEntity.transform.rotation.x); yaw.Set(camEntity.transform.rotation.y); roll.Set(camEntity.transform.rotation.z);
        auto& c = *camEntity.camera; fov.Set(c.fovDeg); zoom.Set(1.f); ortho = c.ortho; orthoSize = c.orthoSize; nearZ = c.nearZ; farZ = c.farZ;
        PostSettings d; post[0].Set(d.exposure); post[1].Set(d.bloom); post[2].Set(d.vignette); post[3].Set(d.chroma);
        post[4].Set(d.saturation); post[5].Set(d.contrast); post[6].Set(d.grain); post[7].Set(0);
        base = { px.value, py.value, pz.value };
    }
    // ---- API (e' isso que os scripts C# chamam) ----
    void ZoomTo(float z, float dur = 0.4f, Ease e = Ease::QuadOut)            { zoom.Start(z, dur, e); }
    void ZoomPunch(float amount, float dur = 0.25f)                           { zoom.value += amount; zoom.Start(zoom.to > 0 ? zoom.to : 1.f, dur, Ease::CubicOut); }
    void FovTo(float deg, float dur = 0.4f, Ease e = Ease::QuadOut)           { fov.Start(deg, dur, e); }
    void MoveTo(float x, float y, float z, float dur = 0.5f, Ease e = Ease::QuadInOut) { followTarget = 0; px.Start(x,dur,e); py.Start(y,dur,e); pz.Start(z,dur,e); }
    void RotateTo(float pitchDeg, float yawDeg, float rollDeg, float dur = 0.5f, Ease e = Ease::QuadInOut) { pitch.Start(pitchDeg,dur,e); yaw.Start(yawDeg,dur,e); roll.Start(rollDeg,dur,e); }
    void Shake(float intensity = 0.08f, float dur = 0.3f)                     { shakeIntensity = intensity; shakeDur = shakeTime = dur; }
    void Flash(float r, float g, float b, float amount = 1.f, float dur = 0.5f) { flashColor = {r,g,b}; post[(int)PostParam::FlashAmount].Set(amount); post[(int)PostParam::FlashAmount].Start(0, dur, Ease::QuadOut); }
    void Fade(float r, float g, float b, bool fadeOut, float dur = 1.f)       { flashColor = {r,g,b}; post[7].Start(fadeOut ? 1.f : 0.f, dur, Ease::Linear); }
    void SetPost(PostParam p, float v, float dur = 0.f, Ease e = Ease::QuadOut) { post[(int)p].Start(v, dur, e); }
    void Follow(EntityId id, XMFLOAT3 off = {0,0,0}, float lerp = 5.f)       { followTarget = id; followOffset = off; followLerp = lerp; }
    void SetOrtho(bool o, float size = 5)                                      { ortho = o; orthoSize = size; }

    void Update(float dt, const Scene& scene) {
        for (auto* t : { &px,&py,&pz,&pitch,&yaw,&roll,&zoom,&fov }) t->Update(dt);
        for (auto& t : post) t.Update(dt);
        if (followTarget) if (auto* e = scene.Find(followTarget)) {
            float k = 1.f - std::exp(-followLerp * dt);
            px.value += (e->transform.position.x + followOffset.x - px.value) * k; py.value += (e->transform.position.y + followOffset.y - py.value) * k;
            pz.value += (e->transform.position.z + followOffset.z - pz.value) * k; }
        shakeOff = {0,0,0};
        if (shakeTime > 0) { shakeTime -= dt; float f = shakeIntensity * std::max(0.f, shakeTime / std::max(shakeDur, 1e-4f));
            shakeOff = { (Rand01()*2-1)*f, (Rand01()*2-1)*f, 0 }; }
    }
    XMFLOAT3 Position() const { return { px.value + shakeOff.x, py.value + shakeOff.y, pz.value + shakeOff.z }; }
    XMMATRIX View() const {
        XMFLOAT3 p = Position();
        XMMATRIX rot = XMMatrixRotationRollPitchYaw(XMConvertToRadians(pitch.value), XMConvertToRadians(yaw.value), XMConvertToRadians(roll.value));
        XMVECTOR fwd = XMVector3TransformNormal(XMVectorSet(0,0,1,0), rot), up = XMVector3TransformNormal(XMVectorSet(0,1,0,0), rot);
        return XMMatrixLookToLH(XMLoadFloat3(&p), fwd, up); }
    XMMATRIX Proj(float aspect) const {
        float z = std::max(zoom.value, 0.01f);
        if (ortho) return XMMatrixOrthographicLH(orthoSize * 2 * aspect / z, orthoSize * 2 / z, nearZ, farZ);
        float fv = 2.f * std::atan(std::tan(XMConvertToRadians(fov.value) * 0.5f) / z);
        return XMMatrixPerspectiveFovLH(fv, aspect, nearZ, farZ); }
    PostSettings GetPost() const { PostSettings s; s.exposure=post[0].value; s.bloom=post[1].value; s.vignette=post[2].value; s.chroma=post[3].value;
        s.saturation=post[4].value; s.contrast=post[5].value; s.grain=post[6].value; s.flash=post[7].value; s.flashColor=flashColor; return s; }
private:
    XMFLOAT3 base{}, shakeOff{};
    static float Rand01() { static uint32_t s = 1234567; s = s * 1664525u + 1013904223u; return (s >> 8) / 16777216.f; }
};
}
