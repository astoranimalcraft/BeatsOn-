#pragma once
#include "Scene.h"
#include "CameraRig.h"
namespace bo {

constexpr UINT kFrames = 2, kBackBuffers = 3;

struct GpuTexture { ComPtr<ID3D12Resource> res; uint32_t cpuIndex = 0; uint32_t w = 0, h = 0; };
struct Vertex { XMFLOAT3 pos; XMFLOAT3 normal; XMFLOAT2 uv; XMFLOAT4 tangent; };
struct SubMesh { ComPtr<ID3D12Resource> vb, ib; D3D12_VERTEX_BUFFER_VIEW vbv{}; D3D12_INDEX_BUFFER_VIEW ibv{}; uint32_t indexCount = 0;
                 std::string albedo, normal, orm, emissive; XMFLOAT4 baseColor{1,1,1,1}; bool hasMaterial = false; };
struct Mesh { std::vector<SubMesh> subs; };

// Alvo de render (viewport do editor ou tela do jogo): cena HDR -> pos-processamento -> LDR (mostrado via ImGui::Image ou copiado pro backbuffer).
struct ViewportTarget {
    uint32_t w = 0, h = 0;
    ComPtr<ID3D12Resource> hdr, ldr, depth;
    D3D12_CPU_DESCRIPTOR_HANDLE rtvHdr{}, rtvLdr{}, dsv{}; uint32_t hdrSrvCpu = 0;
    D3D12_CPU_DESCRIPTOR_HANDLE ldrSrvCpuPermanent{}; D3D12_GPU_DESCRIPTOR_HANDLE ldrGpu{};   // use ldrGpu.ptr como ImTextureID
    bool inited = false;
};

struct RenderView {
    XMMATRIX view, proj; XMFLOAT3 camPos; bool drawGrid = false; PostSettings post; float time = 0;
};

class Renderer {
public:
    bool Init(HWND hwnd, uint32_t w, uint32_t h, const std::string& shaderDir, const std::string& assetRoot);
    void Shutdown(); void Resize(uint32_t w, uint32_t h);
    void BeginFrame(); void BeginBackbuffer(const float clear[4]); void EndFrame();
    void WaitIdle(); bool BackbufferActive() const { return bbRT; }

    void CreateViewport(ViewportTarget& vt, uint32_t w, uint32_t h);       // (re)cria; seguro chamar quando o painel muda de tamanho
    void RenderScene(Scene& scene, const RenderView& view, ViewportTarget& vt);
    void BlitToBackbuffer(ViewportTarget& vt);                              // para o jogo (sem ImGui): copia o LDR p/ tela

    GpuTexture* GetTexture(const std::string& path, bool srgb = true);     // cache; "builtin:*" gerados proceduralmente
    Mesh* GetMesh(const std::string& path);                                 // cache; builtin:cube/plane ou Assimp (fbx, obj, gltf, dae...)
    GpuTexture* CreateTextureFromMemory(const unsigned char* data, size_t size);          // ex.: icone de mod (png)
    D3D12_GPU_DESCRIPTOR_HANDLE ImGuiHandle(GpuTexture* t);                                // use .ptr como ImTextureID
    bool LoadHDRI(const std::string& path);                                 // equirretangular .hdr/.exr -> usado pelo SkyComponent
    void ClearHDRI() { hdri.reset(); }
    void SetAssetRoot(const std::string& r) { assetRoot = r; for (auto it = textures.begin(); it != textures.end();) { if (it->first.rfind("builtin:", 0) == 0) ++it; else it = textures.erase(it); } meshes.clear(); }
    const std::string& AssetRoot() const { return assetRoot; }

    // ImGui
    ID3D12Device* Device() const { return device.Get(); }
    ID3D12GraphicsCommandList* List() const { return list.Get(); }
    ID3D12DescriptorHeap* GpuHeap() const { return gpuHeap.Get(); }
    void AllocPermanent(D3D12_CPU_DESCRIPTOR_HANDLE* cpu, D3D12_GPU_DESCRIPTOR_HANDLE* gpu);
    uint32_t Width() const { return width; } uint32_t Height() const { return height; }
    DXGI_FORMAT BackbufferFormat() const { return DXGI_FORMAT_R8G8B8A8_UNORM; }
    ID3D12CommandQueue* Queue() const { return queue.Get(); }
    uint32_t PermanentCount() const { return permCount; }

private:
    struct Upload { D3D12_GPU_VIRTUAL_ADDRESS va; void* cpu; };
    Upload AllocUpload(size_t size);
    D3D12_GPU_DESCRIPTOR_HANDLE AllocTable(uint32_t count, D3D12_CPU_DESCRIPTOR_HANDLE* cpuStart);
    uint32_t AllocCpuSrv();
    void CreateRootAndPipelines(const std::string& shaderDir);
    ComPtr<ID3D12PipelineState> MakePSO(const std::string& file, const char* vs, const char* ps, bool mesh, DXGI_FORMAT rt, bool depth, bool depthWrite, bool blend, D3D12_CULL_MODE cull, bool shadow = false);
    ComPtr<ID3DBlob> Compile(const std::string& file, const char* entry, const char* target);
    GpuTexture MakeTexture(const void* data, uint32_t w, uint32_t h, DXGI_FORMAT fmt, uint32_t bytesPerPixel, bool genMips);
    GpuTexture MakeTextureHalf(const float* rgba, uint32_t w, uint32_t h);
    ComPtr<ID3D12Resource> MakeBuffer(const void* data, size_t size);
    void FlushCopy(const std::function<void(ID3D12GraphicsCommandList*)>& rec);
    void CreateBuiltinTextures(); Mesh BuildPrimitive(bool cube);
    void Transition(ID3D12Resource* r, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b);
    void DrawMeshes(Scene& scene, bool shadowPass, D3D12_GPU_VIRTUAL_ADDRESS frameCB, D3D12_GPU_DESCRIPTOR_HANDLE globals);

    HWND hwnd{}; uint32_t width = 0, height = 0, frameIndex = 0, backIndex = 0; std::string assetRoot, shaderDir;
    ComPtr<IDXGIFactory6> factory; ComPtr<ID3D12Device> device; ComPtr<ID3D12CommandQueue> queue; ComPtr<IDXGISwapChain3> swap;
    ComPtr<ID3D12CommandAllocator> alloc[kFrames]; ComPtr<ID3D12GraphicsCommandList> list;
    ComPtr<ID3D12Fence> fence; HANDLE fenceEvent{}; uint64_t fenceValue = 0, frameFence[kFrames] = {};
    ComPtr<ID3D12Resource> backbuffers[kBackBuffers];
    ComPtr<ID3D12DescriptorHeap> rtvHeap, dsvHeap, cpuSrvHeap, gpuHeap;
    UINT rtvInc = 0, dsvInc = 0, srvInc = 0; uint32_t rtvCount = 0, dsvCount = 0, cpuSrvCount = 0;
    static constexpr uint32_t kPermanent = 256, kPerFrame = 3840, kCpuSrv = 4096;
    uint32_t permCount = 0, frameDescOffset = 0;
    ComPtr<ID3D12Resource> uploadBuf[kFrames]; uint8_t* uploadPtr[kFrames] = {}; size_t uploadOffset = 0; static constexpr size_t kUploadSize = 8 << 20;
    ComPtr<ID3D12RootSignature> rootSig;
    ComPtr<ID3D12PipelineState> psoSky, psoMesh, psoShadow, psoGrid, psoAxis, psoSprite, psoPost;
    ComPtr<ID3D12Resource> shadowMap; D3D12_CPU_DESCRIPTOR_HANDLE shadowDsv{}; uint32_t shadowSrvCpu = 0; bool shadowInit = false;
    std::unordered_map<std::string, std::unique_ptr<GpuTexture>> textures; std::unordered_map<std::string, std::unique_ptr<Mesh>> meshes;
    std::vector<std::unique_ptr<GpuTexture>> ownedTextures; std::unordered_map<GpuTexture*, D3D12_GPU_DESCRIPTOR_HANDLE> imguiHandles;
    std::unique_ptr<GpuTexture> hdri; GpuTexture dummyHdri;
    GpuTexture whiteTex, flatNormalTex, blackTex;
    ViewportTarget* currentTarget = nullptr; bool inFrame = false, bbRT = false;
};
}
