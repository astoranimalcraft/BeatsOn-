#pragma once
#include "Platform.h"
#include "Renderer.h"
#include "Audio.h"
#include "../scripting/ScriptHost.h"
#include <imgui.h>
namespace bo {
class Application {
public:
    virtual ~Application() = default; int Run(const wchar_t* title, int w, int h, bool editorStyle);
protected:
    virtual bool OnInit() = 0; virtual void OnUpdate(float dt) = 0; virtual void OnGui() = 0; virtual void OnRender() {} virtual void OnShutdown() {}
    Window window; Renderer renderer; std::unique_ptr<AudioEngine> audio; ScriptHost scripts; fs::path exeDir; bool dockspace = true; ImFont* fontBig = nullptr;
private: void SetupImGui(bool editorStyle);
};
void ApplyBeatsOnTheme();
}
