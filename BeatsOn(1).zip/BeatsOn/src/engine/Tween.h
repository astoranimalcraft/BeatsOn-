#pragma once
#include <cmath>
#include <algorithm>
namespace bo {
enum class Ease { Linear, QuadIn, QuadOut, QuadInOut, CubicIn, CubicOut, CubicInOut, SineInOut, BackOut, ElasticOut, BounceOut, Instant };
inline float ApplyEase(Ease e, float t) {
    t = std::clamp(t, 0.f, 1.f); const float PI = 3.14159265f;
    switch (e) {
    case Ease::Linear: return t;
    case Ease::QuadIn: return t*t;
    case Ease::QuadOut: return 1-(1-t)*(1-t);
    case Ease::QuadInOut: return t<.5f ? 2*t*t : 1-std::pow(-2*t+2,2.f)/2;
    case Ease::CubicIn: return t*t*t;
    case Ease::CubicOut: return 1-std::pow(1-t,3.f);
    case Ease::CubicInOut: return t<.5f ? 4*t*t*t : 1-std::pow(-2*t+2,3.f)/2;
    case Ease::SineInOut: return -(std::cos(PI*t)-1)/2;
    case Ease::BackOut: { float c1=1.70158f,c3=c1+1; return 1+c3*std::pow(t-1,3.f)+c1*std::pow(t-1,2.f); }
    case Ease::ElasticOut: { if(t==0||t==1) return t; return std::pow(2.f,-10*t)*std::sin((t*10-0.75f)*(2*PI/3))+1; }
    case Ease::BounceOut: { float n=7.5625f,d=2.75f; if(t<1/d) return n*t*t; if(t<2/d){t-=1.5f/d;return n*t*t+.75f;} if(t<2.5f/d){t-=2.25f/d;return n*t*t+.9375f;} t-=2.625f/d; return n*t*t+.984375f; }
    case Ease::Instant: return 1.f;
    } return t;
}
// Float animado: Start(para, duracao, ease). value e' lido todo frame.
struct TweenF {
    float value = 0, from = 0, to = 0, t = 0, dur = 0; Ease ease = Ease::Linear; bool active = false;
    void Set(float v) { value = from = to = v; active = false; }
    void Start(float target, float duration, Ease e = Ease::QuadOut) {
        from = value; to = target; dur = duration; t = 0; ease = e; active = true;
        if (duration <= 0.f) { value = target; active = false; } }
    void Update(float dt) { if (!active) return; t += dt; float k = dur > 0 ? t / dur : 1.f;
        value = from + (to - from) * ApplyEase(ease, k); if (k >= 1.f) { value = to; active = false; } }
};
}
