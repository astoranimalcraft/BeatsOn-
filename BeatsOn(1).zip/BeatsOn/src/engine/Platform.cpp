#include "Platform.h"
#include <commdlg.h>
#include <shlobj.h>
#include <windowsx.h>
namespace bo {
bool Window::Create(const wchar_t* title, int W, int H) {
    WNDCLASSEXW wc{ sizeof wc }; wc.style = CS_HREDRAW | CS_VREDRAW; wc.lpfnWndProc = Proc; wc.hInstance = GetModuleHandle(nullptr); wc.hCursor = LoadCursor(nullptr, IDC_ARROW); wc.lpszClassName = L"BeatsOnWnd"; RegisterClassExW(&wc);
    RECT r{ 0,0,W,H }; AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
    hwnd = CreateWindowExW(0, wc.lpszClassName, title, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top, nullptr, nullptr, wc.hInstance, this);
    if (!hwnd) return false; w = W; h = H; ShowWindow(hwnd, SW_SHOW); return true; }
bool Window::PumpMessages() { MSG m; while (PeekMessage(&m, nullptr, 0, 0, PM_REMOVE)) { if (m.message == WM_QUIT) quit = true; TranslateMessage(&m); DispatchMessage(&m); } return !quit; }
void Window::SetCursorCaptured(bool c) {
    if (c == captured) return; captured = c;
    if (c) { GetCursorPos(&lockPos); ShowCursor(FALSE); RECT r{ lockPos.x, lockPos.y, lockPos.x + 1, lockPos.y + 1 }; ClipCursor(&r); SetCapture(hwnd); }
    else { ClipCursor(nullptr); ReleaseCapture(); ShowCursor(TRUE); SetCursorPos(lockPos.x, lockPos.y); } }
LRESULT CALLBACK Window::Proc(HWND h, UINT m, WPARAM w, LPARAM l) {
    Window* self = (Window*)GetWindowLongPtr(h, GWLP_USERDATA);
    if (m == WM_NCCREATE) { self = (Window*)((CREATESTRUCT*)l)->lpCreateParams; SetWindowLongPtr(h, GWLP_USERDATA, (LONG_PTR)self); }
    return self ? self->Handle(h, m, w, l) : DefWindowProc(h, m, w, l); }
LRESULT Window::Handle(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    if (preHandler && preHandler(h, m, wp, lp)) return true;
    switch (m) {
    case WM_SIZE: if (wp != SIZE_MINIMIZED) { w = LOWORD(lp); this->h = HIWORD(lp); if (onResize) onResize(w, this->h); } return 0;
    case WM_KEYDOWN: case WM_SYSKEYDOWN: input.key[wp & 255] = true; return 0;
    case WM_KEYUP: case WM_SYSKEYUP: input.key[wp & 255] = false; return 0;
    case WM_LBUTTONDOWN: input.mouse[0] = true; return 0; case WM_LBUTTONUP: input.mouse[0] = false; return 0;
    case WM_RBUTTONDOWN: input.mouse[1] = true; return 0; case WM_RBUTTONUP: input.mouse[1] = false; return 0;
    case WM_MBUTTONDOWN: input.mouse[2] = true; return 0; case WM_MBUTTONUP: input.mouse[2] = false; return 0;
    case WM_MOUSEWHEEL: input.scroll += GET_WHEEL_DELTA_WPARAM(wp) / (float)WHEEL_DELTA; return 0;
    case WM_MOUSEMOVE: input.mouseX = (float)GET_X_LPARAM(lp); input.mouseY = (float)GET_Y_LPARAM(lp); return 0;
    case WM_INPUT: { UINT sz = 0; GetRawInputData((HRAWINPUT)lp, RID_INPUT, nullptr, &sz, sizeof(RAWINPUTHEADER)); std::vector<BYTE> b(sz);
        if (GetRawInputData((HRAWINPUT)lp, RID_INPUT, b.data(), &sz, sizeof(RAWINPUTHEADER)) == sz) { auto* ri = (RAWINPUT*)b.data(); if (ri->header.dwType == RIM_TYPEMOUSE) { input.mouseDX += (float)ri->data.mouse.lLastX; input.mouseDY += (float)ri->data.mouse.lLastY; } } break; }
    case WM_KILLFOCUS: memset(input.key, 0, sizeof input.key); break;
    case WM_DESTROY: PostQuitMessage(0); return 0; }
    return DefWindowProc(h, m, wp, lp); }

std::string OpenFileDialog(HWND owner, const wchar_t* filter) { wchar_t f[MAX_PATH] = {}; OPENFILENAMEW o{ sizeof o }; o.hwndOwner = owner; o.lpstrFilter = filter; o.lpstrFile = f; o.nMaxFile = MAX_PATH; o.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (!GetOpenFileNameW(&o)) return {}; return fs::path(f).string(); }
std::string SaveFileDialog(HWND owner, const wchar_t* filter, const wchar_t* ext) { wchar_t f[MAX_PATH] = {}; OPENFILENAMEW o{ sizeof o }; o.hwndOwner = owner; o.lpstrFilter = filter; o.lpstrFile = f; o.nMaxFile = MAX_PATH; o.lpstrDefExt = ext; o.Flags = OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
    if (!GetSaveFileNameW(&o)) return {}; return fs::path(f).string(); }
std::string PickFolderDialog(HWND owner) { BROWSEINFOW b{}; b.hwndOwner = owner; b.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE; PIDLIST_ABSOLUTE p = SHBrowseForFolderW(&b); if (!p) return {}; wchar_t path[MAX_PATH]; SHGetPathFromIDListW(p, path); CoTaskMemFree(p); return fs::path(path).string(); }
}
