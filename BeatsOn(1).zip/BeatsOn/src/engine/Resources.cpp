// Texturas, malhas (Assimp), HDRI, primitivas e texturas placeholder.
#define STB_IMAGE_IMPLEMENTATION
#define STBI_WINDOWS_UTF8
#include <stb_image.h>
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>
#include "Renderer.h"
#include <DirectXPackedVector.h>
using namespace DirectX::PackedVector;
namespace bo {

void Renderer::FlushCopy(const std::function<void(ID3D12GraphicsCommandList*)>& rec) {
    ComPtr<ID3D12CommandAllocator> a; ComPtr<ID3D12GraphicsCommandList> l; ComPtr<ID3D12Fence> f;
    device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&a)); device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, a.Get(), nullptr, IID_PPV_ARGS(&l));
    rec(l.Get()); l->Close(); ID3D12CommandList* ls[] = { l.Get() }; queue->ExecuteCommandLists(1, ls);
    device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&f)); HANDLE ev = CreateEvent(nullptr, FALSE, FALSE, nullptr);
    queue->Signal(f.Get(), 1); f->SetEventOnCompletion(1, ev); WaitForSingleObject(ev, INFINITE); CloseHandle(ev); }

ComPtr<ID3D12Resource> Renderer::MakeBuffer(const void* data, size_t size) {
    ComPtr<ID3D12Resource> buf, up; auto hpD = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT), hpU = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD); auto rd = CD3DX12_RESOURCE_DESC::Buffer(size);
    Check(device->CreateCommittedResource(&hpD, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&buf)), "Buffer");
    Check(device->CreateCommittedResource(&hpU, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&up)), "UploadBuffer");
    void* p; up->Map(0, nullptr, &p); memcpy(p, data, size); up->Unmap(0, nullptr);
    FlushCopy([&](ID3D12GraphicsCommandList* l) { l->CopyBufferRegion(buf.Get(), 0, up.Get(), 0, size);
        auto b = CD3DX12_RESOURCE_BARRIER::Transition(buf.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER | D3D12_RESOURCE_STATE_INDEX_BUFFER); l->ResourceBarrier(1, &b); });
    return buf; }

GpuTexture Renderer::MakeTexture(const void* data, uint32_t w, uint32_t h, DXGI_FORMAT fmt, uint32_t bpp, bool genMips) {
    // mips por filtro de caixa (RGBA8)
    std::vector<std::vector<uint8_t>> mips; std::vector<uint32_t> mw, mh; mips.emplace_back((const uint8_t*)data, (const uint8_t*)data + (size_t)w * h * bpp); mw.push_back(w); mh.push_back(h);
    if (genMips && bpp == 4) while (mw.back() > 1 || mh.back() > 1) { uint32_t pw = mw.back(), ph = mh.back(), nw = std::max(1u, pw / 2), nh = std::max(1u, ph / 2); std::vector<uint8_t> n((size_t)nw * nh * 4); auto& src = mips.back();
        for (uint32_t y = 0; y < nh; ++y) for (uint32_t x = 0; x < nw; ++x) for (int c = 0; c < 4; ++c) { uint32_t x0 = std::min(x * 2, pw - 1), x1 = std::min(x * 2 + 1, pw - 1), y0 = std::min(y * 2, ph - 1), y1 = std::min(y * 2 + 1, ph - 1);
            n[((size_t)y * nw + x) * 4 + c] = (uint8_t)((src[((size_t)y0 * pw + x0) * 4 + c] + src[((size_t)y0 * pw + x1) * 4 + c] + src[((size_t)y1 * pw + x0) * 4 + c] + src[((size_t)y1 * pw + x1) * 4 + c]) / 4); }
        mips.push_back(std::move(n)); mw.push_back(nw); mh.push_back(nh); }
    GpuTexture t; t.w = w; t.h = h; UINT nm = (UINT)mips.size(); auto hp = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT); auto rd = CD3DX12_RESOURCE_DESC::Tex2D(fmt, w, h, 1, (UINT16)nm);
    Check(device->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&t.res)), "Texture");
    std::vector<D3D12_SUBRESOURCE_DATA> subs(nm); for (UINT i = 0; i < nm; ++i) subs[i] = { mips[i].data(), (LONG_PTR)(mw[i] * bpp), (LONG_PTR)(mw[i] * mh[i] * bpp) };
    UINT64 sz = GetRequiredIntermediateSize(t.res.Get(), 0, nm); ComPtr<ID3D12Resource> up; auto hpU = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD); auto rdU = CD3DX12_RESOURCE_DESC::Buffer(sz);
    Check(device->CreateCommittedResource(&hpU, D3D12_HEAP_FLAG_NONE, &rdU, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&up)), "TexUpload");
    FlushCopy([&](ID3D12GraphicsCommandList* l) { UpdateSubresources(l, t.res.Get(), up.Get(), 0, 0, nm, subs.data());
        auto b = CD3DX12_RESOURCE_BARRIER::Transition(t.res.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE); l->ResourceBarrier(1, &b); });
    t.cpuIndex = AllocCpuSrv(); device->CreateShaderResourceView(t.res.Get(), nullptr, CD3DX12_CPU_DESCRIPTOR_HANDLE(cpuSrvHeap->GetCPUDescriptorHandleForHeapStart(), t.cpuIndex, srvInc)); return t; }

GpuTexture Renderer::MakeTextureHalf(const float* rgba, uint32_t w, uint32_t h) {
    std::vector<HALF> hd((size_t)w * h * 4); for (size_t i = 0; i < hd.size(); ++i) hd[i] = XMConvertFloatToHalf(std::min(rgba[i], 60000.f));
    GpuTexture t; t.w = w; t.h = h; auto hp = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT); auto rd = CD3DX12_RESOURCE_DESC::Tex2D(DXGI_FORMAT_R16G16B16A16_FLOAT, w, h, 1, 1);
    Check(device->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, IID_PPV_ARGS(&t.res)), "HDRI");
    D3D12_SUBRESOURCE_DATA sd{ hd.data(), (LONG_PTR)(w * 8), (LONG_PTR)(w * h * 8) }; UINT64 sz = GetRequiredIntermediateSize(t.res.Get(), 0, 1); ComPtr<ID3D12Resource> up;
    auto hpU = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD); auto rdU = CD3DX12_RESOURCE_DESC::Buffer(sz); Check(device->CreateCommittedResource(&hpU, D3D12_HEAP_FLAG_NONE, &rdU, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&up)), "HDRIUpload");
    FlushCopy([&](ID3D12GraphicsCommandList* l) { UpdateSubresources(l, t.res.Get(), up.Get(), 0, 0, 1, &sd); auto b = CD3DX12_RESOURCE_BARRIER::Transition(t.res.Get(), D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE); l->ResourceBarrier(1, &b); });
    t.cpuIndex = AllocCpuSrv(); device->CreateShaderResourceView(t.res.Get(), nullptr, CD3DX12_CPU_DESCRIPTOR_HANDLE(cpuSrvHeap->GetCPUDescriptorHandleForHeapStart(), t.cpuIndex, srvInc)); return t; }

bool Renderer::LoadHDRI(const std::string& path) {
    std::string full = fs::path(path).is_absolute() ? path : assetRoot + "/" + path; int w, h, n; float* px = stbi_loadf(full.c_str(), &w, &h, &n, 4);   // .hdr (Radiance). EXR: converta para .hdr
    if (!px) { Log("[HDRI] nao foi possivel carregar %s", full.c_str()); return false; }
    WaitIdle(); hdri = std::make_unique<GpuTexture>(MakeTextureHalf(px, w, h)); stbi_image_free(px); return true; }

// ---- texturas procedurais ("builtin:*"): permitem o projeto padrao funcionar sem nenhum arquivo.
static std::vector<uint8_t> GenChar(uint32_t S, float r, float g, float b) {
    std::vector<uint8_t> px((size_t)S * S * 4, 0); auto put = [&](int x, int y, float R, float G, float B, float A) { if (x < 0 || y < 0 || x >= (int)S || y >= (int)S) return; auto* p = &px[((size_t)y * S + x) * 4]; p[0] = (uint8_t)(R * 255); p[1] = (uint8_t)(G * 255); p[2] = (uint8_t)(B * 255); p[3] = (uint8_t)(A * 255); };
    for (int y = 0; y < (int)S; ++y) for (int x = 0; x < (int)S; ++x) { float u = x / (float)S - 0.5f, v = y / (float)S; // v: 0 topo
        float head = std::hypot(u, v - 0.2f), body = (std::abs(u) < 0.17f - (v - 0.4f) * 0.05f && v > 0.34f && v < 0.80f) ? 1.f : 0.f, legs = (std::abs(std::abs(u) - 0.08f) < 0.05f && v >= 0.8f && v < 0.98f) ? 1.f : 0.f;
        float arm = (std::abs(u) > 0.15f && std::abs(u) < 0.25f && v > 0.40f && v < 0.68f) ? 1.f : 0.f;
        if (head < 0.15f) { float s = 1.f - head * 1.6f; put(x, y, 0.96f * s, 0.80f * s, 0.68f * s, 1); if (std::abs(std::abs(u) - 0.05f) < 0.018f && std::abs(v - 0.19f) < 0.025f) put(x, y, 0.05f, 0.05f, 0.1f, 1); if (head > 0.13f) put(x, y, 0.05f, 0.05f, 0.08f, 1); }
        else if (head < 0.17f && v < 0.12f) put(x, y, r * 0.5f, g * 0.5f, b * 0.5f, 1);
        else if (body > 0.5f || arm > 0.5f) { float s = 0.75f + 0.25f * (0.5f - std::abs(u)); put(x, y, r * s, g * s, b * s, 1); }
        else if (legs > 0.5f) put(x, y, 0.15f, 0.15f, 0.25f, 1); }
    return px; }
static std::vector<uint8_t> GenBackdrop(uint32_t W, uint32_t H) {
    std::vector<uint8_t> px((size_t)W * H * 4); for (uint32_t y = 0; y < H; ++y) for (uint32_t x = 0; x < W; ++x) { float t = y / (float)H; auto* p = &px[((size_t)y * W + x) * 4];
        float R = 0.10f + 0.25f * (1 - t), G = 0.08f + 0.12f * (1 - t), B = 0.22f + 0.35f * (1 - t); bool grid = (x % 64 < 2) || (y % 64 < 2); if (grid) { R += 0.10f; G += 0.12f; B += 0.18f; }
        p[0] = (uint8_t)(std::min(R, 1.f) * 255); p[1] = (uint8_t)(std::min(G, 1.f) * 255); p[2] = (uint8_t)(std::min(B, 1.f) * 255); p[3] = 255; } return px; }
void Renderer::CreateBuiltinTextures() {
    uint32_t w1 = 0xFFFFFFFF, n1 = 0xFFFF8080, b1 = 0xFF000000; whiteTex = MakeTexture(&w1, 1, 1, DXGI_FORMAT_R8G8B8A8_UNORM, 4, false); flatNormalTex = MakeTexture(&n1, 1, 1, DXGI_FORMAT_R8G8B8A8_UNORM, 4, false); blackTex = MakeTexture(&b1, 1, 1, DXGI_FORMAT_R8G8B8A8_UNORM, 4, false);
    float one[4] = { 0.2f,0.3f,0.5f,1 }; dummyHdri = MakeTextureHalf(one, 1, 1);
    auto reg = [&](const char* n, const std::vector<uint8_t>& d, uint32_t w, uint32_t h) { textures[n] = std::make_unique<GpuTexture>(MakeTexture(d.data(), w, h, DXGI_FORMAT_R8G8B8A8_UNORM_SRGB, 4, true)); };
    reg("builtin:char_blue", GenChar(256, 0.2f, 0.55f, 1.0f), 256, 256); reg("builtin:char_red", GenChar(256, 0.95f, 0.25f, 0.3f), 256, 256); reg("builtin:backdrop", GenBackdrop(512, 256), 512, 256);
    textures["builtin:white"] = std::make_unique<GpuTexture>(whiteTex); }

GpuTexture* Renderer::GetTexture(const std::string& path, bool srgb) {
    std::string key = path + (srgb ? "|s" : "|l"); if (path.rfind("builtin:", 0) == 0) key = path;
    auto it = textures.find(key); if (it != textures.end()) return it->second.get();
    std::string full = fs::path(path).is_absolute() ? path : assetRoot + "/" + path; int w, h, n; stbi_uc* px = stbi_load(full.c_str(), &w, &h, &n, 4);
    if (!px) { Log("[Texture] falhou: %s", full.c_str()); textures[key] = std::make_unique<GpuTexture>(whiteTex); return textures[key].get(); }
    auto t = std::make_unique<GpuTexture>(MakeTexture(px, w, h, srgb ? DXGI_FORMAT_R8G8B8A8_UNORM_SRGB : DXGI_FORMAT_R8G8B8A8_UNORM, 4, true)); stbi_image_free(px); return (textures[key] = std::move(t)).get(); }

GpuTexture* Renderer::CreateTextureFromMemory(const unsigned char* d, size_t sz) {
    int w, h, n; stbi_uc* px = stbi_load_from_memory(d, (int)sz, &w, &h, &n, 4); if (!px) return nullptr;
    ownedTextures.push_back(std::make_unique<GpuTexture>(MakeTexture(px, w, h, DXGI_FORMAT_R8G8B8A8_UNORM_SRGB, 4, false))); stbi_image_free(px); return ownedTextures.back().get(); }
D3D12_GPU_DESCRIPTOR_HANDLE Renderer::ImGuiHandle(GpuTexture* t) {
    auto it = imguiHandles.find(t); if (it != imguiHandles.end()) return it->second; D3D12_CPU_DESCRIPTOR_HANDLE c; D3D12_GPU_DESCRIPTOR_HANDLE g; AllocPermanent(&c, &g);
    device->CopyDescriptorsSimple(1, c, CD3DX12_CPU_DESCRIPTOR_HANDLE(cpuSrvHeap->GetCPUDescriptorHandleForHeapStart(), t->cpuIndex, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV); return imguiHandles[t] = g; }

// ---- malhas
Mesh Renderer::BuildPrimitive(bool cube) {
    std::vector<Vertex> v; std::vector<uint32_t> idx;
    auto face = [&](XMFLOAT3 n, XMFLOAT3 r, float half, float uvScale) { XMVECTOR N = XMLoadFloat3(&n), R = XMLoadFloat3(&r), U = XMVector3Cross(-N, R); XMFLOAT3 u; XMStoreFloat3(&u, U); uint32_t b = (uint32_t)v.size();
        auto P = [&](float a, float c) { return XMFLOAT3{ (n.x + r.x * a + u.x * c) * half, (n.y + r.y * a + u.y * c) * half, (n.z + r.z * a + u.z * c) * half }; };
        v.push_back({ P(-1,-1), n, {0, uvScale}, {r.x,r.y,r.z,1} }); v.push_back({ P(-1,1), n, {0,0}, {r.x,r.y,r.z,1} }); v.push_back({ P(1,1), n, {uvScale,0}, {r.x,r.y,r.z,1} }); v.push_back({ P(1,-1), n, {uvScale,uvScale}, {r.x,r.y,r.z,1} });
        for (uint32_t i : { 0u,1u,2u,0u,2u,3u }) idx.push_back(b + i); };
    if (cube) { face({ 0,1,0 }, { 1,0,0 }, .5f, 1); face({ 0,-1,0 }, { 1,0,0 }, .5f, 1); face({ 1,0,0 }, { 0,0,1 }, .5f, 1); face({ -1,0,0 }, { 0,0,-1 }, .5f, 1); face({ 0,0,1 }, { -1,0,0 }, .5f, 1); face({ 0,0,-1 }, { 1,0,0 }, .5f, 1); }
    else { face({ 0,1,0 }, { 1,0,0 }, .5f, 1); }   // plano 1x1 em XZ (y=0); escala via Transform
    SubMesh s; s.indexCount = (uint32_t)idx.size(); s.vb = MakeBuffer(v.data(), v.size() * sizeof(Vertex)); s.ib = MakeBuffer(idx.data(), idx.size() * 4);
    s.vbv = { s.vb->GetGPUVirtualAddress(), (UINT)(v.size() * sizeof(Vertex)), sizeof(Vertex) }; s.ibv = { s.ib->GetGPUVirtualAddress(), (UINT)(idx.size() * 4), DXGI_FORMAT_R32_UINT };
    Mesh m; m.subs.push_back(std::move(s)); return m; }

Mesh* Renderer::GetMesh(const std::string& path) {
    auto it = meshes.find(path); if (it != meshes.end()) return it->second.get();
    auto m = std::make_unique<Mesh>();
    if (path == "builtin:cube") *m = BuildPrimitive(true); else if (path == "builtin:plane") *m = BuildPrimitive(false);
    else {   // Assimp: fbx, obj, gltf/glb, dae, 3ds, blend, ply, stl...
        std::string full = fs::path(path).is_absolute() ? path : assetRoot + "/" + path; Assimp::Importer imp;
        const aiScene* sc = imp.ReadFile(full, aiProcess_Triangulate | aiProcess_GenSmoothNormals | aiProcess_CalcTangentSpace | aiProcess_JoinIdenticalVertices | aiProcess_PreTransformVertices | aiProcess_ConvertToLeftHanded | aiProcess_GenUVCoords | aiProcess_ImproveCacheLocality);
        if (!sc || !sc->mNumMeshes) { Log("[Assimp] %s: %s", full.c_str(), imp.GetErrorString()); meshes[path] = nullptr; return nullptr; }
        fs::path dir = fs::path(full).parent_path();
        for (unsigned mi = 0; mi < sc->mNumMeshes; ++mi) { aiMesh* am = sc->mMeshes[mi]; std::vector<Vertex> v(am->mNumVertices); std::vector<uint32_t> idx;
            for (unsigned i = 0; i < am->mNumVertices; ++i) { Vertex& x = v[i]; x.pos = { am->mVertices[i].x, am->mVertices[i].y, am->mVertices[i].z }; x.normal = am->mNormals ? XMFLOAT3{ am->mNormals[i].x, am->mNormals[i].y, am->mNormals[i].z } : XMFLOAT3{ 0,1,0 };
                x.uv = am->mTextureCoords[0] ? XMFLOAT2{ am->mTextureCoords[0][i].x, am->mTextureCoords[0][i].y } : XMFLOAT2{ 0,0 };
                if (am->mTangents) { aiVector3D t = am->mTangents[i], bt = am->mBitangents[i], n = am->mNormals[i]; float s = ((n ^ t) * bt) < 0 ? -1.f : 1.f; x.tangent = { t.x,t.y,t.z,s }; } else x.tangent = { 1,0,0,1 }; }
            for (unsigned f = 0; f < am->mNumFaces; ++f) for (unsigned k = 0; k < 3; ++k) idx.push_back(am->mFaces[f].mIndices[k]);
            SubMesh s; s.indexCount = (uint32_t)idx.size(); s.vb = MakeBuffer(v.data(), v.size() * sizeof(Vertex)); s.ib = MakeBuffer(idx.data(), idx.size() * 4);
            s.vbv = { s.vb->GetGPUVirtualAddress(), (UINT)(v.size() * sizeof(Vertex)), sizeof(Vertex) }; s.ibv = { s.ib->GetGPUVirtualAddress(), (UINT)(idx.size() * 4), DXGI_FORMAT_R32_UINT };
            if (am->mMaterialIndex < sc->mNumMaterials) { aiMaterial* mat = sc->mMaterials[am->mMaterialIndex]; aiString p; s.hasMaterial = true; aiColor4D c;
                auto tex = [&](std::initializer_list<aiTextureType> types) -> std::string { for (auto t : types) if (mat->GetTextureCount(t) && mat->GetTexture(t, 0, &p) == AI_SUCCESS && p.C_Str()[0] != '*') return (dir / p.C_Str()).string(); return {}; };
                s.albedo = tex({ aiTextureType_BASE_COLOR, aiTextureType_DIFFUSE }); s.normal = tex({ aiTextureType_NORMALS, aiTextureType_HEIGHT }); s.orm = tex({ aiTextureType_UNKNOWN, aiTextureType_AMBIENT_OCCLUSION }); s.emissive = tex({ aiTextureType_EMISSIVE });
                if (mat->Get(AI_MATKEY_COLOR_DIFFUSE, c) == AI_SUCCESS) s.baseColor = { c.r, c.g, c.b, 1 }; }
            m->subs.push_back(std::move(s)); } }
    return (meshes[path] = std::move(m)).get(); }
}
