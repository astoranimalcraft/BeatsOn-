#pragma once
#include "Common.h"
namespace bo {
struct Input {
    bool key[256] = {}, keyPrev[256] = {}, mouse[3] = {}, mousePrev[3] = {};
    float mouseX = 0, mouseY = 0, mouseDX = 0, mouseDY = 0, scroll = 0;
    bool Down(int vk) const { return key[vk & 255]; } bool Pressed(int vk) const { return key[vk & 255] && !keyPrev[vk & 255]; } bool Released(int vk) const { return !key[vk & 255] && keyPrev[vk & 255]; }
    bool MouseDown(int b) const { return mouse[b]; } bool MousePressed(int b) const { return mouse[b] && !mousePrev[b]; }
    void EndFrame() { memcpy(keyPrev, key, sizeof key); memcpy(mousePrev, mouse, sizeof mouse); mouseDX = mouseDY = scroll = 0; }
};
class Window {
public:
    bool Create(const wchar_t* title, int w, int h);
    bool PumpMessages();                     // false = pediu pra fechar
    HWND Handle() const { return hwnd; } int Width() const { return w; } int Height() const { return h; }
    Input input; std::function<void(int, int)> onResize; std::function<LRESULT(HWND, UINT, WPARAM, LPARAM)> preHandler;   // preHandler: ImGui
    void SetCursorCaptured(bool c);          // botao direito: esconde e trava o mouse (olhar ao redor)
    bool captured = false;
private:
    static LRESULT CALLBACK Proc(HWND, UINT, WPARAM, LPARAM); LRESULT Handle(HWND, UINT, WPARAM, LPARAM);
    HWND hwnd{}; int w = 0, h = 0; bool quit = false; POINT lockPos{};
};
// Dialogos de arquivo (Win32): filtro tipo "Audio\0*.mp3;*.wav;*.ogg;*.flac\0Todos\0*.*\0"
std::string OpenFileDialog(HWND owner, const wchar_t* filter); std::string SaveFileDialog(HWND owner, const wchar_t* filter, const wchar_t* defExt); std::string PickFolderDialog(HWND owner);
}
