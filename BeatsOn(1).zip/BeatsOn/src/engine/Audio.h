#pragma once
// BeatsOn! - audio via miniaudio. Suporta .mp3 .wav .flac .ogg(vorbis)
#include <string>
#include <memory>
namespace bo {
class AudioEngine {
public:
    AudioEngine(); ~AudioEngine();
    bool Load(const std::string& path);   // carrega (stream) a musica
    void Play(); void Pause(); void Stop(); void Seek(double ms);
    bool IsPlaying() const; bool IsFinished() const;
    double PositionMs() const; double LengthMs() const;
    void SetVolume(float v); void SetPitch(float p);
    void PlayOneShot(const std::string& path, float volume = 1.f);   // efeitos (hit, miss...)
private: struct Impl; std::unique_ptr<Impl> d;
};
}
