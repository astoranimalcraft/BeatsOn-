#include "Renderer.h"
#include <stdexcept>
#pragma comment(lib, "d3d12.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")
namespace bo {

struct FrameCB { XMFLOAT4X4 viewProj, invViewProj, lightViewProj; XMFLOAT4 camPos, camRight, camUp, sunDir, sunColor, skyParams, viewport, gridParams, post0, post1, flashColor; };
struct ObjectCB { XMFLOAT4X4 world; XMFLOAT4 baseColor, mat, uvRect, flags, flags2, spriteSize; };
static XMFLOAT4X4 T(CXMMATRIX m) { XMFLOAT4X4 o; XMStoreFloat4x4(&o, XMMatrixTranspose(m)); return o; }

// ------------------------------------------------------------------ init
bool Renderer::Init(HWND h, uint32_t w, uint32_t ht, const std::string& shDir, const std::string& root) {
    hwnd = h; width = w; height = ht; shaderDir = shDir; assetRoot = root; frameIndex = kFrames - 1;
    UINT dxgiFlags = 0;
#ifdef _DEBUG
    { ComPtr<ID3D12Debug> dbg; if (SUCCEEDED(D3D12GetDebugInterface(IID_PPV_ARGS(&dbg)))) { dbg->EnableDebugLayer(); dxgiFlags = DXGI_CREATE_FACTORY_DEBUG; } }
#endif
    Check(CreateDXGIFactory2(dxgiFlags, IID_PPV_ARGS(&factory)), "CreateDXGIFactory2");
    ComPtr<IDXGIAdapter1> ad;
    for (UINT i = 0; factory->EnumAdapterByGpuPreference(i, DXGI_GPU_PREFERENCE_HIGH_PERFORMANCE, IID_PPV_ARGS(&ad)) != DXGI_ERROR_NOT_FOUND; ++i) {
        DXGI_ADAPTER_DESC1 d; ad->GetDesc1(&d); if (d.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) continue;
        if (SUCCEEDED(D3D12CreateDevice(ad.Get(), D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), nullptr))) break; }
    Check(D3D12CreateDevice(ad.Get(), D3D_FEATURE_LEVEL_11_0, IID_PPV_ARGS(&device)), "D3D12CreateDevice");
    D3D12_COMMAND_QUEUE_DESC qd{}; qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT; Check(device->CreateCommandQueue(&qd, IID_PPV_ARGS(&queue)), "CreateCommandQueue");
    DXGI_SWAP_CHAIN_DESC1 sd{}; sd.Width = w; sd.Height = ht; sd.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.SampleDesc.Count = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.BufferCount = kBackBuffers; sd.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    ComPtr<IDXGISwapChain1> sc1; Check(factory->CreateSwapChainForHwnd(queue.Get(), hwnd, &sd, nullptr, nullptr, &sc1), "CreateSwapChain");
    sc1.As(&swap); factory->MakeWindowAssociation(hwnd, DXGI_MWA_NO_ALT_ENTER);

    auto mkHeap = [&](D3D12_DESCRIPTOR_HEAP_TYPE t, UINT n, bool visible, ComPtr<ID3D12DescriptorHeap>& out) {
        D3D12_DESCRIPTOR_HEAP_DESC d{}; d.Type = t; d.NumDescriptors = n; d.Flags = visible ? D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE : D3D12_DESCRIPTOR_HEAP_FLAG_NONE;
        Check(device->CreateDescriptorHeap(&d, IID_PPV_ARGS(&out)), "CreateDescriptorHeap"); };
    mkHeap(D3D12_DESCRIPTOR_HEAP_TYPE_RTV, 32, false, rtvHeap); mkHeap(D3D12_DESCRIPTOR_HEAP_TYPE_DSV, 8, false, dsvHeap);
    mkHeap(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV, kCpuSrv, false, cpuSrvHeap);
    mkHeap(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV, kPermanent + kFrames * kPerFrame, true, gpuHeap);
    rtvInc = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV); dsvInc = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_DSV);
    srvInc = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
    rtvCount = kBackBuffers;
    for (UINT i = 0; i < kBackBuffers; ++i) { Check(swap->GetBuffer(i, IID_PPV_ARGS(&backbuffers[i])), "GetBuffer");
        device->CreateRenderTargetView(backbuffers[i].Get(), nullptr, CD3DX12_CPU_DESCRIPTOR_HANDLE(rtvHeap->GetCPUDescriptorHandleForHeapStart(), i, rtvInc)); }
    for (UINT i = 0; i < kFrames; ++i) { Check(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&alloc[i])), "CreateCommandAllocator");
        auto hp = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD); auto rd = CD3DX12_RESOURCE_DESC::Buffer(kUploadSize);
        Check(device->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&uploadBuf[i])), "Upload buffer");
        uploadBuf[i]->Map(0, nullptr, (void**)&uploadPtr[i]); }
    Check(device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, alloc[0].Get(), nullptr, IID_PPV_ARGS(&list)), "CreateCommandList"); list->Close();
    Check(device->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&fence)), "CreateFence"); fenceEvent = CreateEvent(nullptr, FALSE, FALSE, nullptr);

    // mapa de sombras 2048^2
    { D3D12_RESOURCE_DESC rd = CD3DX12_RESOURCE_DESC::Tex2D(DXGI_FORMAT_R32_TYPELESS, 2048, 2048, 1, 1, 1, 0, D3D12_RESOURCE_FLAG_ALLOW_DEPTH_STENCIL);
      D3D12_CLEAR_VALUE cv{}; cv.Format = DXGI_FORMAT_D32_FLOAT; cv.DepthStencil.Depth = 1.f; auto hp = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);
      Check(device->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, &cv, IID_PPV_ARGS(&shadowMap)), "ShadowMap");
      shadowDsv = dsvHeap->GetCPUDescriptorHandleForHeapStart(); dsvCount = 1;
      D3D12_DEPTH_STENCIL_VIEW_DESC dv{}; dv.Format = DXGI_FORMAT_D32_FLOAT; dv.ViewDimension = D3D12_DSV_DIMENSION_TEXTURE2D; device->CreateDepthStencilView(shadowMap.Get(), &dv, shadowDsv);
      shadowSrvCpu = AllocCpuSrv(); D3D12_SHADER_RESOURCE_VIEW_DESC sv{}; sv.Format = DXGI_FORMAT_R32_FLOAT; sv.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
      sv.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING; sv.Texture2D.MipLevels = 1;
      device->CreateShaderResourceView(shadowMap.Get(), &sv, CD3DX12_CPU_DESCRIPTOR_HANDLE(cpuSrvHeap->GetCPUDescriptorHandleForHeapStart(), shadowSrvCpu, srvInc)); }
    CreateBuiltinTextures();
    CreateRootAndPipelines(shaderDir);
    return true;
}
void Renderer::WaitIdle() { fenceValue++; queue->Signal(fence.Get(), fenceValue); if (fence->GetCompletedValue() < fenceValue) { fence->SetEventOnCompletion(fenceValue, fenceEvent); WaitForSingleObject(fenceEvent, INFINITE); } }
void Renderer::Shutdown() { WaitIdle(); if (fenceEvent) CloseHandle(fenceEvent); textures.clear(); meshes.clear(); }
void Renderer::Resize(uint32_t w, uint32_t h) {
    if (!swap || w == 0 || h == 0) return; WaitIdle(); for (auto& b : backbuffers) b.Reset();
    Check(swap->ResizeBuffers(kBackBuffers, w, h, DXGI_FORMAT_R8G8B8A8_UNORM, 0), "ResizeBuffers"); width = w; height = h;
    for (UINT i = 0; i < kBackBuffers; ++i) { swap->GetBuffer(i, IID_PPV_ARGS(&backbuffers[i]));
        device->CreateRenderTargetView(backbuffers[i].Get(), nullptr, CD3DX12_CPU_DESCRIPTOR_HANDLE(rtvHeap->GetCPUDescriptorHandleForHeapStart(), i, rtvInc)); }
}
uint32_t Renderer::AllocCpuSrv() { if (cpuSrvCount >= kCpuSrv) throw std::runtime_error("CPU SRV heap cheio"); return cpuSrvCount++; }
void Renderer::AllocPermanent(D3D12_CPU_DESCRIPTOR_HANDLE* cpu, D3D12_GPU_DESCRIPTOR_HANDLE* gpu) {
    if (permCount >= kPermanent) throw std::runtime_error("heap permanente cheio");
    *cpu = CD3DX12_CPU_DESCRIPTOR_HANDLE(gpuHeap->GetCPUDescriptorHandleForHeapStart(), permCount, srvInc);
    *gpu = CD3DX12_GPU_DESCRIPTOR_HANDLE(gpuHeap->GetGPUDescriptorHandleForHeapStart(), permCount, srvInc); permCount++; }
D3D12_GPU_DESCRIPTOR_HANDLE Renderer::AllocTable(uint32_t n, D3D12_CPU_DESCRIPTOR_HANDLE* cpu) {
    if (frameDescOffset + n > kPerFrame) { frameDescOffset = 0; Log("[BeatsOn] aviso: heap de descritores do frame estourou"); }
    uint32_t idx = kPermanent + frameIndex * kPerFrame + frameDescOffset; frameDescOffset += n;
    *cpu = CD3DX12_CPU_DESCRIPTOR_HANDLE(gpuHeap->GetCPUDescriptorHandleForHeapStart(), idx, srvInc);
    return CD3DX12_GPU_DESCRIPTOR_HANDLE(gpuHeap->GetGPUDescriptorHandleForHeapStart(), idx, srvInc); }
Renderer::Upload Renderer::AllocUpload(size_t size) {
    size = (size + 255) & ~size_t(255); if (uploadOffset + size > kUploadSize) { uploadOffset = 0; Log("[BeatsOn] aviso: upload ring estourou"); }
    Upload u{ uploadBuf[frameIndex]->GetGPUVirtualAddress() + uploadOffset, uploadPtr[frameIndex] + uploadOffset }; uploadOffset += size; return u; }
void Renderer::Transition(ID3D12Resource* r, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b) { if (a == b) return; auto br = CD3DX12_RESOURCE_BARRIER::Transition(r, a, b); list->ResourceBarrier(1, &br); }

// ------------------------------------------------------------------ pipelines
ComPtr<ID3DBlob> Renderer::Compile(const std::string& file, const char* entry, const char* target) {
    UINT fl = D3DCOMPILE_ENABLE_STRICTNESS;
#ifdef _DEBUG
    fl |= D3DCOMPILE_DEBUG | D3DCOMPILE_SKIP_OPTIMIZATION;
#else
    fl |= D3DCOMPILE_OPTIMIZATION_LEVEL3;
#endif
    ComPtr<ID3DBlob> code, err; std::wstring w(file.begin(), file.end());
    HRESULT hr = D3DCompileFromFile(w.c_str(), nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE, entry, target, fl, 0, &code, &err);
    if (FAILED(hr)) { std::string m = err ? (const char*)err->GetBufferPointer() : "erro desconhecido"; Log("[Shader] %s (%s): %s", file.c_str(), entry, m.c_str()); throw std::runtime_error(m); }
    return code; }
ComPtr<ID3D12PipelineState> Renderer::MakePSO(const std::string& file, const char* vs, const char* ps, bool mesh, DXGI_FORMAT rt, bool depth, bool depthWrite, bool blend, D3D12_CULL_MODE cull, bool shadow) {
    auto vsb = Compile(file, vs, "vs_5_1"); ComPtr<ID3DBlob> psb; if (ps) psb = Compile(file, ps, "ps_5_1");
    static const D3D12_INPUT_ELEMENT_DESC il[] = {
        {"POSITION",0,DXGI_FORMAT_R32G32B32_FLOAT,0,0,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0}, {"NORMAL",0,DXGI_FORMAT_R32G32B32_FLOAT,0,12,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0},
        {"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,24,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0}, {"TANGENT",0,DXGI_FORMAT_R32G32B32A32_FLOAT,0,32,D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA,0} };
    D3D12_GRAPHICS_PIPELINE_STATE_DESC d{}; d.pRootSignature = rootSig.Get(); d.VS = CD3DX12_SHADER_BYTECODE(vsb.Get()); if (psb) d.PS = CD3DX12_SHADER_BYTECODE(psb.Get());
    if (mesh) { d.InputLayout = { il, 4 }; }
    d.RasterizerState = CD3DX12_RASTERIZER_DESC(D3D12_DEFAULT); d.RasterizerState.CullMode = cull; d.RasterizerState.DepthClipEnable = TRUE;
    if (shadow) { d.RasterizerState.DepthBias = 1500; d.RasterizerState.SlopeScaledDepthBias = 2.0f; }
    d.BlendState = CD3DX12_BLEND_DESC(D3D12_DEFAULT);
    if (blend) { auto& b = d.BlendState.RenderTarget[0]; b.BlendEnable = TRUE; b.SrcBlend = D3D12_BLEND_SRC_ALPHA; b.DestBlend = D3D12_BLEND_INV_SRC_ALPHA; b.BlendOp = D3D12_BLEND_OP_ADD;
        b.SrcBlendAlpha = D3D12_BLEND_ZERO; b.DestBlendAlpha = D3D12_BLEND_ONE; b.BlendOpAlpha = D3D12_BLEND_OP_ADD; }
    d.DepthStencilState = CD3DX12_DEPTH_STENCIL_DESC(D3D12_DEFAULT); d.DepthStencilState.DepthEnable = depth;
    d.DepthStencilState.DepthWriteMask = depthWrite ? D3D12_DEPTH_WRITE_MASK_ALL : D3D12_DEPTH_WRITE_MASK_ZERO;
    d.SampleMask = UINT_MAX; d.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
    if (rt != DXGI_FORMAT_UNKNOWN) { d.NumRenderTargets = 1; d.RTVFormats[0] = rt; } d.DSVFormat = (rt == DXGI_FORMAT_R8G8B8A8_UNORM) ? DXGI_FORMAT_UNKNOWN : DXGI_FORMAT_D32_FLOAT; d.SampleDesc.Count = 1;
    ComPtr<ID3D12PipelineState> pso; Check(device->CreateGraphicsPipelineState(&d, IID_PPV_ARGS(&pso)), "CreateGraphicsPipelineState"); return pso; }
void Renderer::CreateRootAndPipelines(const std::string& dir) {
    CD3DX12_DESCRIPTOR_RANGE r0(D3D12_DESCRIPTOR_RANGE_TYPE_SRV, 4, 0), r1(D3D12_DESCRIPTOR_RANGE_TYPE_SRV, 2, 4);
    CD3DX12_ROOT_PARAMETER p[4]; p[0].InitAsConstantBufferView(0); p[1].InitAsConstantBufferView(1); p[2].InitAsDescriptorTable(1, &r0); p[3].InitAsDescriptorTable(1, &r1);
    CD3DX12_STATIC_SAMPLER_DESC s0(0, D3D12_FILTER_ANISOTROPIC, D3D12_TEXTURE_ADDRESS_MODE_WRAP, D3D12_TEXTURE_ADDRESS_MODE_WRAP, D3D12_TEXTURE_ADDRESS_MODE_WRAP, 0.f, 8);
    CD3DX12_STATIC_SAMPLER_DESC s1(1, D3D12_FILTER_COMPARISON_MIN_MAG_LINEAR_MIP_POINT, D3D12_TEXTURE_ADDRESS_MODE_CLAMP, D3D12_TEXTURE_ADDRESS_MODE_CLAMP, D3D12_TEXTURE_ADDRESS_MODE_CLAMP, 0.f, 1, D3D12_COMPARISON_FUNC_LESS_EQUAL);
    D3D12_STATIC_SAMPLER_DESC ss[] = { s0, s1 }; CD3DX12_ROOT_SIGNATURE_DESC rs(4, p, 2, ss, D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT);
    ComPtr<ID3DBlob> blob, err; HRESULT hr = D3D12SerializeRootSignature(&rs, D3D_ROOT_SIGNATURE_VERSION_1, &blob, &err);
    if (FAILED(hr)) throw std::runtime_error(err ? (const char*)err->GetBufferPointer() : "root signature");
    Check(device->CreateRootSignature(0, blob->GetBufferPointer(), blob->GetBufferSize(), IID_PPV_ARGS(&rootSig)), "CreateRootSignature");
    std::string f = dir + "/BeatsOn.hlsl"; const DXGI_FORMAT HDR = DXGI_FORMAT_R16G16B16A16_FLOAT, LDR = DXGI_FORMAT_R8G8B8A8_UNORM;
    psoSky = MakePSO(f, "VS_Full", "PS_Sky", false, HDR, false, false, false, D3D12_CULL_MODE_NONE);
    psoMesh = MakePSO(f, "VS_Mesh", "PS_Mesh", true, HDR, true, true, false, D3D12_CULL_MODE_BACK);
    psoShadow = MakePSO(f, "VS_Shadow", nullptr, true, DXGI_FORMAT_UNKNOWN, true, true, false, D3D12_CULL_MODE_NONE, true);
    psoGrid = MakePSO(f, "VS_Full", "PS_Grid", false, HDR, true, false, true, D3D12_CULL_MODE_NONE);
    psoAxis = MakePSO(f, "VS_Full", "PS_AxisY", false, HDR, false, false, true, D3D12_CULL_MODE_NONE);
    psoSprite = MakePSO(f, "VS_Sprite", "PS_Sprite", false, HDR, true, false, true, D3D12_CULL_MODE_NONE);
    psoPost = MakePSO(f, "VS_Full", "PS_Post", false, LDR, false, false, false, D3D12_CULL_MODE_NONE);
}

// ------------------------------------------------------------------ frame
void Renderer::BeginFrame() {
    frameIndex = (frameIndex + 1) % kFrames;
    if (fence->GetCompletedValue() < frameFence[frameIndex]) { fence->SetEventOnCompletion(frameFence[frameIndex], fenceEvent); WaitForSingleObject(fenceEvent, INFINITE); }
    alloc[frameIndex]->Reset(); list->Reset(alloc[frameIndex].Get(), nullptr); backIndex = swap->GetCurrentBackBufferIndex();
    ID3D12DescriptorHeap* heaps[] = { gpuHeap.Get() }; list->SetDescriptorHeaps(1, heaps); frameDescOffset = 0; uploadOffset = 0; bbRT = false; inFrame = true; }
void Renderer::BeginBackbuffer(const float* clear) {
    if (!bbRT) { Transition(backbuffers[backIndex].Get(), D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_RENDER_TARGET); bbRT = true; }
    auto rtv = CD3DX12_CPU_DESCRIPTOR_HANDLE(rtvHeap->GetCPUDescriptorHandleForHeapStart(), backIndex, rtvInc);
    list->OMSetRenderTargets(1, &rtv, FALSE, nullptr); if (clear) list->ClearRenderTargetView(rtv, clear, 0, nullptr);
    D3D12_VIEWPORT vp{ 0,0,(float)width,(float)height,0,1 }; D3D12_RECT sc{ 0,0,(LONG)width,(LONG)height }; list->RSSetViewports(1, &vp); list->RSSetScissorRects(1, &sc); }
void Renderer::EndFrame() {
    if (!bbRT) Transition(backbuffers[backIndex].Get(), D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_RENDER_TARGET);
    Transition(backbuffers[backIndex].Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_PRESENT);
    list->Close(); ID3D12CommandList* l[] = { list.Get() }; queue->ExecuteCommandLists(1, l); swap->Present(1, 0);
    fenceValue++; queue->Signal(fence.Get(), fenceValue); frameFence[frameIndex] = fenceValue; inFrame = false; }

void Renderer::CreateViewport(ViewportTarget& vt, uint32_t w, uint32_t h) {
    w = std::max(w, 16u); h = std::max(h, 16u); if (vt.inited && vt.w == w && vt.h == h) return;
    if (vt.inited) WaitIdle();
    else { vt.rtvHdr = CD3DX12_CPU_DESCRIPTOR_HANDLE(rtvHeap->GetCPUDescriptorHandleForHeapStart(), rtvCount++, rtvInc);
           vt.rtvLdr = CD3DX12_CPU_DESCRIPTOR_HANDLE(rtvHeap->GetCPUDescriptorHandleForHeapStart(), rtvCount++, rtvInc);
           vt.dsv = CD3DX12_CPU_DESCRIPTOR_HANDLE(dsvHeap->GetCPUDescriptorHandleForHeapStart(), dsvCount++, dsvInc);
           vt.hdrSrvCpu = AllocCpuSrv(); AllocPermanent(&vt.ldrSrvCpuPermanent, &vt.ldrGpu); vt.inited = true; }
    vt.w = w; vt.h = h; auto hp = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);
    { auto rd = CD3DX12_RESOURCE_DESC::Tex2D(DXGI_FORMAT_R16G16B16A16_FLOAT, w, h, 1, 1, 1, 0, D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET);
      D3D12_CLEAR_VALUE cv{}; cv.Format = rd.Format; vt.hdr.Reset();
      Check(device->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, &cv, IID_PPV_ARGS(&vt.hdr)), "HDR target");
      device->CreateRenderTargetView(vt.hdr.Get(), nullptr, vt.rtvHdr);
      device->CreateShaderResourceView(vt.hdr.Get(), nullptr, CD3DX12_CPU_DESCRIPTOR_HANDLE(cpuSrvHeap->GetCPUDescriptorHandleForHeapStart(), vt.hdrSrvCpu, srvInc)); }
    { auto rd = CD3DX12_RESOURCE_DESC::Tex2D(DXGI_FORMAT_R8G8B8A8_UNORM, w, h, 1, 1, 1, 0, D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET);
      D3D12_CLEAR_VALUE cv{}; cv.Format = rd.Format; vt.ldr.Reset();
      Check(device->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, &cv, IID_PPV_ARGS(&vt.ldr)), "LDR target");
      device->CreateRenderTargetView(vt.ldr.Get(), nullptr, vt.rtvLdr); device->CreateShaderResourceView(vt.ldr.Get(), nullptr, vt.ldrSrvCpuPermanent); }
    { auto rd = CD3DX12_RESOURCE_DESC::Tex2D(DXGI_FORMAT_D32_FLOAT, w, h, 1, 1, 1, 0, D3D12_RESOURCE_FLAG_ALLOW_DEPTH_STENCIL);
      D3D12_CLEAR_VALUE cv{}; cv.Format = DXGI_FORMAT_D32_FLOAT; cv.DepthStencil.Depth = 1.f; vt.depth.Reset();
      Check(device->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_DEPTH_WRITE, &cv, IID_PPV_ARGS(&vt.depth)), "Depth target");
      device->CreateDepthStencilView(vt.depth.Get(), nullptr, vt.dsv); }
}

void Renderer::BlitToBackbuffer(ViewportTarget& vt) {
    auto* bb = backbuffers[backIndex].Get(); Transition(bb, bbRT ? D3D12_RESOURCE_STATE_RENDER_TARGET : D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_COPY_DEST);
    Transition(vt.ldr.Get(), D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_SOURCE);
    if (vt.w == width && vt.h == height) list->CopyResource(bb, vt.ldr.Get());
    Transition(vt.ldr.Get(), D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
    Transition(bb, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_RENDER_TARGET); bbRT = true; }

// ------------------------------------------------------------------ render da cena
void Renderer::DrawMeshes(Scene& scene, bool shadowPass, D3D12_GPU_VIRTUAL_ADDRESS, D3D12_GPU_DESCRIPTOR_HANDLE) {
    for (auto& e : scene.entities) {
        if (!e->active || !e->model || e->model->model.empty()) continue; auto& m = *e->model; if (shadowPass && !m.castShadow) continue;
        Mesh* mesh = GetMesh(m.model); if (!mesh) continue; XMMATRIX w = e->World(scene);
        for (auto& sm : mesh->subs) {
            ObjectCB oc{}; oc.world = T(w);
            std::string a = !m.albedo.empty() ? m.albedo : sm.albedo, n = !m.normal.empty() ? m.normal : sm.normal, o = !m.orm.empty() ? m.orm : sm.orm, em = !m.emissive.empty() ? m.emissive : sm.emissive;
            XMFLOAT4 bc = m.baseColor; if (sm.hasMaterial && m.model.rfind("builtin:", 0) != 0) { bc.x *= sm.baseColor.x; bc.y *= sm.baseColor.y; bc.z *= sm.baseColor.z; }
            oc.baseColor = bc; oc.mat = { m.metallic, m.roughness, 1.f, m.emissiveStrength };
            GpuTexture* ta = a.empty() ? nullptr : GetTexture(a, true); GpuTexture* tn = n.empty() ? nullptr : GetTexture(n, false);
            GpuTexture* to = o.empty() ? nullptr : GetTexture(o, false); GpuTexture* te = em.empty() ? nullptr : GetTexture(em, true);
            oc.flags = { ta ? 1.f : 0.f, tn ? 1.f : 0.f, to ? 1.f : 0.f, te ? 1.f : 0.f };
            auto up = AllocUpload(sizeof(ObjectCB)); memcpy(up.cpu, &oc, sizeof(oc)); list->SetGraphicsRootConstantBufferView(1, up.va);
            if (!shadowPass) { D3D12_CPU_DESCRIPTOR_HANDLE cpu; auto gpu = AllocTable(4, &cpu); GpuTexture* t4[4] = { ta ? ta : &whiteTex, tn ? tn : &flatNormalTex, to ? to : &whiteTex, te ? te : &blackTex };
                for (int i = 0; i < 4; ++i) device->CopyDescriptorsSimple(1, CD3DX12_CPU_DESCRIPTOR_HANDLE(cpu, i, srvInc), CD3DX12_CPU_DESCRIPTOR_HANDLE(cpuSrvHeap->GetCPUDescriptorHandleForHeapStart(), t4[i]->cpuIndex, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
                list->SetGraphicsRootDescriptorTable(2, gpu); }
            list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST); list->IASetVertexBuffers(0, 1, &sm.vbv); list->IASetIndexBuffer(&sm.ibv); list->DrawIndexedInstanced(sm.indexCount, 1, 0, 0, 0);
        } } }

void Renderer::RenderScene(Scene& scene, const RenderView& rv, ViewportTarget& vt) {
    // --- sol / ceu
    SkyComponent sky; LightComponent light; for (auto& e : scene.entities) { if (!e->active) continue; if (e->sky) sky = *e->sky; if (e->light) light = *e->light; }
    float el = XMConvertToRadians(sky.sunElevation), az = XMConvertToRadians(sky.sunAzimuth);
    XMFLOAT3 sunDir{ cosf(el) * sinf(az), sinf(el), cosf(el) * cosf(az) };
    bool useHdri = !sky.procedural && hdri; if (!sky.hdri.empty() && !hdri && !sky.procedural) { LoadHDRI(sky.hdri); useHdri = hdri != nullptr; }
    XMVECTOR sd = XMLoadFloat3(&sunDir), center = XMVectorZero();
    XMMATRIX lview = XMMatrixLookAtLH(center + sd * 60.f, center, XMVectorSet(0, 1, 0, 0)), lproj = XMMatrixOrthographicLH(50, 50, 1, 140), lvp = lview * lproj;
    XMMATRIX vp = rv.view * rv.proj; XMVECTOR det; XMMATRIX ivp = XMMatrixInverse(&det, vp);
    FrameCB fc{}; fc.viewProj = T(vp); fc.invViewProj = T(ivp); fc.lightViewProj = T(lvp); fc.camPos = { rv.camPos.x, rv.camPos.y, rv.camPos.z, 1 };
    XMFLOAT4X4 V; XMStoreFloat4x4(&V, rv.view); fc.camRight = { V._11, V._21, V._31, 0 }; fc.camUp = { V._12, V._22, V._32, 0 };
    float sunH = std::max(sunDir.y, 0.f); fc.sunDir = { sunDir.x, sunDir.y, sunDir.z, 0 };
    float k = light.intensity * std::min(1.f, sunH * 3.f + 0.02f); fc.sunColor = { light.color.x * k, light.color.y * k, light.color.z * k, 1 };
    fc.skyParams = { rv.time, sky.cloudCover, sky.cloudDensity, useHdri ? 1.f : 0.f }; fc.viewport = { (float)vt.w, (float)vt.h, 1.f / vt.w, 1.f / vt.h };
    fc.gridParams = { 1.f, 10.f, 80.f, rv.drawGrid ? 1.f : 0.f }; auto& P = rv.post;
    fc.post0 = { P.exposure, P.bloom, P.vignette, P.chroma }; fc.post1 = { P.saturation, P.contrast, P.grain, P.flash }; fc.flashColor = { P.flashColor.x, P.flashColor.y, P.flashColor.z, sky.hdriIntensity };
    auto fUp = AllocUpload(sizeof(FrameCB)); memcpy(fUp.cpu, &fc, sizeof(fc));
    D3D12_CPU_DESCRIPTOR_HANDLE gcpu; auto globals = AllocTable(2, &gcpu); auto base = cpuSrvHeap->GetCPUDescriptorHandleForHeapStart();
    device->CopyDescriptorsSimple(1, gcpu, CD3DX12_CPU_DESCRIPTOR_HANDLE(base, shadowSrvCpu, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
    device->CopyDescriptorsSimple(1, CD3DX12_CPU_DESCRIPTOR_HANDLE(gcpu, 1, srvInc), CD3DX12_CPU_DESCRIPTOR_HANDLE(base, (useHdri ? hdri.get() : &dummyHdri)->cpuIndex, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

    list->SetGraphicsRootSignature(rootSig.Get()); list->SetGraphicsRootConstantBufferView(0, fUp.va); list->SetGraphicsRootDescriptorTable(3, globals);
    ObjectCB def{}; def.world = T(XMMatrixIdentity()); def.baseColor = { 1,1,1,1 }; def.uvRect = { 0,0,1,1 }; auto dUp = AllocUpload(sizeof(def)); memcpy(dUp.cpu, &def, sizeof(def));
    auto bindDefaults = [&]() { list->SetGraphicsRootConstantBufferView(1, dUp.va); D3D12_CPU_DESCRIPTOR_HANDLE c; auto g = AllocTable(4, &c);
        for (int i = 0; i < 4; ++i) device->CopyDescriptorsSimple(1, CD3DX12_CPU_DESCRIPTOR_HANDLE(c, i, srvInc), CD3DX12_CPU_DESCRIPTOR_HANDLE(base, whiteTex.cpuIndex, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        list->SetGraphicsRootDescriptorTable(2, g); };

    // --- sombras
    Transition(shadowMap.Get(), D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_DEPTH_WRITE);
    list->OMSetRenderTargets(0, nullptr, FALSE, &shadowDsv); list->ClearDepthStencilView(shadowDsv, D3D12_CLEAR_FLAG_DEPTH, 1.f, 0, 0, nullptr);
    { D3D12_VIEWPORT v{ 0,0,2048,2048,0,1 }; D3D12_RECT r{ 0,0,2048,2048 }; list->RSSetViewports(1, &v); list->RSSetScissorRects(1, &r); }
    list->SetPipelineState(psoShadow.Get()); bindDefaults(); DrawMeshes(scene, true, 0, globals);
    Transition(shadowMap.Get(), D3D12_RESOURCE_STATE_DEPTH_WRITE, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);

    // --- cena HDR
    Transition(vt.hdr.Get(), D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
    list->OMSetRenderTargets(1, &vt.rtvHdr, FALSE, &vt.dsv); const float black[4] = { 0,0,0,1 };
    list->ClearRenderTargetView(vt.rtvHdr, black, 0, nullptr); list->ClearDepthStencilView(vt.dsv, D3D12_CLEAR_FLAG_DEPTH, 1.f, 0, 0, nullptr);
    { D3D12_VIEWPORT v{ 0,0,(float)vt.w,(float)vt.h,0,1 }; D3D12_RECT r{ 0,0,(LONG)vt.w,(LONG)vt.h }; list->RSSetViewports(1, &v); list->RSSetScissorRects(1, &r); }
    list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    bindDefaults(); list->SetPipelineState(psoSky.Get()); list->DrawInstanced(3, 1, 0, 0);
    list->SetPipelineState(psoMesh.Get()); DrawMeshes(scene, false, 0, globals);
    if (rv.drawGrid) { bindDefaults(); list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        list->SetPipelineState(psoGrid.Get()); list->DrawInstanced(3, 1, 0, 0); list->SetPipelineState(psoAxis.Get()); list->DrawInstanced(3, 1, 0, 0); }
    // sprites (ordenados: sortOrder, depois distancia - mais longe primeiro)
    struct SD { Entity* e; float dist; }; std::vector<SD> spr; XMVECTOR fwd = XMVectorSet(V._13, V._23, V._33, 0), cp = XMLoadFloat3(&rv.camPos);
    for (auto& e : scene.entities) if (e->active && e->sprite) { XMFLOAT3 p; XMStoreFloat3(&p, e->World(scene).r[3]); spr.push_back({ e.get(), XMVectorGetX(XMVector3Dot(XMLoadFloat3(&p) - cp, fwd)) }); }
    std::sort(spr.begin(), spr.end(), [](const SD& a, const SD& b) { return a.e->sprite->sortOrder != b.e->sprite->sortOrder ? a.e->sprite->sortOrder < b.e->sprite->sortOrder : a.dist > b.dist; });
    list->SetPipelineState(psoSprite.Get()); list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
    for (auto& s : spr) { auto& sp = *s.e->sprite; ObjectCB oc{}; oc.world = T(s.e->World(scene)); oc.baseColor = sp.tint; oc.uvRect = sp.uvRect; oc.mat = { 0,1,1,0 };
        oc.flags2 = { sp.billboard ? 1.f : 0.f, sp.flipX ? 1.f : 0.f, sp.lit ? 1.f : 0.f, 0 }; oc.spriteSize = { sp.size.x, sp.size.y, sp.pivot.x, sp.pivot.y };
        auto up = AllocUpload(sizeof(oc)); memcpy(up.cpu, &oc, sizeof(oc)); list->SetGraphicsRootConstantBufferView(1, up.va);
        GpuTexture* t = sp.texture.empty() ? &whiteTex : GetTexture(sp.texture, true); D3D12_CPU_DESCRIPTOR_HANDLE c; auto g = AllocTable(4, &c);
        for (int i = 0; i < 4; ++i) device->CopyDescriptorsSimple(1, CD3DX12_CPU_DESCRIPTOR_HANDLE(c, i, srvInc), CD3DX12_CPU_DESCRIPTOR_HANDLE(base, (i == 0 ? t : &whiteTex)->cpuIndex, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        list->SetGraphicsRootDescriptorTable(2, g); list->DrawInstanced(4, 1, 0, 0); }
    Transition(vt.hdr.Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);

    // --- pos-processamento
    Transition(vt.ldr.Get(), D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
    list->OMSetRenderTargets(1, &vt.rtvLdr, FALSE, nullptr); list->SetPipelineState(psoPost.Get()); list->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    { D3D12_CPU_DESCRIPTOR_HANDLE c; auto g = AllocTable(4, &c);
      device->CopyDescriptorsSimple(1, c, CD3DX12_CPU_DESCRIPTOR_HANDLE(base, vt.hdrSrvCpu, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
      for (int i = 1; i < 4; ++i) device->CopyDescriptorsSimple(1, CD3DX12_CPU_DESCRIPTOR_HANDLE(c, i, srvInc), CD3DX12_CPU_DESCRIPTOR_HANDLE(base, whiteTex.cpuIndex, srvInc), D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
      list->SetGraphicsRootDescriptorTable(2, g); }
    list->DrawInstanced(3, 1, 0, 0);
    Transition(vt.ldr.Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
}
}
