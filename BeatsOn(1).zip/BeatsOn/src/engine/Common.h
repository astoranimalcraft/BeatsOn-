#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <d3dcompiler.h>
#include <directx/d3dx12.h>
#include <DirectXMath.h>
#include <wrl/client.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <memory>
#include <functional>
#include <optional>
#include <cstdint>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <cstdarg>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include "../../third_party/json.hpp"

namespace bo {
using Microsoft::WRL::ComPtr;
using namespace DirectX;
namespace fs = std::filesystem;
inline void Check(HRESULT hr, const char* what) {
    if (FAILED(hr)) { char b[256]; snprintf(b, 256, "[BeatsOn] %s falhou (HRESULT 0x%08X)\n", what, (unsigned)hr); OutputDebugStringA(b); fputs(b, stderr); throw std::runtime_error(b); }
}
inline std::vector<std::string>& LogBuffer() { static std::vector<std::string> b; return b; }
inline void Log(const char* fmt, ...) { char b[1024]; va_list a; va_start(a, fmt); vsnprintf(b, 1024, fmt, a); va_end(a); OutputDebugStringA(b); OutputDebugStringA("\n"); puts(b); LogBuffer().push_back(b); if (LogBuffer().size() > 2000) LogBuffer().erase(LogBuffer().begin(), LogBuffer().begin() + 500); }
}
