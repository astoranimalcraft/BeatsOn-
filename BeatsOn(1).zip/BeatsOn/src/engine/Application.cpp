#include "Application.h"
#include <imgui_impl_win32.h>
#include <imgui_impl_dx12.h>
#include <ImGuizmo.h>
#include "../editor/IconsFontAwesome6.h"
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);
namespace bo {
void ApplyBeatsOnTheme() {   // tema escuro moderno (roxo/ciano)
    ImGuiStyle& s = ImGui::GetStyle(); s.WindowRounding = 8; s.ChildRounding = 6; s.FrameRounding = 6; s.PopupRounding = 8; s.ScrollbarRounding = 10; s.GrabRounding = 6; s.TabRounding = 6;
    s.WindowPadding = { 10,10 }; s.FramePadding = { 10,6 }; s.ItemSpacing = { 8,7 }; s.ItemInnerSpacing = { 6,5 }; s.WindowBorderSize = 1; s.FrameBorderSize = 0; s.TabBarBorderSize = 0; s.SeparatorTextBorderSize = 2; s.WindowMenuButtonPosition = ImGuiDir_None;
    ImVec4* c = s.Colors; auto C = [](int r, int g, int b, int a = 255) { return ImVec4(r / 255.f, g / 255.f, b / 255.f, a / 255.f); };
    ImVec4 bg = C(16,16,22), panel = C(24,24,34), raised = C(36,36,52), hover = C(52,50,78), accent = C(138,92,246), accent2 = C(34,211,238);
    c[ImGuiCol_WindowBg] = panel; c[ImGuiCol_ChildBg] = bg; c[ImGuiCol_PopupBg] = C(20,20,30,250); c[ImGuiCol_Border] = C(48,48,68); c[ImGuiCol_Text] = C(232,232,242); c[ImGuiCol_TextDisabled] = C(128,128,150);
    c[ImGuiCol_FrameBg] = raised; c[ImGuiCol_FrameBgHovered] = hover; c[ImGuiCol_FrameBgActive] = C(66,60,100); c[ImGuiCol_TitleBg] = bg; c[ImGuiCol_TitleBgActive] = bg; c[ImGuiCol_MenuBarBg] = bg;
    c[ImGuiCol_Button] = raised; c[ImGuiCol_ButtonHovered] = hover; c[ImGuiCol_ButtonActive] = accent; c[ImGuiCol_Header] = C(138,92,246,70); c[ImGuiCol_HeaderHovered] = C(138,92,246,120); c[ImGuiCol_HeaderActive] = C(138,92,246,170);
    c[ImGuiCol_Tab] = bg; c[ImGuiCol_TabHovered] = C(138,92,246,150); c[ImGuiCol_TabSelected] = C(60,48,110); c[ImGuiCol_TabDimmed] = bg; c[ImGuiCol_TabDimmedSelected] = raised; c[ImGuiCol_TabSelectedOverline] = accent;
    c[ImGuiCol_CheckMark] = accent2; c[ImGuiCol_SliderGrab] = accent; c[ImGuiCol_SliderGrabActive] = accent2; c[ImGuiCol_Separator] = C(48,48,68); c[ImGuiCol_ResizeGrip] = C(138,92,246,60);
    c[ImGuiCol_DockingPreview] = C(138,92,246,150); c[ImGuiCol_DockingEmptyBg] = bg; c[ImGuiCol_ScrollbarBg] = bg; c[ImGuiCol_ScrollbarGrab] = raised; c[ImGuiCol_TextSelectedBg] = C(138,92,246,110); c[ImGuiCol_NavHighlight] = accent2; }

void Application::SetupImGui(bool editorStyle) {
    IMGUI_CHECKVERSION(); ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard; if (editorStyle) io.ConfigFlags |= ImGuiConfigFlags_DockingEnable; io.IniFilename = nullptr;
    ApplyBeatsOnTheme(); fs::path fonts = exeDir / "assets" / "fonts"; ImFontConfig cfg; cfg.OversampleH = 3; cfg.OversampleV = 2;
    std::string inter = (fonts / "Inter.ttf").string(), fa = (fonts / "fa-solid-900.ttf").string(); static const ImWchar range[] = { ICON_MIN_FA, ICON_MAX_16_FA, 0 };
    if (fs::exists(inter)) io.Fonts->AddFontFromFileTTF(inter.c_str(), 17.f, &cfg); else io.Fonts->AddFontDefault();
    if (fs::exists(fa)) { ImFontConfig ic; ic.MergeMode = true; ic.PixelSnapH = true; ic.GlyphMinAdvanceX = 17.f; io.Fonts->AddFontFromFileTTF(fa.c_str(), 15.f, &ic, range); }
    if (fs::exists(inter)) { fontBig = io.Fonts->AddFontFromFileTTF(inter.c_str(), 34.f, &cfg); if (fs::exists(fa)) { ImFontConfig ic; ic.MergeMode = true; ic.GlyphMinAdvanceX = 30.f; io.Fonts->AddFontFromFileTTF(fa.c_str(), 28.f, &ic, range); } }
    ImGui_ImplWin32_Init(window.Handle()); D3D12_CPU_DESCRIPTOR_HANDLE c; D3D12_GPU_DESCRIPTOR_HANDLE g; renderer.AllocPermanent(&c, &g);
    ImGui_ImplDX12_Init(renderer.Device(), kFrames, renderer.BackbufferFormat(), renderer.GpuHeap(), c, g); window.preHandler = [](HWND h, UINT m, WPARAM w, LPARAM l) -> LRESULT { return ImGui_ImplWin32_WndProcHandler(h, m, w, l); }; }

int Application::Run(const wchar_t* title, int w, int h, bool editorStyle) {
    wchar_t buf[MAX_PATH]; GetModuleFileNameW(nullptr, buf, MAX_PATH); exeDir = fs::path(buf).parent_path(); CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    try {
        if (!window.Create(title, w, h)) return 1; RAWINPUTDEVICE rid{ 0x01, 0x02, 0, window.Handle() }; RegisterRawInputDevices(&rid, 1, sizeof rid);
        RECT rc; GetClientRect(window.Handle(), &rc); renderer.Init(window.Handle(), rc.right, rc.bottom, (exeDir / "assets" / "shaders").string(), (exeDir).string());
        window.onResize = [&](int W, int H) { renderer.Resize(W, H); }; audio = std::make_unique<AudioEngine>(); scripts.Init((exeDir / "scripting").string()); SetupImGui(editorStyle);
        if (!OnInit()) return 2; LARGE_INTEGER f, t0, t1; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&t0);
        while (window.PumpMessages()) {
            QueryPerformanceCounter(&t1); float dt = std::min(0.1f, (float)(t1.QuadPart - t0.QuadPart) / f.QuadPart); t0 = t1; if (IsIconic(window.Handle())) { Sleep(30); continue; }
            renderer.BeginFrame(); ImGui_ImplDX12_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame(); ImGuizmo::BeginFrame();
            if (dockspace) ImGui::DockSpaceOverViewport(0, ImGui::GetMainViewport(), ImGuiDockNodeFlags_PassthruCentralNode);
            OnUpdate(dt); OnGui(); ImGui::Render(); OnRender();
            const float clear[4] = { 0.06f, 0.06f, 0.09f, 1 }; renderer.BeginBackbuffer(renderer.BackbufferActive() ? nullptr : clear); ImGui_ImplDX12_RenderDrawData(ImGui::GetDrawData(), renderer.List()); renderer.EndFrame(); window.input.EndFrame(); }
        OnShutdown(); renderer.WaitIdle(); ImGui_ImplDX12_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext(); renderer.Shutdown();
    } catch (const std::exception& e) { MessageBoxA(nullptr, e.what(), "BeatsOn! - erro fatal", MB_ICONERROR); return 3; } return 0; }
}
