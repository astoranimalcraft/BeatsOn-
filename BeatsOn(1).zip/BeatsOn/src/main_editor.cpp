// BeatsOn! Editor: Scene 3D, Hierarquia, Inspetor, Music Editor, Assets, Console, Export Mod, Mods.
#include "engine/Application.h"
#include "game/GameRuntime.h"
#include "game/Project.h"
#include "editor/ModsUI.h"
#include <imgui_internal.h>
#include <ImGuizmo.h>
#include <thread>
#include <mutex>
using namespace bo;

class EditorApp : public Application {
    // ---------- projeto
    fs::path projectDir, modsDir; Scene scene; EntityId selected = 0; LevelData level; std::string levelFile = "Levels/Level01.level.json"; int curSong = 0;
    // ---------- viewports / camera do editor
    ViewportTarget sceneVp, gameVp; XMFLOAT3 camPos{ 0, 3.5f, -11 }; float yaw = 0, pitch = 12, camSpeed = 6; bool sceneHovered = false, sceneVisible = true, gameVisible = true; XMMATRIX lastView, lastProj; XMFLOAT2 sceneSize{ 1,1 };
    ImGuizmo::OPERATION gizmoOp = ImGuizmo::TRANSLATE; ImGuizmo::MODE gizmoMode = ImGuizmo::LOCAL; bool snap = false; float snapVal = 0.5f;
    // ---------- play
    std::unique_ptr<GameRuntime> play; bool playing = false; CameraRig previewRig;
    // ---------- music editor
    float scrollMs = -500, pxPerMs = 0.30f; int snapDiv = 16; bool musicPlaying = false; std::string loadedAudio; int eventPopupLane = -1; double eventPopupTime = 0; char evName[64] = "zoom", evArg[64] = "1.2";
    // ---------- mods / export
    ModsState mods; bool showMods = false, showExport = false; char mName[64] = "My Mod", mAuthor[64] = "", mVersion[16] = "1.0.0", mDesc[256] = ""; std::string mIcon;
    // ---------- build de scripts (thread)
    std::mutex logMx; std::vector<std::string> pendingLog; bool building = false; bool dirtyScene = false;

    bool OnInit() override {
        modsDir = exeDir / "Mods"; fs::create_directories(modsDir); projectDir = exeDir / "Projects" / "Default";
        if (!fs::exists(projectDir / "project.json")) CreateDefaultProject(projectDir, exeDir / "assets" / "Example" / "ExampleScripts.cs");
        OpenProject(projectDir); play = std::make_unique<GameRuntime>(renderer, *audio, &scripts, window.input); Log("BeatsOn! Editor pronto."); return true; }
    void OpenProject(const fs::path& dir) {
        projectDir = dir; renderer.SetAssetRoot(dir.string()); fs::create_directories(dir / "Assets"); selected = 0; curSong = 0;
        if (!LoadLevel(level, (dir / levelFile).string())) { level = LevelData{}; level.songs.push_back(SongData{}); }
        if (level.scene.empty() || !scene.Load((dir / level.scene).string())) scene.BuildDefault(); }
    void SaveAll() { scene.Save((projectDir / (level.scene.empty() ? "Scenes/Default.scene.json" : level.scene)).string()); SaveLevel(level, (projectDir / levelFile).string()); Log("Projeto salvo."); }
    std::string Import(const wchar_t* filter, const char* sub) {      // copia arquivo escolhido p/ Assets/<sub> e devolve caminho relativo ao projeto
        std::string f = OpenFileDialog(window.Handle(), filter); if (f.empty()) return {}; fs::path src = f, dst = projectDir / sub / src.filename(); std::error_code ec; fs::create_directories(dst.parent_path(), ec);
        if (fs::weakly_canonical(src) != fs::weakly_canonical(dst)) fs::copy_file(src, dst, fs::copy_options::overwrite_existing, ec); return fs::relative(dst, projectDir).generic_string(); }
    static constexpr const wchar_t* kImg = L"Imagens\0*.png;*.jpg;*.jpeg;*.tga;*.bmp\0Todos\0*.*\0", *kModel = L"Modelos 3D\0*.fbx;*.obj;*.gltf;*.glb;*.dae;*.3ds;*.blend;*.ply;*.stl\0Todos\0*.*\0",
                                 *kHdri = L"HDRI (Radiance)\0*.hdr\0Todos\0*.*\0", *kAudio = L"Audio\0*.mp3;*.wav;*.ogg;*.flac\0Todos\0*.*\0";

    // ================================================================ update
    void OnUpdate(float dt) override {
        { std::lock_guard<std::mutex> l(logMx); for (auto& s : pendingLog) Log("%s", s.c_str()); pendingLog.clear(); }
        auto& in = window.input; bool rmb = in.MouseDown(1) && (sceneHovered || window.captured); window.SetCursorCaptured(rmb);
        if (rmb) {   // olhar ao redor + voar: WASD, Q/E (baixo/cima), Shift = turbo, scroll = velocidade
            yaw += in.mouseDX * 0.12f; pitch = std::clamp(pitch + in.mouseDY * 0.12f, -89.f, 89.f); camSpeed = std::clamp(camSpeed * std::pow(1.2f, in.scroll), 0.3f, 400.f);
            float y = XMConvertToRadians(yaw), p = XMConvertToRadians(pitch); XMVECTOR fwd = XMVectorSet(sinf(y) * cosf(p), -sinf(p), cosf(y) * cosf(p), 0), right = XMVectorSet(cosf(y), 0, -sinf(y), 0), up = XMVectorSet(0, 1, 0, 0), mv = XMVectorZero();
            if (in.Down('W')) mv += fwd; if (in.Down('S')) mv -= fwd; if (in.Down('D')) mv += right; if (in.Down('A')) mv -= right; if (in.Down('E')) mv += up; if (in.Down('Q')) mv -= up;
            float k = camSpeed * (in.Down(VK_SHIFT) ? 3.f : 1.f) * dt; XMVECTOR np = XMLoadFloat3(&camPos) + mv * k; XMStoreFloat3(&camPos, np); }
        else if (sceneHovered && !ImGui::GetIO().WantTextInput) { if (in.Pressed('1')) gizmoOp = ImGuizmo::TRANSLATE; if (in.Pressed('2')) gizmoOp = ImGuizmo::ROTATE; if (in.Pressed('3')) gizmoOp = ImGuizmo::SCALE; if (in.Pressed(VK_DELETE) && selected) { scene.Remove(selected); selected = 0; } }
        if (in.Down(VK_CONTROL) && in.Pressed('S')) SaveAll();
        if (playing) { play->Update(dt); if (play->Finished()) StopPlay(); if (in.Pressed(VK_ESCAPE)) StopPlay(); }
        else if (musicPlaying) { auto& s = level.songs[std::clamp(curSong, 0, (int)level.songs.size() - 1)]; scrollMs = (!s.audio.empty() && audio->IsPlaying()) ? audio->PositionMs() : scrollMs + dt * 1000.0; if (audio->IsFinished()) musicPlaying = false; }
        scene.Update(dt); }
    void StartPlay(const fs::path& root, const std::string& lvl) { if (!playing && root == projectDir) SaveAll(); musicPlaying = false; audio->Pause(); if (play->LoadLevel(root.string(), lvl)) { playing = true; } renderer.SetAssetRoot(projectDir.string()); if (root != projectDir) renderer.SetAssetRoot(root.string()); }
    void StopPlay() { play->Stop(); playing = false; renderer.SetAssetRoot(projectDir.string()); ScriptApi_SetContext(nullptr); }
    void BuildScripts() {
        if (building) return; building = true; std::string cmd = "dotnet build \"" + (projectDir / "Scripts" / "GameScripts.csproj").string() + "\" -c Release -o \"" + (projectDir / "Scripts" / "bin").string() + "\" -p:BeatsOnDir=\"" + (exeDir / "scripting").string() + "\" 2>&1";
        Log("Compilando scripts C#..."); std::thread([this, cmd]() { FILE* p = _popen(cmd.c_str(), "r"); char b[512]; std::string last; if (p) { while (fgets(b, sizeof b, p)) { std::string l = b; while (!l.empty() && (l.back() == '\n' || l.back() == '\r')) l.pop_back(); if (l.find("error") != std::string::npos || l.find("Warn") != std::string::npos || l.find("Build succeeded") != std::string::npos) { std::lock_guard<std::mutex> g(logMx); pendingLog.push_back(l); } } _pclose(p); }
            { std::lock_guard<std::mutex> g(logMx); pendingLog.push_back("Build de scripts finalizado. (Reinicie o Play/Editor para recarregar a DLL.)"); } building = false; }).detach(); }

    // ================================================================ render
    void OnRender() override {
        if (sceneVisible && sceneVp.inited) { RenderView rv; rv.view = lastView; rv.proj = lastProj; rv.camPos = camPos; rv.drawGrid = true; rv.post.bloom = 0.12f; rv.post.vignette = 0.f; rv.time = (float)ImGui::GetTime(); renderer.RenderScene(scene, rv, sceneVp); }
        if (gameVisible && gameVp.inited) {
            if (playing) play->Render(gameVp);
            else if (auto* c = scene.GameplayCamera()) { previewRig.Bind(*c); RenderView rv; rv.view = previewRig.View(); rv.proj = previewRig.Proj((float)gameVp.w / gameVp.h); rv.camPos = previewRig.Position(); rv.post = previewRig.GetPost(); rv.time = (float)ImGui::GetTime(); renderer.RenderScene(scene, rv, gameVp); } } }

    // ================================================================ GUI
    void OnGui() override {
        static bool layoutDone = false; if (!layoutDone) { layoutDone = true; BuildLayout(); }
        MainMenu(); PanelScene3D(); PanelGame(); PanelHierarchy(); PanelInspector(); PanelAssets(); PanelConsole(); PanelMusic();
        if (showMods) { ImGui::SetNextWindowSize({ 640, 480 }, ImGuiCond_Appearing); if (ImGui::Begin(ICON_FA_PUZZLE_PIECE " Mods", &showMods)) DrawModsContent(renderer, mods, modsDir.string(), window.Handle(), [&](const ModInfo& m) { fs::path cache = modsDir / "_cache" / fs::path(m.path).stem(); std::error_code ec; fs::remove_all(cache, ec); if (ExtractMod(m, cache.string())) StartPlay(cache, m.startLevel); }); ImGui::End(); }
        ExportPopup(); }
    void BuildLayout() {
        ImGuiID root = ImGui::GetMainViewport()->ID; ImGui::DockBuilderRemoveNode(root); ImGui::DockBuilderAddNode(root, ImGuiDockNodeFlags_DockSpace); ImGui::DockBuilderSetNodeSize(root, ImGui::GetMainViewport()->Size);
        ImGuiID center = root, left, right, bottom; left = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 0.17f, nullptr, &center); right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 0.22f, nullptr, &center); bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, 0.28f, nullptr, &center);
        ImGui::DockBuilderDockWindow("Hierarquia", left); ImGui::DockBuilderDockWindow("Inspetor", right); ImGui::DockBuilderDockWindow("Scene 3D", center); ImGui::DockBuilderDockWindow("Game", center); ImGui::DockBuilderDockWindow("Music Editor", center);
        ImGui::DockBuilderDockWindow("Assets", bottom); ImGui::DockBuilderDockWindow("Console", bottom); ImGui::DockBuilderFinish(root); }
    void MainMenu() {
        if (!ImGui::BeginMainMenuBar()) return;
        if (ImGui::BeginMenu("File")) {
            if (ImGui::MenuItem(ICON_FA_FLOPPY_DISK "  Save All", "Ctrl+S")) SaveAll();
            if (ImGui::MenuItem(ICON_FA_FOLDER_OPEN "  Open Project Folder...")) { auto d = PickFolderDialog(window.Handle()); if (!d.empty()) { if (!fs::exists(fs::path(d) / "project.json")) CreateDefaultProject(d, exeDir / "assets" / "Example" / "ExampleScripts.cs"); OpenProject(d); } }
            ImGui::Separator(); if (ImGui::MenuItem(ICON_FA_FILE_EXPORT "  Export Mod...")) { showExport = true; ImGui::OpenPopup("Export Mod"); } if (ImGui::MenuItem(ICON_FA_PUZZLE_PIECE "  Mods")) { showMods = true; mods.dirty = true; }
            ImGui::Separator(); if (ImGui::MenuItem(ICON_FA_GEAR "  Build C# Scripts", nullptr, false, !building)) BuildScripts(); ImGui::Separator(); if (ImGui::MenuItem("Exit")) PostQuitMessage(0); ImGui::EndMenu(); }
        if (ImGui::BeginMenu("Create")) { CreateMenu(); ImGui::EndMenu(); }
        ImGui::SameLine(ImGui::GetWindowWidth() * 0.5f - 90);
        if (!playing) { if (ImGui::SmallButton(ICON_FA_PLAY " Play")) StartPlay(projectDir, levelFile); } else if (ImGui::SmallButton(ICON_FA_STOP " Stop")) StopPlay();
        ImGui::SameLine(ImGui::GetWindowWidth() - 150); if (ImGui::SmallButton(ICON_FA_FILE_EXPORT " Export")) { showExport = true; ImGui::OpenPopup("Export Mod"); } if (ImGui::SmallButton(ICON_FA_PUZZLE_PIECE " Mods")) { showMods = true; mods.dirty = true; }
        ImGui::EndMainMenuBar(); if (showExport && !ImGui::IsPopupOpen("Export Mod")) ImGui::OpenPopup("Export Mod"); }
    void CreateMenu() {
        auto mk = [&](const char* n) { auto* e = scene.Create(n); selected = e->id; return e; };
        if (ImGui::MenuItem(ICON_FA_CUBE " Empty")) mk("Empty");
        if (ImGui::MenuItem(ICON_FA_IMAGE " Sprite 2D")) { auto* e = mk("Sprite"); e->sprite = SpriteRenderer{}; e->sprite->texture = "builtin:white"; e->sprite->billboard = false; e->sprite->size = { 2, 2 }; }
        if (ImGui::MenuItem(ICON_FA_CUBE " Cube")) { auto* e = mk("Cube"); e->model = ModelRenderer{}; e->model->model = "builtin:cube"; e->transform.position = { 0, 0.5f, 0 }; }
        if (ImGui::MenuItem(ICON_FA_SQUARE " Plane")) { auto* e = mk("Plane"); e->model = ModelRenderer{}; e->model->model = "builtin:plane"; e->transform.scale = { 10, 1, 10 }; }
        if (ImGui::MenuItem(ICON_FA_VIDEO " Camera")) { auto* e = mk("Camera"); e->camera = CameraComponent{}; e->camera->gameplayCamera = false; e->transform.position = { 0, 2, -8 }; }
        if (ImGui::MenuItem(ICON_FA_SUN " Sky & Sun")) { auto* e = mk("Sky & Sun"); e->sky = SkyComponent{}; e->light = LightComponent{}; }
        if (ImGui::MenuItem(ICON_FA_FILE_IMPORT " Import 3D Model...")) { auto f = Import(kModel, "Assets/Models"); if (!f.empty()) { auto* e = mk(fs::path(f).stem().string().c_str()); e->model = ModelRenderer{}; e->model->model = f; } } }

    void PanelScene3D() {
        sceneVisible = ImGui::Begin("Scene 3D"); if (!sceneVisible) { ImGui::End(); sceneHovered = false; return; }
        if (ImGui::Button(ICON_FA_UP_DOWN_LEFT_RIGHT)) gizmoOp = ImGuizmo::TRANSLATE; ImGui::SameLine(); if (ImGui::Button(ICON_FA_ROTATE)) gizmoOp = ImGuizmo::ROTATE; ImGui::SameLine(); if (ImGui::Button(ICON_FA_MAXIMIZE)) gizmoOp = ImGuizmo::SCALE; ImGui::SameLine();
        if (ImGui::Button(gizmoMode == ImGuizmo::LOCAL ? "Local" : "World")) gizmoMode = gizmoMode == ImGuizmo::LOCAL ? ImGuizmo::WORLD : ImGuizmo::LOCAL; ImGui::SameLine(); ImGui::Checkbox("Snap", &snap); ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::DragFloat("##sv", &snapVal, 0.05f, 0.05f, 10);
        ImGui::SameLine(); ImGui::TextDisabled("  Vel: %.1f  |  RMB: olhar+WASD QE  Shift: turbo  Scroll: velocidade  |  1/2/3: gizmo", camSpeed);
        ImVec2 avail = ImGui::GetContentRegionAvail(); avail.x = std::max(avail.x, 16.f); avail.y = std::max(avail.y, 16.f); renderer.CreateViewport(sceneVp, (uint32_t)avail.x, (uint32_t)avail.y); sceneSize = { avail.x, avail.y };
        float y = XMConvertToRadians(yaw), p = XMConvertToRadians(pitch); XMVECTOR fwd = XMVectorSet(sinf(y) * cosf(p), -sinf(p), cosf(y) * cosf(p), 0); XMVECTOR pos = XMLoadFloat3(&camPos);
        lastView = XMMatrixLookToLH(pos, fwd, XMVectorSet(0, 1, 0, 0)); lastProj = XMMatrixPerspectiveFovLH(XMConvertToRadians(60), avail.x / avail.y, 0.05f, 4000.f);
        ImVec2 org = ImGui::GetCursorScreenPos(); ImGui::Image((ImTextureID)sceneVp.ldrGpu.ptr, avail); sceneHovered = ImGui::IsItemHovered(); auto* dl = ImGui::GetWindowDrawList();
        XMMATRIX vp = lastView * lastProj; auto toScreen = [&](XMFLOAT3 w, ImVec2& o) { XMVECTOR c = XMVector4Transform(XMVectorSet(w.x, w.y, w.z, 1), vp); float cw = XMVectorGetW(c); if (cw <= 0.01f) return false; o = { org.x + (XMVectorGetX(c) / cw * 0.5f + 0.5f) * avail.x, org.y + (1 - (XMVectorGetY(c) / cw * 0.5f + 0.5f)) * avail.y }; return true; };
        for (auto& e : scene.entities) if (e->camera || e->light) { ImVec2 s; if (toScreen(e->transform.position, s)) { dl->AddCircleFilled(s, 15, IM_COL32(20, 20, 30, 190)); dl->AddText({ s.x - 8, s.y - 9 }, e->camera ? IM_COL32(120, 220, 255, 255) : IM_COL32(255, 220, 90, 255), e->camera ? ICON_FA_VIDEO : ICON_FA_SUN); } }
        if (sceneHovered && ImGui::IsMouseClicked(0) && !ImGuizmo::IsOver()) { ImVec2 m = ImGui::GetMousePos(); float best = 28; EntityId pick = 0; for (auto& e : scene.entities) { ImVec2 s; XMFLOAT3 c = e->transform.position; if (e->sprite) c.y += e->sprite->size.y * 0.5f; if (toScreen(c, s)) { float d = hypotf(s.x - m.x, s.y - m.y); if (d < best) { best = d; pick = e->id; } } } if (pick) selected = pick; }
        if (auto* e = scene.Find(selected)) { ImGuizmo::SetDrawlist(); ImGuizmo::SetRect(org.x, org.y, avail.x, avail.y); XMFLOAT4X4 v, pr; XMStoreFloat4x4(&v, lastView); XMStoreFloat4x4(&pr, lastProj);
            float m[16], t[3] = { e->transform.position.x, e->transform.position.y, e->transform.position.z }, r[3] = { e->transform.rotation.x, e->transform.rotation.y, e->transform.rotation.z }, s[3] = { e->transform.scale.x, e->transform.scale.y, e->transform.scale.z };
            ImGuizmo::RecomposeMatrixFromComponents(t, r, s, m); float sn[3] = { snapVal, snapVal, snapVal };
            if (ImGuizmo::Manipulate(&v._11, &pr._11, gizmoOp, gizmoMode, m, nullptr, snap ? sn : nullptr)) { ImGuizmo::DecomposeMatrixToComponents(m, t, r, s); e->transform.position = { t[0], t[1], t[2] }; e->transform.rotation = { r[0], r[1], r[2] }; e->transform.scale = { s[0], s[1], s[2] }; } }
        ImGui::End(); }
    void PanelGame() {
        gameVisible = ImGui::Begin("Game"); if (!gameVisible) { ImGui::End(); return; }
        if (!playing) { if (ImGui::Button(ICON_FA_PLAY " Play")) StartPlay(projectDir, levelFile); ImGui::SameLine(); ImGui::TextDisabled("Previa da camera do jogador (a camera marcada como 'Gameplay Camera')"); }
        else { if (ImGui::Button(ICON_FA_STOP " Stop")) StopPlay(); ImGui::SameLine(); ImGui::Checkbox("Botplay", &play->botplay); ImGui::SameLine(); ImGui::Text("Level: %s", play->level.name.c_str()); }
        ImVec2 avail = ImGui::GetContentRegionAvail(); if (avail.x < 16 || avail.y < 16) { ImGui::End(); return; } renderer.CreateViewport(gameVp, (uint32_t)avail.x, (uint32_t)avail.y); ImVec2 org = ImGui::GetCursorScreenPos(); ImGui::Image((ImTextureID)gameVp.ldrGpu.ptr, avail);
        if (playing) { ImGui::GetWindowDrawList()->PushClipRect(org, { org.x + avail.x, org.y + avail.y }, true); play->DrawHud(ImGui::GetWindowDrawList(), org, avail); ImGui::GetWindowDrawList()->PopClipRect(); }
        ImGui::End(); }

    void PanelHierarchy() {
        ImGui::Begin("Hierarquia"); if (ImGui::Button(ICON_FA_PLUS " Criar")) ImGui::OpenPopup("create"); if (ImGui::BeginPopup("create")) { CreateMenu(); ImGui::EndPopup(); } ImGui::Separator();
        EntityId del = 0, dup = 0;
        for (auto& e : scene.entities) { const char* ic = e->camera ? ICON_FA_VIDEO : e->sky ? ICON_FA_SUN : e->sprite ? ICON_FA_IMAGE : e->model ? ICON_FA_CUBE : ICON_FA_CIRCLE_DOT; char l[160]; snprintf(l, sizeof l, "%s  %s##%u", ic, e->name.c_str(), e->id);
            if (ImGui::Selectable(l, selected == e->id)) selected = e->id; if (ImGui::BeginPopupContextItem()) { if (ImGui::MenuItem("Duplicar")) dup = e->id; if (ImGui::MenuItem("Excluir", "Del")) del = e->id; ImGui::EndPopup(); } }
        if (dup) if (auto* s = scene.Find(dup)) { auto* n = scene.Create(s->name + " (copy)"); EntityId id = n->id; *n = *s; n->id = id; n->name = s->name + " (copy)"; selected = id; }
        if (del) { scene.Remove(del); if (selected == del) selected = 0; } ImGui::End(); }

    bool Browse(const char* label, std::string& path, const wchar_t* filter, const char* sub) { bool ch = false; ImGui::PushID(label); char b[260]; snprintf(b, sizeof b, "%s", path.c_str()); ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - 40); if (ImGui::InputText(label, b, sizeof b)) { path = b; ch = true; }
        ImGui::SameLine(); if (ImGui::Button(ICON_FA_FOLDER_OPEN)) { auto f = Import(filter, sub); if (!f.empty()) { path = f; ch = true; } } ImGui::PopID(); return ch; }
    void PanelInspector() {
        ImGui::Begin("Inspetor"); Entity* e = scene.Find(selected); if (!e) { ImGui::TextDisabled("Selecione uma entidade."); ImGui::End(); return; }
        char nm[96]; snprintf(nm, sizeof nm, "%s", e->name.c_str()); if (ImGui::InputText("Nome", nm, sizeof nm)) e->name = nm; ImGui::Checkbox("Ativo", &e->active);
        if (ImGui::CollapsingHeader(ICON_FA_ARROWS_UP_DOWN_LEFT_RIGHT "  Transform", ImGuiTreeNodeFlags_DefaultOpen)) { ImGui::DragFloat3("Posicao", &e->transform.position.x, 0.05f); ImGui::DragFloat3("Rotacao", &e->transform.rotation.x, 0.5f); ImGui::DragFloat3("Escala", &e->transform.scale.x, 0.02f); }
        if (auto& s = e->sprite; s && ImGui::CollapsingHeader(ICON_FA_IMAGE "  Sprite Renderer", ImGuiTreeNodeFlags_DefaultOpen)) { Browse("Textura", s->texture, kImg, "Assets/Sprites"); ImGui::ColorEdit4("Tint", &s->tint.x); ImGui::DragFloat2("Tamanho", &s->size.x, 0.05f); ImGui::DragFloat2("Pivot", &s->pivot.x, 0.01f, 0, 1);
            ImGui::Checkbox("Billboard", &s->billboard); ImGui::SameLine(); ImGui::Checkbox("Flip X", &s->flipX); ImGui::SameLine(); ImGui::Checkbox("Iluminado", &s->lit); ImGui::DragInt("Sort", &s->sortOrder); if (ImGui::SmallButton("Remover##spr")) { e->sprite.reset(); e->animator.reset(); } }
        if (e->sprite && !e->animator && ImGui::Button(ICON_FA_FILM " Adicionar Sprite Animator")) e->animator = SpriteAnimator{};
        if (auto& a = e->animator; a && ImGui::CollapsingHeader(ICON_FA_FILM "  Sprite Animator", ImGuiTreeNodeFlags_DefaultOpen)) {
            static char an[32] = "idle"; static int cols = 4, rows = 1, start = 0, cnt = 4; static float fps = 24; static bool loop = true; ImGui::InputText("Nome##an", an, sizeof an); ImGui::DragInt("Colunas", &cols, 0.1f, 1, 64); ImGui::DragInt("Linhas", &rows, 0.1f, 1, 64); ImGui::DragInt("Frame inicial", &start, 0.1f, 0, 4096); ImGui::DragInt("Frames", &cnt, 0.1f, 1, 4096); ImGui::DragFloat("FPS", &fps, 0.5f, 1, 120); ImGui::Checkbox("Loop", &loop);
            if (ImGui::Button("Adicionar animacao (grade)")) a->AddGridAnimation(an, start, cnt, cols, rows, fps, loop);
            for (auto& [k, v] : a->anims) { ImGui::PushID(k.c_str()); ImGui::BulletText("%s  (%d frames, %.0f fps)", k.c_str(), (int)v.frames.size(), v.fps); ImGui::SameLine(); if (ImGui::SmallButton("Play")) a->Play(k); ImGui::PopID(); } }
        if (auto& c = e->camera; c && ImGui::CollapsingHeader(ICON_FA_VIDEO "  Camera (olhos do jogador)", ImGuiTreeNodeFlags_DefaultOpen)) { ImGui::Checkbox("Gameplay Camera", &c->gameplayCamera); ImGui::Checkbox("Ortografica", &c->ortho); if (c->ortho) ImGui::DragFloat("Tamanho ortho", &c->orthoSize, 0.05f, 0.1f, 100); else ImGui::SliderFloat("FOV", &c->fovDeg, 10, 120); ImGui::DragFloat("Near", &c->nearZ, 0.01f, 0.001f, 10); ImGui::DragFloat("Far", &c->farZ, 1, 10, 10000); }
        if (auto& m = e->model; m && ImGui::CollapsingHeader(ICON_FA_CUBE "  Model Renderer (PBR)", ImGuiTreeNodeFlags_DefaultOpen)) { Browse("Modelo", m->model, kModel, "Assets/Models"); Browse("Albedo", m->albedo, kImg, "Assets/Textures"); Browse("Normal Map", m->normal, kImg, "Assets/Textures"); Browse("ORM (AO/Rough/Metal)", m->orm, kImg, "Assets/Textures"); Browse("Emissive", m->emissive, kImg, "Assets/Textures");
            ImGui::ColorEdit4("Cor base", &m->baseColor.x); ImGui::SliderFloat("Metallic", &m->metallic, 0, 1); ImGui::SliderFloat("Roughness", &m->roughness, 0.04f, 1); ImGui::DragFloat("Emissive", &m->emissiveStrength, 0.05f, 0, 50); ImGui::Checkbox("Projeta sombra", &m->castShadow); if (ImGui::SmallButton("Remover##mdl")) e->model.reset(); }
        if (auto& l = e->light; l && ImGui::CollapsingHeader(ICON_FA_SUN "  Luz direcional (Sol)", ImGuiTreeNodeFlags_DefaultOpen)) { ImGui::ColorEdit3("Cor", &l->color.x); ImGui::DragFloat("Intensidade", &l->intensity, 0.1f, 0, 100); }
        if (auto& s = e->sky; s && ImGui::CollapsingHeader(ICON_FA_CLOUD_SUN "  Ceu / Nuvens / HDRI", ImGuiTreeNodeFlags_DefaultOpen)) { ImGui::Checkbox("Ceu procedural", &s->procedural); if (!s->procedural) { if (Browse("HDRI (.hdr)", s->hdri, kHdri, "Assets/HDRI")) renderer.ClearHDRI(); ImGui::DragFloat("Intensidade HDRI", &s->hdriIntensity, 0.05f, 0, 20); }
            ImGui::SliderFloat("Sol - elevacao", &s->sunElevation, -10, 90); ImGui::SliderFloat("Sol - azimute", &s->sunAzimuth, 0, 360); ImGui::SliderFloat("Cobertura de nuvens", &s->cloudCover, 0, 1); ImGui::SliderFloat("Densidade", &s->cloudDensity, 0, 2); }
        if (auto& sc = e->script; sc && ImGui::CollapsingHeader(ICON_FA_CODE "  Scripts C#")) { for (auto& c : sc->classes) { char b[96]; snprintf(b, sizeof b, "%s", c.c_str()); if (ImGui::InputText(("##c" + c).c_str(), b, sizeof b)) c = b; } if (ImGui::SmallButton("+ classe")) sc->classes.push_back("Namespace.Classe"); }
        ImGui::Separator(); if (ImGui::Button(ICON_FA_PLUS " Adicionar componente")) ImGui::OpenPopup("addc");
        if (ImGui::BeginPopup("addc")) { if (!e->sprite && ImGui::MenuItem("Sprite Renderer")) { e->sprite = SpriteRenderer{}; e->sprite->texture = "builtin:white"; } if (!e->camera && ImGui::MenuItem("Camera")) e->camera = CameraComponent{}; if (!e->model && ImGui::MenuItem("Model Renderer")) { e->model = ModelRenderer{}; e->model->model = "builtin:cube"; }
            if (!e->light && ImGui::MenuItem("Luz")) e->light = LightComponent{}; if (!e->sky && ImGui::MenuItem("Ceu")) e->sky = SkyComponent{}; if (!e->script && ImGui::MenuItem("Script C#")) e->script = ScriptComponent{}; ImGui::EndPopup(); }
        ImGui::End(); }

    void PanelAssets() {
        ImGui::Begin("Assets"); if (ImGui::Button(ICON_FA_CUBE " Modelo 3D")) { auto f = Import(kModel, "Assets/Models"); (void)f; } ImGui::SameLine(); if (ImGui::Button(ICON_FA_IMAGE " Textura / PBR")) Import(kImg, "Assets/Textures"); ImGui::SameLine(); if (ImGui::Button(ICON_FA_SUN " HDRI")) Import(kHdri, "Assets/HDRI"); ImGui::SameLine(); if (ImGui::Button(ICON_FA_MUSIC " Audio")) Import(kAudio, "Songs");
        ImGui::SameLine(); ImGui::TextDisabled("(duplo clique: modelo -> cena | imagem -> sprite | .hdr -> ceu)"); ImGui::Separator(); ImGui::BeginChild("files");
        for (const char* d : { "Assets", "Songs" }) { fs::path root = projectDir / d; if (!fs::exists(root)) continue; for (auto& f : fs::recursive_directory_iterator(root)) { if (!f.is_regular_file()) continue; std::string rel = fs::relative(f.path(), projectDir).generic_string(), ext = f.path().extension().string(); std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
            bool isImg = ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tga" || ext == ".bmp", isMdl = ext == ".fbx" || ext == ".obj" || ext == ".gltf" || ext == ".glb" || ext == ".dae" || ext == ".3ds", isHdr = ext == ".hdr", isAud = ext == ".mp3" || ext == ".wav" || ext == ".ogg" || ext == ".flac";
            const char* ic = isImg ? ICON_FA_IMAGE : isMdl ? ICON_FA_CUBE : isHdr ? ICON_FA_SUN : isAud ? ICON_FA_MUSIC : ICON_FA_FILE; char l[300]; snprintf(l, sizeof l, "%s  %s", ic, rel.c_str()); ImGui::Selectable(l);
            if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0)) { if (isMdl) { auto* e = scene.Create(f.path().stem().string()); e->model = ModelRenderer{}; e->model->model = rel; selected = e->id; } else if (isImg) { auto* e = scene.Create(f.path().stem().string()); e->sprite = SpriteRenderer{}; e->sprite->texture = rel; e->sprite->billboard = false; selected = e->id; }
                else if (isHdr) { for (auto& en : scene.entities) if (en->sky) { en->sky->procedural = false; en->sky->hdri = rel; renderer.ClearHDRI(); } } else if (isAud && !level.songs.empty()) { level.songs[curSong].audio = rel; loadedAudio.clear(); } } } }
        ImGui::EndChild(); ImGui::End(); }
    void PanelConsole() { ImGui::Begin("Console"); if (ImGui::SmallButton("Limpar")) LogBuffer().clear(); ImGui::Separator(); ImGui::BeginChild("log"); for (auto& l : LogBuffer()) ImGui::TextUnformatted(l.c_str()); if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 5) ImGui::SetScrollHereY(1.f); ImGui::EndChild(); ImGui::End(); }

    // ================================================================ MUSIC EDITOR
    SongData& Song() { if (level.songs.empty()) level.songs.push_back(SongData{}); curSong = std::clamp(curSong, 0, (int)level.songs.size() - 1); return level.songs[curSong]; }
    void EnsureAudio() { SongData& s = Song(); std::string key = std::to_string(curSong) + "|" + s.audio; if (key == loadedAudio) return; loadedAudio = key; audio->Stop(); if (!s.audio.empty()) { if (!audio->Load((projectDir / s.audio).string())) Log("Nao foi possivel abrir audio: %s", s.audio.c_str()); } }
    std::vector<std::string> ListFiles(const char* dir, const char* ext) { std::vector<std::string> r; fs::path d = projectDir / dir; if (fs::exists(d)) for (auto& f : fs::directory_iterator(d)) if (f.path().string().size() >= strlen(ext) && f.path().string().rfind(ext) == f.path().string().size() - strlen(ext)) r.push_back(fs::relative(f.path(), projectDir).generic_string()); return r; }
    void PanelMusic() {
        if (!ImGui::Begin("Music Editor")) { ImGui::End(); return; } EnsureAudio(); SongData& s = Song(); ImVec2 full = ImGui::GetContentRegionAvail(); const float rightW = 320;
        ImGui::BeginChild("chart", { full.x - rightW - 8, 0 });
        if (ImGui::Button(ICON_FA_FILE_AUDIO " Importar musica")) { auto f = Import(kAudio, "Songs"); if (!f.empty()) { s.audio = f; if (s.name == "New Song") s.name = fs::path(f).stem().string(); loadedAudio.clear(); } } ImGui::SameLine();
        if (!musicPlaying) { if (ImGui::Button(ICON_FA_PLAY " Tocar")) { musicPlaying = true; if (!s.audio.empty()) { audio->Seek(std::max(0.0, (double)scrollMs)); audio->Play(); } } } else if (ImGui::Button(ICON_FA_PAUSE " Pausar")) { musicPlaying = false; audio->Pause(); }
        ImGui::SameLine(); if (ImGui::Button(ICON_FA_STOP)) { musicPlaying = false; audio->Stop(); scrollMs = -500; } ImGui::SameLine(); ImGui::Text("%.2fs", scrollMs / 1000.0); ImGui::SameLine(); ImGui::TextDisabled("%s", s.audio.empty() ? "(sem audio: modo metronomo)" : s.audio.c_str());
        ImGui::SetNextItemWidth(90); ImGui::DragScalar("BPM", ImGuiDataType_Double, &s.bpm, 0.1f); ImGui::SameLine(); ImGui::SetNextItemWidth(90); ImGui::DragScalar("Offset ms", ImGuiDataType_Double, &s.offsetMs, 1.f); ImGui::SameLine(); ImGui::SetNextItemWidth(80); ImGui::DragFloat("Velocidade", &s.scrollSpeed, 0.02f, 0.5f, 6);
        ImGui::SameLine(); ImGui::SetNextItemWidth(70); static const int snaps[] = { 4, 8, 12, 16, 24, 32 }; int si = 3; for (int i = 0; i < 6; ++i) if (snaps[i] == snapDiv) si = i; char sl[8]; snprintf(sl, 8, "1/%d", snapDiv); if (ImGui::BeginCombo("Snap", sl)) { for (int v : snaps) { snprintf(sl, 8, "1/%d", v); if (ImGui::Selectable(sl, v == snapDiv)) snapDiv = v; } ImGui::EndCombo(); } (void)si;
        ImGui::SameLine(); ImGui::SetNextItemWidth(90); ImGui::SliderFloat("Zoom", &pxPerMs, 0.08f, 1.2f); ImGui::SameLine(); if (ImGui::Button(ICON_FA_GAMEPAD " Testar level")) StartPlay(projectDir, levelFile);
        // ---- timeline
        ImVec2 org = ImGui::GetCursorScreenPos(), size = ImGui::GetContentRegionAvail(); const int kCols = 9; float colW = std::min(46.f, (size.x - 60) / kCols), gridW = colW * kCols, x0 = org.x + (size.x - gridW) * 0.5f, playY = org.y + 70;
        ImGui::InvisibleButton("##timeline", size, ImGuiButtonFlags_MouseButtonLeft | ImGuiButtonFlags_MouseButtonRight); bool hov = ImGui::IsItemHovered(); auto* dl = ImGui::GetWindowDrawList(); dl->PushClipRect(org, { org.x + size.x, org.y + size.y }, true);
        dl->AddRectFilled(org, { org.x + size.x, org.y + size.y }, IM_COL32(14, 14, 20, 255));
        auto T2Y = [&](double t) { return playY + (float)(t - scrollMs) * pxPerMs; }; auto Y2T = [&](float y) { return scrollMs + (y - playY) / pxPerMs; };
        static const ImU32 col[4] = { IM_COL32(194, 75, 153, 255), IM_COL32(0, 229, 255, 255), IM_COL32(18, 250, 5, 255), IM_COL32(249, 57, 63, 255) };
        for (int c = 0; c < kCols; ++c) { ImU32 bg = c < 4 ? IM_COL32(40, 24, 40, 120) : c < 8 ? IM_COL32(20, 34, 44, 120) : IM_COL32(40, 36, 20, 120); dl->AddRectFilled({ x0 + c * colW, org.y }, { x0 + (c + 1) * colW, org.y + size.y }, (c % 2) ? bg : (bg & 0x00FFFFFF) | (70u << 24)); dl->AddLine({ x0 + c * colW, org.y }, { x0 + c * colW, org.y + size.y }, IM_COL32(60, 60, 80, 255)); }
        dl->AddLine({ x0 + gridW, org.y }, { x0 + gridW, org.y + size.y }, IM_COL32(60, 60, 80, 255)); dl->AddText({ x0 + 4, org.y + 4 }, IM_COL32(255, 140, 220, 255), "OPONENTE"); dl->AddText({ x0 + 4 * colW + 4, org.y + 4 }, IM_COL32(120, 220, 255, 255), "JOGADOR"); dl->AddText({ x0 + 8 * colW + 4, org.y + 4 }, IM_COL32(255, 220, 120, 255), "EVENTOS");
        double beat = 60000.0 / s.bpm, snapMs = beat * 4.0 / snapDiv, tTop = Y2T(org.y), tBot = Y2T(org.y + size.y);
        for (double t = std::floor((tTop - s.offsetMs) / snapMs) * snapMs + s.offsetMs; t <= tBot; t += snapMs) { double n = (t - s.offsetMs) / beat; bool isBeat = std::abs(n - std::round(n)) < 1e-4, isBar = isBeat && ((long)std::llround(n) % 4 == 0); float y = T2Y(t);
            dl->AddLine({ x0, y }, { x0 + gridW, y }, isBar ? IM_COL32(150, 150, 190, 220) : isBeat ? IM_COL32(90, 90, 120, 200) : IM_COL32(45, 45, 62, 160), isBar ? 2.f : 1.f); if (isBar) { char b[16]; snprintf(b, 16, "%ld", (long)std::llround(n) / 4 + 1); dl->AddText({ x0 - 28, y - 8 }, IM_COL32(170, 170, 200, 255), b); } }
        for (auto& n : s.notes) { int c = n.side == 1 ? n.lane : 4 + n.lane; float y = T2Y(n.time); if (y < org.y - 40 || y > org.y + size.y + 40) continue; float cx = x0 + c * colW + colW * 0.5f; if (n.sustain > 0) dl->AddRectFilled({ cx - 5, y }, { cx + 5, y + (float)n.sustain * pxPerMs }, (col[n.lane & 3] & 0x00FFFFFF) | (150u << 24), 4);
            dl->AddRectFilled({ cx - colW * 0.42f, y - 11 }, { cx + colW * 0.42f, y + 11 }, col[n.lane & 3], 6); dl->AddRect({ cx - colW * 0.42f, y - 11 }, { cx + colW * 0.42f, y + 11 }, IM_COL32(255, 255, 255, 140), 6); }
        for (auto& ev : s.events) { float y = T2Y(ev.time); float cx = x0 + 8 * colW; dl->AddRectFilled({ cx + 2, y - 10 }, { cx + colW - 2, y + 10 }, IM_COL32(255, 200, 60, 255), 5); dl->AddText({ cx + 4, y - 8 }, IM_COL32(20, 20, 20, 255), ev.name.c_str()); }
        dl->AddLine({ x0 - 10, playY }, { x0 + gridW + 10, playY }, IM_COL32(255, 80, 120, 255), 2.f); dl->AddTriangleFilled({ x0 - 22, playY - 7 }, { x0 - 22, playY + 7 }, { x0 - 8, playY }, IM_COL32(255, 80, 120, 255));
        if (hov) { ImVec2 m = ImGui::GetMousePos(); int c = (int)std::floor((m.x - x0) / colW); double t = std::round((Y2T(m.y) - s.offsetMs) / snapMs) * snapMs + s.offsetMs;
            if (c >= 0 && c < kCols) { float cx = x0 + c * colW; dl->AddRectFilled({ cx + 2, T2Y(t) - 11 }, { cx + colW - 2, T2Y(t) + 11 }, IM_COL32(255, 255, 255, 50), 6); ImGui::SetTooltip("%s  t=%.0f ms", c < 4 ? "Oponente" : c < 8 ? "Jogador" : "Evento", t);
                auto findNote = [&]() { for (size_t i = 0; i < s.notes.size(); ++i) { auto& n = s.notes[i]; if ((n.side == 1 ? n.lane : 4 + n.lane) == c && std::abs(n.time - t) < snapMs * 0.5) return (int)i; } return -1; };
                if (c < 8) { int idx = findNote(); if (ImGui::IsMouseClicked(0)) { if (idx >= 0 && ImGui::GetIO().KeyCtrl) s.notes[idx].sustain += snapMs; else if (idx >= 0) s.notes.erase(s.notes.begin() + idx); else if (t >= 0 || true) { NoteData nd; nd.time = t; nd.lane = c % 4; nd.side = c < 4 ? 1 : 0; s.notes.push_back(nd); } } if (ImGui::IsMouseClicked(1) && idx >= 0) s.notes.erase(s.notes.begin() + idx); }
                else { if (ImGui::IsMouseClicked(0)) { eventPopupTime = t; eventPopupLane = c; ImGui::OpenPopup("newevent"); } if (ImGui::IsMouseClicked(1)) for (size_t i = 0; i < s.events.size(); ++i) if (std::abs(s.events[i].time - t) < snapMs * 0.5) { s.events.erase(s.events.begin() + i); break; } } }
            if (ImGui::GetIO().MouseWheel != 0) { if (ImGui::GetIO().KeyCtrl) pxPerMs = std::clamp(pxPerMs * (1 + 0.1f * ImGui::GetIO().MouseWheel), 0.08f, 1.2f); else { scrollMs -= ImGui::GetIO().MouseWheel * (float)snapMs * 2; if (musicPlaying && !s.audio.empty()) audio->Seek(std::max(0.0, (double)scrollMs)); } } }
        dl->PopClipRect();
        if (ImGui::BeginPopup("newevent")) { ImGui::Text("Evento em %.0f ms", eventPopupTime); ImGui::InputText("Nome", evName, sizeof evName); ImGui::InputText("Argumento", evArg, sizeof evArg); ImGui::TextDisabled("-> OnEvent(nome, arg) no C#. 'next_level' + caminho troca de level."); if (ImGui::Button("Adicionar")) { s.events.push_back({ eventPopupTime, evName, evArg }); ImGui::CloseCurrentPopup(); } ImGui::EndPopup(); }
        ImGui::EndChild(); ImGui::SameLine();
        // ---- coluna direita: level, musicas, scripts
        ImGui::BeginChild("right", { rightW, 0 }, ImGuiChildFlags_Borders);
        ImGui::SeparatorText(ICON_FA_LAYER_GROUP "  Levels do projeto"); auto levels = ListFiles("Levels", ".level.json"); for (auto& l : levels) { bool cur = (l == levelFile); if (ImGui::Selectable((std::string(ICON_FA_FILE_LINES "  ") + l).c_str(), cur) && !cur) { SaveAll(); levelFile = l; curSong = 0; loadedAudio.clear(); OpenProject(projectDir); } }
        if (ImGui::Button(ICON_FA_PLUS " Novo level")) { SaveAll(); int n = (int)levels.size() + 1; char nm[64]; snprintf(nm, 64, "Levels/Level%02d.level.json", n); LevelData nl; nl.name = "Level " + std::to_string(n); nl.scene = level.scene; nl.scripts = level.scripts; nl.songs.push_back(SongData{}); SaveLevel(nl, (projectDir / nm).string()); if (level.nextLevel.empty()) level.nextLevel = nm; SaveAll(); levelFile = nm; curSong = 0; loadedAudio.clear(); OpenProject(projectDir); }
        ImGui::SeparatorText("Configuracao do Level"); char nm[96]; snprintf(nm, sizeof nm, "%s", level.name.c_str()); if (ImGui::InputText("Nome##lvl", nm, sizeof nm)) level.name = nm;
        if (ImGui::BeginCombo("Cena", level.scene.c_str())) { for (auto& f : ListFiles("Scenes", ".scene.json")) if (ImGui::Selectable(f.c_str(), f == level.scene)) { SaveAll(); level.scene = f; scene.Load((projectDir / f).string()); } ImGui::EndCombo(); }
        if (ImGui::BeginCombo("Proximo level", level.nextLevel.empty() ? "(voltar ao menu)" : level.nextLevel.c_str())) { if (ImGui::Selectable("(voltar ao menu)")) level.nextLevel.clear(); for (auto& l : levels) if (ImGui::Selectable(l.c_str(), l == level.nextLevel)) level.nextLevel = l; ImGui::EndCombo(); }
        ImGui::TextDisabled("Quando as musicas acabam, carrega o proximo level. Via script: Game.LoadLevel(\"...\")."); ImGui::Text("Scripts C# do level:"); for (size_t i = 0; i < level.scripts.size(); ++i) { char b[96]; snprintf(b, sizeof b, "%s", level.scripts[i].c_str()); ImGui::PushID((int)i); ImGui::SetNextItemWidth(rightW - 70); if (ImGui::InputText("##s", b, sizeof b)) level.scripts[i] = b; ImGui::SameLine(); if (ImGui::SmallButton(ICON_FA_XMARK)) { level.scripts.erase(level.scripts.begin() + i); ImGui::PopID(); break; } ImGui::PopID(); } if (ImGui::SmallButton("+ script")) level.scripts.push_back("Example.CameraBop");
        ImGui::SeparatorText(ICON_FA_MUSIC "  Musicas deste level"); int del = -1, mv = 0, mvIdx = -1;
        for (int i = 0; i < (int)level.songs.size(); ++i) { ImGui::PushID(i); char l[160]; snprintf(l, sizeof l, "%d. %s  (%zu notas)", i + 1, level.songs[i].name.c_str(), level.songs[i].notes.size()); if (ImGui::Selectable(l, i == curSong)) { curSong = i; musicPlaying = false; audio->Pause(); scrollMs = -500; } if (ImGui::BeginPopupContextItem()) { if (ImGui::MenuItem("Subir") && i > 0) { mv = -1; mvIdx = i; } if (ImGui::MenuItem("Descer") && i + 1 < (int)level.songs.size()) { mv = 1; mvIdx = i; } if (ImGui::MenuItem("Remover")) del = i; ImGui::EndPopup(); } ImGui::PopID(); }
        if (mv) { std::swap(level.songs[mvIdx], level.songs[mvIdx + mv]); curSong = mvIdx + mv; } if (del >= 0 && level.songs.size() > 1) { level.songs.erase(level.songs.begin() + del); curSong = 0; loadedAudio.clear(); }
        if (ImGui::Button(ICON_FA_PLUS " Adicionar musica")) { SongData n; auto f = Import(kAudio, "Songs"); if (!f.empty()) { n.audio = f; n.name = fs::path(f).stem().string(); } level.songs.push_back(n); curSong = (int)level.songs.size() - 1; loadedAudio.clear(); }
        ImGui::SeparatorText("Musica selecionada"); char sn[96]; snprintf(sn, sizeof sn, "%s", s.name.c_str()); if (ImGui::InputText("Titulo", sn, sizeof sn)) s.name = sn; char sa[96]; snprintf(sa, sizeof sa, "%s", s.artist.c_str()); if (ImGui::InputText("Artista", sa, sizeof sa)) s.artist = sa;
        ImGui::Text("Notas: %zu   Eventos: %zu", s.notes.size(), s.events.size()); if (ImGui::Button("Limpar notas")) s.notes.clear(); ImGui::SameLine(); if (ImGui::Button(ICON_FA_FLOPPY_DISK " Salvar")) SaveAll();
        ImGui::TextDisabled("Click: add/remove nota | Ctrl+Click: sustain | Botao direito: remover | Scroll: mover | Ctrl+Scroll: zoom"); ImGui::EndChild(); ImGui::End(); }

    // ================================================================ EXPORT MOD
    void ExportPopup() {
        ImGui::SetNextWindowSize({ 460, 0 }); ImVec2 c = ImGui::GetMainViewport()->GetCenter(); ImGui::SetNextWindowPos(c, ImGuiCond_Appearing, { 0.5f, 0.5f });
        if (!ImGui::BeginPopupModal("Export Mod", &showExport, ImGuiWindowFlags_NoSavedSettings)) { if (!showExport) {} return; }
        ImGui::InputText("Nome do mod", mName, sizeof mName); ImGui::InputText("Criador", mAuthor, sizeof mAuthor); ImGui::InputText("Versao", mVersion, sizeof mVersion); ImGui::InputTextMultiline("Descricao", mDesc, sizeof mDesc, { 0, 80 });
        ImGui::Text("Icone:"); ImGui::SameLine(); ImGui::TextDisabled("%s", mIcon.empty() ? "(nenhum)" : fs::path(mIcon).filename().string().c_str()); ImGui::SameLine(); if (ImGui::Button(ICON_FA_IMAGE " Escolher PNG...")) { auto f = OpenFileDialog(window.Handle(), L"PNG\0*.png\0"); if (!f.empty()) mIcon = f; }
        static bool incSrc = false; ImGui::Checkbox("Incluir codigo-fonte C# (.cs)", &incSrc); ImGui::Separator(); ImGui::TextDisabled("Sera salvo em: %s", (modsDir / (std::string(mName) + ".beatson")).string().c_str());
        ImGui::TextDisabled("Dica: compile os scripts antes (File > Build C# Scripts) - a DLL vai junto no pacote.");
        if (ImGui::Button(ICON_FA_FILE_EXPORT " Exportar", { 140, 34 })) { SaveAll(); ExportOptions o; o.info.name = mName; o.info.author = mAuthor; o.info.version = mVersion; o.info.description = mDesc; o.info.startLevel = levelFile; o.iconPng = mIcon; o.projectDir = projectDir.string(); o.includeScriptSources = incSrc;
            std::string safe = mName; for (char& ch : safe) if (!isalnum((unsigned char)ch) && ch != '-' && ch != '_') ch = '_'; o.outFile = (modsDir / (safe + ".beatson")).string(); std::string err; if (ExportMod(o, err)) { Log("Mod exportado: %s", o.outFile.c_str()); mods.dirty = true; showMods = true; showExport = false; ImGui::CloseCurrentPopup(); } else Log("Erro ao exportar: %s", err.c_str()); }
        ImGui::SameLine(); if (ImGui::Button("Cancelar", { 100, 34 })) { showExport = false; ImGui::CloseCurrentPopup(); } ImGui::EndPopup(); }
};
int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) { EditorApp app; return app.Run(L"BeatsOn! Editor", 1600, 900, true); }
