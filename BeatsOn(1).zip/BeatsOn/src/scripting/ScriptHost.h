#pragma once
// Hospeda o runtime .NET (hostfxr) dentro do processo para rodar scripts C# (BeatsOn.Scripting.dll).
#include "BeatsOnAPI.h"
#include <string>
namespace bo {
class ScriptHost {
public:
    bool Init(const std::string& scriptingDir);       // pasta com BeatsOn.Scripting.dll + .runtimeconfig.json
    bool LoadUserAssembly(const std::string& dll);    // compilada de <projeto>/Scripts
    bool Activate(const std::string& className);      // instancia uma classe BeatsOnScript
    void Clear() { if (ready && cb.ClearScripts) cb.ClearScripts(); }
    bool Ready() const { return ready; }
    BOManagedCallbacks cb{};
private: bool ready = false;
};
}
