#pragma once
#include "BeatsOnAPI.h"
#include "../engine/Scene.h"
#include "../engine/CameraRig.h"
#include "../engine/Platform.h"
#include "../engine/Audio.h"
#include "../game/GameSession.h"
namespace bo {
// Tudo que a API de scripts enxerga. O runtime do jogo (e o "Play" do editor) preenche isto.
struct ScriptContext {
    Scene* scene = nullptr; CameraRig* camera = nullptr; GameSession* session = nullptr; AudioEngine* audio = nullptr; Input* input = nullptr; std::string assetRoot;
    std::function<void(const std::string&)> loadLevel; std::function<void()> endSong; std::function<double()> songTimeMs; std::function<void(int, int, bool)> strumPulse; std::function<void(const char*)> log;
};
void ScriptApi_SetContext(ScriptContext* ctx);   // define o contexto atual
const BOApi* ScriptApi_Get();                    // tabela de funcoes entregue ao C#
}
