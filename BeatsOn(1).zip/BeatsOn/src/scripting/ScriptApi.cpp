#include "ScriptContext.h"
namespace bo {
static ScriptContext* C = nullptr;
void ScriptApi_SetContext(ScriptContext* c) { C = c; }
static Entity* E(uint32_t id) { return (C && C->scene) ? C->scene->Find(id) : nullptr; }
static Ease EA(int e) { return (Ease)std::clamp(e, 0, (int)Ease::Instant); }

static void Camera_ZoomTo(float z, float d, int e) { if (C) C->camera->ZoomTo(z, d, EA(e)); }
static void Camera_ZoomPunch(float a, float d) { if (C) C->camera->ZoomPunch(a, d); }
static void Camera_FovTo(float f, float d, int e) { if (C) C->camera->FovTo(f, d, EA(e)); }
static void Camera_MoveTo(float x, float y, float z, float d, int e) { if (C) C->camera->MoveTo(x, y, z, d, EA(e)); }
static void Camera_RotateTo(float p, float y, float r, float d, int e) { if (C) C->camera->RotateTo(p, y, r, d, EA(e)); }
static void Camera_Shake(float i, float d) { if (C) C->camera->Shake(i, d); }
static void Camera_Flash(float r, float g, float b, float a, float d) { if (C) C->camera->Flash(r, g, b, a, d); }
static void Camera_Fade(float r, float g, float b, int out, float d) { if (C) C->camera->Fade(r, g, b, out != 0, d); }
static void Camera_SetPost(int p, float v, float d, int e) { if (C && p >= 0 && p < (int)PostParam::Count) C->camera->SetPost((PostParam)p, v, d, EA(e)); }
static void Camera_Follow(uint32_t id, float x, float y, float z, float l) { if (C) C->camera->Follow(id, { x,y,z }, l); }
static void Camera_SetOrtho(int on, float s) { if (C) C->camera->SetOrtho(on != 0, s); }
static uint32_t Entity_Find(const char* n) { if (!C || !C->scene) return 0; auto* e = C->scene->FindByName(n); return e ? e->id : 0; }
static void Entity_SetPosition(uint32_t id, float x, float y, float z) { if (auto* e = E(id)) e->transform.position = { x,y,z }; }
static void Entity_GetPosition(uint32_t id, float* o) { if (auto* e = E(id)) { o[0] = e->transform.position.x; o[1] = e->transform.position.y; o[2] = e->transform.position.z; } }
static void Entity_SetRotation(uint32_t id, float x, float y, float z) { if (auto* e = E(id)) e->transform.rotation = { x,y,z }; }
static void Entity_SetScale(uint32_t id, float x, float y, float z) { if (auto* e = E(id)) e->transform.scale = { x,y,z }; }
static void Entity_SetActive(uint32_t id, int a) { if (auto* e = E(id)) e->active = a != 0; }
static void Sprite_SetTexture(uint32_t id, const char* p) { if (auto* e = E(id)) if (e->sprite) e->sprite->texture = p; }
static void Sprite_SetTint(uint32_t id, float r, float g, float b, float a) { if (auto* e = E(id)) if (e->sprite) e->sprite->tint = { r,g,b,a }; }
static void Sprite_SetFlipX(uint32_t id, int f) { if (auto* e = E(id)) if (e->sprite) e->sprite->flipX = f != 0; }
static void Sprite_SetSize(uint32_t id, float w, float h) { if (auto* e = E(id)) if (e->sprite) e->sprite->size = { w,h }; }
static void Sprite_PlayAnim(uint32_t id, const char* n, int r) { if (auto* e = E(id)) if (e->animator) e->animator->Play(n, r != 0); }
static void Sprite_AddGridAnim(uint32_t id, const char* n, int s, int c, int cols, int rows, float fps, int loop) { if (auto* e = E(id)) { if (!e->animator) e->animator = SpriteAnimator{}; e->animator->AddGridAnimation(n, s, c, cols, rows, fps, loop != 0); } }
static void Sky_Set(float el, float az, float cover, float dens) { if (!C || !C->scene) return; for (auto& e : C->scene->entities) if (e->sky) { e->sky->sunElevation = el; e->sky->sunAzimuth = az; e->sky->cloudCover = cover; e->sky->cloudDensity = dens; } }
static int Game_GetScore() { return C && C->session ? C->session->score : 0; }
static int Game_GetCombo() { return C && C->session ? C->session->combo : 0; }
static float Game_GetHealth() { return C && C->session ? C->session->health : 0.5f; }
static void Game_SetHealth(float h) { if (C && C->session) C->session->health = std::clamp(h, 0.f, 1.f); }
static double Game_GetSongTimeMs() { return C && C->songTimeMs ? C->songTimeMs() : 0.0; }
static void Game_LoadLevel(const char* p) { if (C && C->loadLevel) C->loadLevel(p); }
static void Game_EndSong() { if (C && C->endSong) C->endSong(); }
static void Strum_Pulse(int side, int lane, int pressed) { if (C && C->strumPulse) C->strumPulse(side, lane, pressed != 0); }
static int Input_KeyDown(int vk) { return C && C->input && C->input->Down(vk); }
static int Input_KeyPressed(int vk) { return C && C->input && C->input->Pressed(vk); }
static void Audio_PlaySfx(const char* p) { if (C && C->audio) C->audio->PlayOneShot(C->assetRoot + "/" + p); }
static void LogFn(const char* m) { if (C && C->log) C->log(m); else Log("[Script] %s", m); }

const BOApi* ScriptApi_Get() {
    static BOApi api = { 1, Camera_ZoomTo, Camera_ZoomPunch, Camera_FovTo, Camera_MoveTo, Camera_RotateTo, Camera_Shake, Camera_Flash, Camera_Fade, Camera_SetPost, Camera_Follow, Camera_SetOrtho,
        Entity_Find, Entity_SetPosition, Entity_GetPosition, Entity_SetRotation, Entity_SetScale, Entity_SetActive, Sprite_SetTexture, Sprite_SetTint, Sprite_SetFlipX, Sprite_SetSize, Sprite_PlayAnim, Sprite_AddGridAnim,
        Sky_Set, Game_GetScore, Game_GetCombo, Game_GetHealth, Game_SetHealth, Game_GetSongTimeMs, Game_LoadLevel, Game_EndSong, Strum_Pulse, Input_KeyDown, Input_KeyPressed, Audio_PlaySfx, LogFn };
    return &api; }
}
