#include "ScriptHost.h"
#include "ScriptContext.h"
namespace bo {
typedef int(__cdecl* init_fn)(const wchar_t*, const void*, void**); typedef int(__cdecl* getdel_fn)(void*, int, void**); typedef int(__cdecl* close_fn)(void*);
typedef int(__cdecl* load_fn)(const wchar_t*, const wchar_t*, const wchar_t*, const wchar_t*, void*, void**);
static std::wstring FindHostFxr() {
    std::vector<fs::path> roots; if (const char* r = getenv("DOTNET_ROOT")) roots.push_back(r); if (const char* pf = getenv("ProgramFiles")) roots.push_back(fs::path(pf) / "dotnet");
    for (auto& root : roots) { fs::path d = root / "host" / "fxr"; if (!fs::exists(d)) continue; fs::path best; for (auto& v : fs::directory_iterator(d)) if (v.is_directory() && (best.empty() || v.path().filename() > best.filename())) best = v.path();
        if (!best.empty() && fs::exists(best / "hostfxr.dll")) return (best / "hostfxr.dll").wstring(); } return {}; }
bool ScriptHost::Init(const std::string& dir) {
    fs::path d = dir, dll = d / "BeatsOn.Scripting.dll", rc = d / "BeatsOn.Scripting.runtimeconfig.json";
    if (!fs::exists(dll) || !fs::exists(rc)) { Log("[Script] BeatsOn.Scripting.dll nao encontrado em %s (rode: dotnet build scripts/BeatsOn.Scripting -c Release)", dir.c_str()); return false; }
    std::wstring fxr = FindHostFxr(); if (fxr.empty()) { Log("[Script] .NET 8 runtime nao encontrado. Instale o .NET 8 Desktop/Runtime."); return false; }
    HMODULE lib = LoadLibraryW(fxr.c_str()); if (!lib) return false;
    auto initF = (init_fn)GetProcAddress(lib, "hostfxr_initialize_for_runtime_config"); auto getF = (getdel_fn)GetProcAddress(lib, "hostfxr_get_runtime_delegate"); auto closeF = (close_fn)GetProcAddress(lib, "hostfxr_close");
    void* ctx = nullptr; if (initF(rc.c_str(), nullptr, &ctx) > 2 || !ctx) { Log("[Script] hostfxr_initialize falhou"); return false; }
    load_fn load = nullptr; if (getF(ctx, 5 /*hdt_load_assembly_and_get_function_pointer*/, (void**)&load) != 0 || !load) { Log("[Script] get_runtime_delegate falhou"); return false; } closeF(ctx);
    const wchar_t* type = L"BeatsOn.Host, BeatsOn.Scripting"; const wchar_t* UCO = (const wchar_t*)(intptr_t)-1;   // UNMANAGEDCALLERSONLY_METHOD
    auto get = [&](const wchar_t* name, void** out) { int rcd = load(dll.c_str(), type, name, UCO, nullptr, out); if (rcd != 0) Log("[Script] metodo %ls nao encontrado (0x%x)", name, rcd); return rcd == 0; };
    void* initFn = nullptr; bool ok = get(L"Init", &initFn);
    ok &= get(L"OnLevelLoad", (void**)&cb.OnLevelLoad); ok &= get(L"OnUpdate", (void**)&cb.OnUpdate); ok &= get(L"OnBeat", (void**)&cb.OnBeat); ok &= get(L"OnStep", (void**)&cb.OnStep);
    ok &= get(L"OnSongStart", (void**)&cb.OnSongStart); ok &= get(L"OnSongEnd", (void**)&cb.OnSongEnd); ok &= get(L"OnNoteSpawn", (void**)&cb.OnNoteSpawn); ok &= get(L"OnNoteReachStrum", (void**)&cb.OnNoteReachStrum);
    ok &= get(L"OnNoteHit", (void**)&cb.OnNoteHit); ok &= get(L"OnNoteMiss", (void**)&cb.OnNoteMiss); ok &= get(L"OnGhostTap", (void**)&cb.OnGhostTap); ok &= get(L"OnEvent", (void**)&cb.OnEvent);
    ok &= get(L"LoadScriptAssembly", (void**)&cb.LoadScriptAssembly); ok &= get(L"ActivateScript", (void**)&cb.ActivateScript); ok &= get(L"ClearScripts", (void**)&cb.ClearScripts);
    if (!ok) return false; ((void(__stdcall*)(const BOApi*))initFn)(ScriptApi_Get()); ready = true; Log("[Script] runtime .NET + BeatsOn.Scripting carregados."); return true; }
bool ScriptHost::LoadUserAssembly(const std::string& dll) { return ready && cb.LoadScriptAssembly && cb.LoadScriptAssembly(dll.c_str()) != 0; }
bool ScriptHost::Activate(const std::string& cls) { return ready && cb.ActivateScript && cb.ActivateScript(cls.c_str()) != 0; }
}
