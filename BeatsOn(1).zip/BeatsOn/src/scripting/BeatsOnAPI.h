#pragma once
// BeatsOn! Engine API (ABI C estavel). A engine entrega esta tabela de funcoes ao C# (BeatsOn.Scripting) na inicializacao.
// A ORDEM dos campos deve bater com scripts/BeatsOn.Scripting/NativeApi.cs
#include <cstdint>
extern "C" {
struct BOApi {
    uint32_t version;
    // ---- Camera: zoom, movimento, rotacao, efeitos e pos-processamento ----
    void (*Camera_ZoomTo)(float zoom, float dur, int ease);
    void (*Camera_ZoomPunch)(float amount, float dur);
    void (*Camera_FovTo)(float fov, float dur, int ease);
    void (*Camera_MoveTo)(float x, float y, float z, float dur, int ease);
    void (*Camera_RotateTo)(float pitch, float yaw, float roll, float dur, int ease);
    void (*Camera_Shake)(float intensity, float dur);
    void (*Camera_Flash)(float r, float g, float b, float amount, float dur);
    void (*Camera_Fade)(float r, float g, float b, int fadeOut, float dur);
    void (*Camera_SetPost)(int param, float value, float dur, int ease);
    void (*Camera_Follow)(uint32_t entity, float ox, float oy, float oz, float lerp);
    void (*Camera_SetOrtho)(int on, float size);
    // ---- Entidades / Sprites ----
    uint32_t (*Entity_Find)(const char* name);
    void (*Entity_SetPosition)(uint32_t id, float x, float y, float z);
    void (*Entity_GetPosition)(uint32_t id, float* xyz);
    void (*Entity_SetRotation)(uint32_t id, float x, float y, float z);
    void (*Entity_SetScale)(uint32_t id, float x, float y, float z);
    void (*Entity_SetActive)(uint32_t id, int active);
    void (*Sprite_SetTexture)(uint32_t id, const char* path);
    void (*Sprite_SetTint)(uint32_t id, float r, float g, float b, float a);
    void (*Sprite_SetFlipX)(uint32_t id, int flip);
    void (*Sprite_SetSize)(uint32_t id, float w, float h);
    void (*Sprite_PlayAnim)(uint32_t id, const char* name, int restart);
    void (*Sprite_AddGridAnim)(uint32_t id, const char* name, int start, int count, int cols, int rows, float fps, int loop);
    // ---- Ceu ----
    void (*Sky_Set)(float sunElevation, float sunAzimuth, float cloudCover, float cloudDensity);
    // ---- Jogo ----
    int    (*Game_GetScore)();
    int    (*Game_GetCombo)();
    float  (*Game_GetHealth)();
    void   (*Game_SetHealth)(float h);
    double (*Game_GetSongTimeMs)();
    void   (*Game_LoadLevel)(const char* levelPath);   // troca de level/cena via script
    void   (*Game_EndSong)();
    void   (*Strum_Pulse)(int side, int lane, int pressed);   // anima a seta fixa
    // ---- Input / Audio / Log ----
    int  (*Input_KeyDown)(int vk);
    int  (*Input_KeyPressed)(int vk);
    void (*Audio_PlaySfx)(const char* path);
    void (*Log)(const char* msg);
};

// Callbacks gerenciados (C#) chamados pela engine. Obtidos via hostfxr em ScriptHost.
struct BOManagedCallbacks {
    void (*OnLevelLoad)(const char* levelName);
    void (*OnUpdate)(float dt);
    void (*OnBeat)(int beat);
    void (*OnStep)(int step);
    void (*OnSongStart)(const char* song);
    void (*OnSongEnd)(const char* song);
    void (*OnNoteSpawn)(int side, int lane, double timeMs);
    void (*OnNoteReachStrum)(int side, int lane, double timeMs, int index);   // <- "o que acontece quando a seta chega na seta principal"
    void (*OnNoteHit)(int side, int lane, int judgement, double deltaMs);
    void (*OnNoteMiss)(int side, int lane);
    void (*OnGhostTap)(int lane);
    void (*OnEvent)(const char* name, const char* arg);
    int  (*LoadScriptAssembly)(const char* path);
    int  (*ActivateScript)(const char* className);
    void (*ClearScripts)();
};
}
