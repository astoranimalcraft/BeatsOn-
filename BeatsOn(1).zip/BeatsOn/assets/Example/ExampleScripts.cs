using BeatsOn;
// Exemplo: copie para <seu projeto>/Scripts/ e adicione "Example.CameraBop" na lista de scripts do Level (Music Editor > Level).
namespace Example
{
    public class CameraBop : BeatsOnScript
    {
        Entity opponent, boyfriend;
        public override void OnLevelLoad(string level)
        {
            opponent = Entity.Find("Opponent"); boyfriend = Entity.Find("Boyfriend");
            Camera.SetPost(PostParam.Vignette, 0.35f, 1f);
        }
        public override void OnBeat(int beat)
        {
            if (beat % 4 == 0) Camera.ZoomPunch(0.05f, 0.3f);          // "bop" a cada compasso
        }
        // A seta chegou na seta principal -> o oponente "canta"
        public override void OnNoteReachStrum(NoteInfo n)
        {
            if (n.Side == Side.Opponent) { Game.PulseStrum(Side.Opponent, n.Lane); Camera.Shake(0.01f, 0.08f); }
        }
        public override void OnNoteMiss(NoteInfo n) { Camera.Flash(1, 0, 0, 0.25f, 0.3f); }
        // Eventos da trilha "Events" do Music Editor. Ex.: nome="zoom", arg="1.3"
        public override void OnEvent(string name, string arg)
        {
            if (name == "zoom" && float.TryParse(arg, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var z)) Camera.ZoomTo(z, 0.5f);
            if (name == "sunset") Sky.Set(8, 250, 0.7f);
            if (name == "next_level") Game.LoadLevel(arg);
        }
    }
}
