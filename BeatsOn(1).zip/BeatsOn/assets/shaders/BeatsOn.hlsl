// BeatsOn! - shaders principais (compilados em runtime com D3DCompileFromFile)
// Entradas: VS_Mesh/PS_Mesh, VS_Shadow, VS_Full, PS_Sky, PS_Grid, VS_Sprite/PS_Sprite, PS_Post
#define PI 3.14159265359

cbuffer Frame : register(b0) {
    float4x4 viewProj, invViewProj, lightViewProj;
    float4 camPos, camRight, camUp;
    float4 sunDir;      // xyz = direcao PARA o sol
    float4 sunColor;    // rgb * intensidade
    float4 skyParams;   // x=time y=cloudCover z=cloudDensity w=hasHDRI
    float4 viewport;    // xy = tamanho, zw = 1/tamanho
    float4 gridParams;  // x=celula y=subdivisoes z=distFade w=ligado
    float4 post0;       // exposure bloom vignette chroma
    float4 post1;       // saturation contrast grain flash
    float4 flashColor;  // rgb, w = hdriIntensity
};
cbuffer Object : register(b1) {
    float4x4 world;
    float4 baseColor;
    float4 mat;         // x=metal y=rough z=ao w=emissiveStrength
    float4 uvRect;
    float4 flags;       // x=hasAlbedo y=hasNormal z=hasORM w=hasEmissive
    float4 flags2;      // x=billboard y=flipX z=lit w=unused
    float4 spriteSize;  // xy size, zw pivot
};
Texture2D tAlbedo : register(t0);
Texture2D tNormal : register(t1);
Texture2D tORM    : register(t2);
Texture2D tEmis   : register(t3);
Texture2D tShadow : register(t4);
Texture2D tHDRI   : register(t5);
SamplerState sLin : register(s0);
SamplerComparisonState sShadow : register(s1);

// ---------------------------------------------------------------- ruido / ceu procedural (estilo UE5 SkyAtmosphere + nuvens volumetricas simplificadas)
float hash21(float2 p){ p = frac(p*float2(123.34,456.21)); p += dot(p,p+45.32); return frac(p.x*p.y); }
float noise(float2 p){ float2 i=floor(p), f=frac(p); f=f*f*(3-2*f);
    return lerp(lerp(hash21(i),hash21(i+float2(1,0)),f.x), lerp(hash21(i+float2(0,1)),hash21(i+float2(1,1)),f.x), f.y); }
float fbm(float2 p){ float a=0.5, s=0; [unroll] for(int i=0;i<6;i++){ s+=a*noise(p); p=p*2.03+float2(17.1,9.2); a*=0.5; } return s; }

float3 AtmosphereColor(float3 d, float3 sun){
    float h = saturate(d.y*0.5+0.5);
    float3 zenith = float3(0.10,0.28,0.65), horizon = float3(0.62,0.74,0.92);
    float3 sky = lerp(horizon, zenith, pow(saturate(d.y),0.45));
    float sunDot = saturate(dot(d,sun));
    float sunH = saturate(sun.y);
    sky = lerp(sky, sky*float3(1.0,0.72,0.55), (1-sunH)*pow(sunDot,3)*0.9);           // por do sol
    sky += float3(1.0,0.75,0.45)*pow(sunDot,8)*0.25*(1.0-sunH*0.6);                    // halo
    sky += float3(1,0.95,0.85)*pow(sunDot,2000)*40;                                    // disco solar
    float3 ground = lerp(float3(0.20,0.22,0.25), horizon, saturate(1+d.y*8));
    return d.y>=0 ? sky : lerp(horizon*0.8, ground, saturate(-d.y*6));
}
float4 Clouds(float3 d, float3 sun, float time, float cover, float density){
    if(d.y<0.02) return 0;
    float2 uv = d.xz/(d.y+0.15)*1.6 + float2(time*0.012, time*0.006);
    float n = fbm(uv) , n2 = fbm(uv*2.3+11.7);
    float c = saturate((n*0.75+n2*0.25 - (1.0-cover)*0.85) * 3.0*density);
    // auto-sombreamento: amostra deslocada na direcao do sol
    float2 so = sun.xz*0.18;
    float n3 = fbm(uv+so)*0.75 + fbm((uv+so)*2.3+11.7)*0.25;
    float shade = saturate(1.0 - (n3-(1.0-cover)*0.85)*2.2);
    float3 lit = float3(1.0,0.97,0.92)*(0.55+0.65*shade), dark = float3(0.45,0.50,0.62);
    float3 col = lerp(dark, lit, shade);
    col *= lerp(float3(1,0.75,0.6),float3(1,1,1), saturate(sun.y*3));
    float fade = saturate(d.y*4.0);
    return float4(col, c*fade);
}
float2 DirToEquirect(float3 d){ return float2(atan2(d.z,d.x)/(2*PI)+0.5, acos(clamp(d.y,-1,1))/PI); }
float3 SampleSky(float3 d, bool withClouds=true){
    float3 sun = normalize(sunDir.xyz);
    if(skyParams.w>0.5) return tHDRI.SampleLevel(sLin, DirToEquirect(d), 0).rgb * flashColor.w;
    float3 c = AtmosphereColor(d, sun);
    if(withClouds){ float4 cl = Clouds(d,sun,skyParams.x,skyParams.y,skyParams.z); c = lerp(c, cl.rgb, cl.a); }
    return c;
}

// ---------------------------------------------------------------- fullscreen
struct FSOut { float4 pos:SV_Position; float2 uv:TEXCOORD0; };
FSOut VS_Full(uint id:SV_VertexID){ FSOut o; float2 uv=float2((id<<1)&2, id&2); o.uv=uv; o.pos=float4(uv*float2(2,-2)+float2(-1,1),0,1); return o; }
float3 RayDir(float2 uv){ float4 p = mul(float4(uv*float2(2,-2)+float2(-1,1), 1, 1), invViewProj); return normalize(p.xyz/p.w - camPos.xyz); }
float4 PS_Sky(FSOut i):SV_Target{ float3 d=RayDir(i.uv); return float4(SampleSky(d),1); }

// ---------------------------------------------------------------- grade infinita com subgrades + eixos X(vermelho) Y(verde) Z(azul)
struct GridOut { float4 col:SV_Target; float depth:SV_Depth; };
float GridLine(float2 p, float cell, float w){ float2 g=abs(frac(p/cell-0.5)-0.5)/fwidth(p/cell); return 1.0-saturate(min(g.x,g.y)/w); }
GridOut PS_Grid(FSOut i){
    GridOut o; o.col=0; o.depth=1;
    float3 d = RayDir(i.uv); float3 ro = camPos.xyz;
    if(abs(d.y)<1e-5) discard;
    float t = -ro.y/d.y; if(t<=0) discard;
    float3 p = ro + d*t;
    float4 clip = mul(float4(p,1), viewProj); o.depth = clip.z/clip.w;
    float cell = gridParams.x, sub = gridParams.y;
    float major = GridLine(p.xz, cell, 1.2), minor = GridLine(p.xz, cell/sub, 1.0);
    float dist = length(p.xz-ro.xz); float fade = saturate(1.0 - dist/gridParams.z);
    float fadeSub = saturate(1.0 - dist/(gridParams.z*0.25));
    float3 col = float3(0.55,0.58,0.65); float a = max(major*0.55*fade, minor*0.18*fadeSub);
    float aw = fwidth(p.x)*1.5+0.0005, bw=fwidth(p.z)*1.5+0.0005;
    float ax = saturate(1.0 - abs(p.z)/(bw*1.5));   // linha do eixo X (z=0)
    float az = saturate(1.0 - abs(p.x)/(aw*1.5));   // linha do eixo Z (x=0)
    if(ax>0.01){ col=lerp(col,float3(0.95,0.25,0.25),ax); a=max(a,ax*0.95*saturate(1.0-dist/(gridParams.z*2))); }
    if(az>0.01){ col=lerp(col,float3(0.25,0.45,0.98),az); a=max(a,az*0.95*saturate(1.0-dist/(gridParams.z*2))); }
    if(a<0.003) discard;
    o.col=float4(col,a); return o;
}
// eixo Y (verde): desenhado como linha vertical em x=0,z=0 via PS_AxisY sobre o mesmo fullscreen
float4 PS_AxisY(FSOut i):SV_Target{
    float3 d=RayDir(i.uv), ro=camPos.xyz;
    // distancia entre raio e a linha vertical (0,y,0)
    float2 o2 = ro.xz, d2 = d.xz; float dd = dot(d2,d2); if(dd<1e-8) discard;
    float t = -dot(o2,d2)/dd; if(t<=0) discard; float3 p = ro+d*t;
    float dist = length(p.xz); float w = max(t*length(fwidth(d))*1.5, 0.002);
    float a = saturate(1.0 - dist/w); if(a<0.01) discard; return float4(0.35,0.95,0.35,a*0.9);
}

// ---------------------------------------------------------------- malha PBR
struct MeshIn { float3 pos:POSITION; float3 n:NORMAL; float2 uv:TEXCOORD0; float4 tan:TANGENT; };
struct MeshOut { float4 pos:SV_Position; float3 wpos:TEXCOORD0; float3 n:TEXCOORD1; float2 uv:TEXCOORD2; float4 tan:TEXCOORD3; float4 lpos:TEXCOORD4; };
MeshOut VS_Mesh(MeshIn v){ MeshOut o; float4 w=mul(float4(v.pos,1),world); o.wpos=w.xyz; o.pos=mul(w,viewProj);
    o.n=normalize(mul(v.n,(float3x3)world)); o.tan=float4(normalize(mul(v.tan.xyz,(float3x3)world)),v.tan.w); o.uv=v.uv; o.lpos=mul(w,lightViewProj); return o; }
float4 VS_Shadow(MeshIn v):SV_Position{ return mul(mul(float4(v.pos,1),world),lightViewProj); }

float D_GGX(float NoH,float a){ float a2=a*a; float d=NoH*NoH*(a2-1)+1; return a2/(PI*d*d+1e-5); }
float V_Smith(float NoV,float NoL,float a){ float k=(a+1)*(a+1)/8; return 1.0/((NoV*(1-k)+k)*(NoL*(1-k)+k)+1e-5); }
float3 F_Schlick(float3 f0,float VoH){ return f0+(1-f0)*pow(1-VoH,5); }
float ShadowPCF(float4 lpos, float NoL){
    float3 p = lpos.xyz/lpos.w; float2 uv = p.xy*float2(0.5,-0.5)+0.5;
    if(any(uv<0)||any(uv>1)||p.z>1) return 1;
    float bias = max(0.0015*(1-NoL),0.0004), s=0, texel=1.0/2048.0;
    [unroll] for(int x=-1;x<=1;x++) [unroll] for(int y=-1;y<=1;y++) s+=tShadow.SampleCmpLevelZero(sShadow, uv+float2(x,y)*texel, p.z-bias);
    return s/9.0;
}
float4 PS_Mesh(MeshOut i):SV_Target{
    float4 alb = baseColor; if(flags.x>0.5) { float4 t=tAlbedo.Sample(sLin,i.uv); alb.rgb*=t.rgb; alb.a*=t.a; }
    float3 N=normalize(i.n);
    if(flags.y>0.5){ float3 tn=tNormal.Sample(sLin,i.uv).xyz*2-1; float3 T=normalize(i.tan.xyz-N*dot(i.tan.xyz,N)); float3 B=cross(N,T)*i.tan.w; N=normalize(tn.x*T+tn.y*B+tn.z*N); }
    float ao=mat.z, rough=mat.y, metal=mat.x;
    if(flags.z>0.5){ float3 o=tORM.Sample(sLin,i.uv).rgb; ao*=o.r; rough*=o.g; metal*=o.b; }
    rough=clamp(rough,0.04,1);
    float3 V=normalize(camPos.xyz-i.wpos), L=normalize(sunDir.xyz), H=normalize(V+L);
    float NoL=saturate(dot(N,L)), NoV=saturate(dot(N,V))+1e-4, NoH=saturate(dot(N,H)), VoH=saturate(dot(V,H));
    float3 f0=lerp(0.04,alb.rgb,metal); float a=rough*rough;
    float3 F=F_Schlick(f0,VoH); float3 spec=D_GGX(NoH,a)*V_Smith(NoV,NoL,a)*F*0.25;
    float3 kd=(1-F)*(1-metal); float3 diff=kd*alb.rgb/PI;
    float sh=ShadowPCF(i.lpos,NoL);
    float3 direct=(diff+spec)*sunColor.rgb*NoL*sh;
    // ambiente: hemisferio do ceu (difuso) + reflexo do ceu (especular, sem nuvens)
    float3 amb = SampleSky(float3(N.x,max(N.y,0.0)*0.5+0.5*N.y,N.z), false)*0.35;
    float3 R=reflect(-V,N); float3 refl=SampleSky(R,false)*lerp(0.15,1.0,saturate(1-rough));
    float3 ambient=kd*alb.rgb*amb*ao + refl*F_Schlick(f0,NoV)*ao*(1-rough*0.7);
    float3 emis=0; if(flags.w>0.5) emis=tEmis.Sample(sLin,i.uv).rgb*mat.w; else emis=alb.rgb*mat.w;
    return float4(direct+ambient+emis, alb.a);
}

// ---------------------------------------------------------------- sprites 2D no mundo 3D (billboard opcional)
struct SprOut { float4 pos:SV_Position; float2 uv:TEXCOORD0; float3 wpos:TEXCOORD1; };
SprOut VS_Sprite(uint id:SV_VertexID){
    float2 c=float2(id&1, (id>>1)&1);                    // 0..1 (strip: 0,1,2,3)
    float2 local=(c-spriteSize.zw)*spriteSize.xy;
    float3 wp;
    float3 origin=float3(world._m30,world._m31,world._m32);
    float3 sc=float3(length(world._m00_m01_m02),length(world._m10_m11_m12),length(world._m20_m21_m22));
    if(flags2.x>0.5){ wp=origin + camRight.xyz*local.x*sc.x + camUp.xyz*local.y*sc.y; }
    else { wp=mul(float4(local.x,local.y,0,1),world).xyz; }
    SprOut o; o.wpos=wp; o.pos=mul(float4(wp,1),viewProj);
    float2 uv=float2(c.x, 1-c.y); if(flags2.y>0.5) uv.x=1-uv.x; o.uv=uvRect.xy+uv*uvRect.zw; return o;
}
float4 PS_Sprite(SprOut i):SV_Target{
    float4 t = tAlbedo.Sample(sLin,i.uv)*baseColor; if(t.a<0.01) discard;
    if(flags2.z>0.5){ t.rgb*=0.35+sunColor.rgb*0.12; }
    return t; }

// ---------------------------------------------------------------- pos-processamento (HDR -> LDR)
float3 ACES(float3 x){ return saturate((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14)); }
float4 PS_Post(FSOut i):SV_Target{
    float2 uv=i.uv; float2 c=uv-0.5; float ca=post0.w*0.01;
    float3 col; col.r=tAlbedo.Sample(sLin,uv+c*ca).r; col.g=tAlbedo.Sample(sLin,uv).g; col.b=tAlbedo.Sample(sLin,uv-c*ca).b;
    // bloom barato (anel de amostras do mip alto)
    float3 b=0; [unroll] for(int k=0;k<12;k++){ float ang=k*0.5236; float2 o=float2(cos(ang),sin(ang)); 
        b+=tAlbedo.SampleLevel(sLin,uv+o*viewport.zw*14,0).rgb; b+=tAlbedo.SampleLevel(sLin,uv+o*viewport.zw*40,0).rgb; }
    col+=max(b/24.0-1.0,0)*post0.y*2.0 + b/24.0*post0.y*0.2;
    col*=post0.x; col=ACES(col); col=pow(col,1/2.2);
    float l=dot(col,float3(0.299,0.587,0.114)); col=lerp(l.xxx,col,post1.x); col=(col-0.5)*post1.y+0.5;
    col*=1.0-post0.z*pow(length(c)*1.35,2.2);
    col+= (hash21(uv*viewport.xy+skyParams.x)-0.5)*post1.z;
    col=lerp(col,flashColor.rgb,post1.w);
    return float4(saturate(col),1); }
