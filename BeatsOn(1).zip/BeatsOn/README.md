# BeatsOn! — jogo de ritmo (estilo FNF) + Engine/Editor
C++20 · DirectX 12 · Dear ImGui + ImGuizmo · Assimp · miniaudio · scripts C# (.NET 8)

Dois executáveis:
* **BeatsOnGame** — GamePlay: menu, Jogar, **Mods** (lista de mods instalados com ícone/nome/autor/descrição).
* **BeatsOnEditor** — a engine: Scene 3D, Hierarquia, Inspetor, Assets, Music Editor, Console, **Export Mod** e **Mods**.

## Compilar (Windows 10/11)
Requisitos: Visual Studio 2022 (C++ desktop), CMake ≥ 3.24, Git, [.NET 8 SDK](https://dotnet.microsoft.com/download) (scripts C#).
```
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```
Os executáveis ficam em `build/Release/` (assets, shaders e `scripting/BeatsOn.Scripting.dll` são copiados junto). A 1ª configuração baixa as dependências (ImGui, Assimp… leva alguns minutos).

## Editor — controles da Scene 3D
| Ação | Tecla |
|---|---|
| Olhar ao redor | **Botão direito** (segurar) |
| Mover | **W A S D**, **Q** (desce) / **E** (sobe) |
| Turbo | **Shift** |
| Velocidade da câmera | **Scroll** do mouse (com botão direito) |
| Gizmo Mover/Rotacionar/Escalar | **1 / 2 / 3** (ou botões) |
| Salvar | Ctrl+S · Excluir entidade: Del |

Grade infinita com subgrades; eixos **X (vermelho) Y (verde) Z (azul)**. O projeto padrão já vem com 2 sprites (Boyfriend/Opponent), câmera, fundo, chão, sol e céu procedural com nuvens.

## Estrutura de um projeto (`Projects/<nome>/`)
`Levels/*.level.json` · `Scenes/*.scene.json` · `Songs/` (mp3/wav/ogg/flac) · `Assets/` (modelos, texturas PBR, HDRI) · `Scripts/` (C#).

## Music Editor
Timeline vertical: 4 colunas **Oponente**, 4 **Jogador** e 1 de **Eventos**. Clique = nota; Ctrl+clique = sustain; botão direito = remover; Scroll = mover; Ctrl+Scroll = zoom. À direita: **lista de levels, músicas do level** (reordenar/remover/adicionar), cena, scripts e **próximo level** (carregado quando as músicas acabam; ou via script `Game.LoadLevel(...)` / evento `next_level`).

## API de scripts C# (`scripts/BeatsOn.Scripting`)
```csharp
using BeatsOn;
public class MeuScript : BeatsOnScript {
  public override void OnBeat(int beat) { if (beat % 4 == 0) Camera.ZoomPunch(0.05f); }
  public override void OnNoteReachStrum(NoteInfo n) {   // a seta chegou na seta principal
     if (n.Side == Side.Opponent) { Game.PulseStrum(Side.Opponent, n.Lane); Camera.Shake(0.01f, 0.08f); } }
  public override void OnNoteHit(NoteInfo n, Judgement j, double d) { }
  public override void OnNoteMiss(NoteInfo n) { Camera.Flash(1,0,0,0.25f,0.3f); }
  public override void OnEvent(string name, string arg) { if (name=="next_level") Game.LoadLevel(arg); }
}
```
* **Camera**: `ZoomTo, ZoomPunch, FovTo, MoveTo, RotateTo, Shake, Flash, Fade, SetPost(Exposure|Bloom|Vignette|ChromaticAberration|Saturation|Contrast|Grain), Follow, SetOrthographic` (com easings).
* **Entity/Sprite**: `Entity.Find(nome)`, `Position`, `SetRotation/Scale/Active`, `SetTexture, SetTint, FlipX, PlayAnim, AddGridAnim`.
* **Sky**: `Sky.Set(elevação, azimute, nuvens, densidade)` · **Game**: `Score, Combo, Health, SongTimeMs, LoadLevel, EndSong, PulseStrum, PlaySfx, Log` · **Input**.
* Callbacks: `OnLevelLoad, OnUpdate, OnBeat, OnStep, OnSongStart/End, OnNoteSpawn, OnNoteReachStrum, OnNoteHit, OnNoteMiss, OnGhostTap, OnEvent`.

Para compilar seus scripts: **File > Build C# Scripts** (gera `Scripts/bin/GameScripts.dll`). Adicione o nome da classe (ex. `Example.CameraBop`) em *Scripts do level* no Music Editor.
A API nativa (ABI C) está em `src/scripting/BeatsOnAPI.h`.

## Mods
* **File > Export Mod…**: nome, descrição, criador, versão e ícone (PNG) → gera `Mods/<nome>.beatson` (zip com `mod.json`, levels, cenas, músicas, assets e DLL dos scripts).
* Botão **Mods** (Editor e Game): lista os `.beatson` da pasta `Mods/`, instala novos e permite jogar.

## Visual
Cena HDR com sol direcional + sombras PCF (2048²), PBR (GGX, normal/ORM/emissive), céu atmosférico procedural com nuvens (fbm auto-sombreadas), HDRI equirretangular (`.hdr`), pós-processamento (ACES, bloom, vinheta, aberração cromática, saturação/contraste, grain, flash/fade). Modelos via Assimp (fbx, obj, gltf, dae, 3ds…).

## Status / limitações conhecidas
* Gameplay lógico, formato de level, pacote de mods e shaders foram testados/validados fora do Windows; o **código DirectX 12/ImGui/Editor** foi escrito para Windows e ainda precisa do seu primeiro build — espere pequenos ajustes de compilação.
* Personagens 3D: ainda não (sprites 2D funcionam; modelos 3D estáticos já renderizam). Skinning/animação 3D é o próximo passo.
* HDRI: `.hdr` (Radiance); `.exr` precisa ser convertido. ImGuizmo usa convenção destro; pode haver pequena diferença de eixos com o renderer (LH).
* Scripts C#: a DLL é carregada uma vez por processo (reinicie para recarregar). Sem waveform no Music Editor ainda.
* Controles do jogo: **D F J K** ou setas. Esc volta ao menu.
