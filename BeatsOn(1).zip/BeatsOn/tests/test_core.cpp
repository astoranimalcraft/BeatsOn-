#include "../src/game/GameSession.h"
#include "../src/mods/ModInfo.h"
#include <cassert>
#include <cstdio>
using namespace bo;
struct Ev : IGameEvents {
    int beats=0,reach=0,hit=0,miss=0,ghost=0,spawn=0,scr=0; bool end=false; Judgement last=Judgement::Miss;
    void OnBeat(int)override{beats++;} void OnNoteReachStrum(const NoteRuntime&)override{reach++;}
    void OnNoteHit(const NoteRuntime&,Judgement j,double)override{hit++;last=j;} void OnNoteMiss(const NoteRuntime&)override{miss++;}
    void OnGhostTap(int)override{ghost++;} void OnNoteSpawn(const NoteRuntime&)override{spawn++;}
    void OnScriptEvent(const std::string&,const std::string&)override{scr++;} void OnSongEnd(const SongData&)override{end=true;}
};
int main(){
    SongData s; s.bpm=120; s.notes={{1000,0,0,0,"normal"},{2000,1,0,0,"normal"},{3000,2,1,0,"normal"}}; s.events={{1500,"zoom","1.2"}};
    // roundtrip JSON
    LevelData L; L.songs.push_back(s); L.nextLevel="Levels/Level02.level.json";
    assert(SaveLevel(L,"/tmp/t.level.json")); LevelData L2; assert(LoadLevel(L2,"/tmp/t.level.json"));
    assert(L2.songs[0].notes.size()==3 && L2.nextLevel==L.nextLevel);
    ModInfo mi; mi.name="X"; nlohmann::json j=mi; ModInfo m2=j.get<ModInfo>(); assert(m2.name=="X");
    // gameplay
    GameSession g; Ev ev; g.Start(L2.songs[0], &ev); InputFrame in;
    for(double t=0;t<=6000;t+=8){ InputFrame f;
        if(std::abs(t-1000)<4) { f.pressed[0]=f.down[0]=true; }   // acerta nota 1
        /* nota 2 (2000ms lane 1) e' ignorada -> miss */
        g.Update(t,f); }
    printf("beats=%d reach=%d hit=%d miss=%d spawn=%d scr=%d score=%d end=%d\n",ev.beats,ev.reach,ev.hit,ev.miss,ev.spawn,ev.scr,g.score,(int)ev.end);
    assert(ev.reach==3 && ev.miss==1 && ev.hit==2 /*1 jogador + 1 oponente*/ && ev.scr==1 && ev.end && ev.spawn==3);
    assert(g.combo==0 && g.score>0);
    puts("TESTES OK"); }
