#include "../src/mods/ModPackage.h"
#include "../src/game/Chart.h"
#include <cassert>
#include <cstdio>
using namespace bo; namespace fs = std::filesystem;
int main(){
    fs::remove_all("/tmp/proj"); fs::remove_all("/tmp/Mods"); fs::create_directories("/tmp/proj/Levels"); fs::create_directories("/tmp/proj/Songs"); fs::create_directories("/tmp/proj/Scripts/bin"); fs::create_directories("/tmp/proj/Scripts/obj");
    LevelData L; L.songs.push_back(SongData{}); SaveLevel(L,"/tmp/proj/Levels/Level01.level.json"); std::ofstream("/tmp/proj/Songs/a.ogg")<<"fake"; std::ofstream("/tmp/proj/Scripts/bin/GameScripts.dll")<<"dll"; std::ofstream("/tmp/proj/Scripts/obj/x.dll")<<"no"; std::ofstream("/tmp/proj/Scripts/S.cs")<<"//src"; std::ofstream("/tmp/icon.png")<<"PNGDATA";
    ExportOptions o; o.info.name="Meu Mod"; o.info.author="Eu"; o.info.description="desc"; o.projectDir="/tmp/proj"; o.iconPng="/tmp/icon.png"; o.outFile="/tmp/Mods/MeuMod.beatson";
    std::string err; assert(ExportMod(o,err));
    auto mods=ListMods("/tmp/Mods"); assert(mods.size()==1 && mods[0].name=="Meu Mod" && mods[0].author=="Eu" && mods[0].icon=="icon.png");
    std::vector<unsigned char> icon; assert(ReadModIcon(mods[0],icon) && icon.size()==7);
    assert(ExtractMod(mods[0],"/tmp/cache"));
    assert(fs::exists("/tmp/cache/Levels/Level01.level.json") && fs::exists("/tmp/cache/Songs/a.ogg") && fs::exists("/tmp/cache/Scripts/bin/GameScripts.dll"));
    assert(!fs::exists("/tmp/cache/Scripts/S.cs") && !fs::exists("/tmp/cache/Scripts/obj/x.dll"));
    puts("MOD TESTS OK"); }
